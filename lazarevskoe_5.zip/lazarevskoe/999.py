import os

def create_improved_create_page():
    """Создает улучшенную страницу добавления объявления"""
    
    file_path = 'lazarevskoe/pages/ads/create.php'
    
    content = '''<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

$page_title = "Добавить объявление - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';

$database = new Database();
$db = $database->getConnection();

// Получаем категории с группировкой
$categories_data = $db->query("
    SELECT 
        c.id,
        c.name,
        c.parent_id,
        p.name as parent_name
    FROM categories c
    LEFT JOIN categories p ON c.parent_id = p.id
    WHERE c.parent_id IS NOT NULL
    ORDER BY p.name, c.name
")->fetchAll();

// Группируем по родительским категориям
$grouped_categories = [];
foreach ($categories_data as $cat) {
    $parent_name = $cat['parent_name'] ?: 'Другие категории';
    if (!isset($grouped_categories[$parent_name])) {
        $grouped_categories[$parent_name] = [];
    }
    $grouped_categories[$parent_name][] = $cat;
}
?>

<style>
@import url('../../assets/css/style.css');

/* Стили для предпросмотра изображений */
.image-preview-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: 15px;
    margin: 15px 0;
}

.image-preview-item {
    position: relative;
    aspect-ratio: 1;
    border: 2px dashed var(--gray);
    border-radius: 10px;
    overflow: hidden;
    background: var(--light);
}

.image-preview-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.image-preview-item .remove-btn {
    position: absolute;
    top: 5px;
    right: 5px;
    background: var(--error);
    color: white;
    border: none;
    border-radius: 50%;
    width: 25px;
    height: 25px;
    cursor: pointer;
    font-size: 12px;
}

.empty-preview {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: var(--secondary);
    font-size: 14px;
}

.empty-preview i {
    font-size: 24px;
    margin-bottom: 5px;
}

/* Стили для формы */
.form-group {
    margin-bottom: 25px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: var(--primary);
    font-size: 16px;
}

.form-input, .form-select, .form-textarea {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid var(--gray);
    border-radius: 8px;
    font-size: 16px;
    background: white;
    transition: border-color 0.3s ease;
    box-sizing: border-box;
}

.form-input:focus, .form-select:focus, .form-textarea:focus {
    border-color: var(--primary);
    outline: none;
}

.form-textarea {
    resize: vertical;
    min-height: 120px;
}

.file-input-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
}

.file-input {
    position: absolute;
    left: -9999px;
}

.file-input-label {
    display: block;
    padding: 15px;
    border: 2px dashed var(--gray);
    border-radius: 8px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    background: var(--light);
}

.file-input-label:hover {
    border-color: var(--primary);
    background: var(--primary-light);
}

.file-input-label i {
    font-size: 24px;
    color: var(--primary);
    margin-bottom: 8px;
    display: block;
}

.category-group {
    margin-bottom: 20px;
    padding: 15px;
    background: var(--light);
    border-radius: 8px;
    border-left: 4px solid var(--primary);
}

.category-group-title {
    font-weight: 600;
    color: var(--primary);
    margin-bottom: 10px;
    font-size: 16px;
}

.form-hint {
    font-size: 14px;
    color: var(--secondary);
    margin-top: 5px;
    display: block;
}

.required::after {
    content: " *";
    color: var(--error);
}
</style>

<div class="header-title">
    <h1>Добавить объявление</h1>
    <small>Заполните информацию о вашем предложении</small>
</div>

<div class="page-container">
    <div style="max-width: 700px; margin: 0 auto;">
        
        <!-- Статус формы -->
        <div class="nav-cards-grid" style="margin-bottom: 30px;">
            <div class="nav-card" style="background: var(--success-light); border-color: var(--success);">
                <i class="fas fa-camera" style="color: var(--success);"></i>
                <span>До 5 фото</span>
            </div>
            <div class="nav-card" style="background: var(--primary-light); border-color: var(--primary);">
                <i class="fas fa-check" style="color: var(--primary);"></i>
                <span>Работает</span>
            </div>
            <div class="nav-card" style="background: var(--accent-light); border-color: var(--accent);">
                <i class="fas fa-bolt" style="color: var(--accent);"></i>
                <span>Быстро</span>
            </div>
        </div>

        <form action="process_ad_fixed.php" method="POST" enctype="multipart/form-data" 
              style="background: var(--light); padding: 30px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            
            <!-- Категория -->
            <div class="form-group">
                <label class="form-label required">Категория:</label>
                <select name="category_id" class="form-select" required>
                    <option value="">-- Выберите категорию --</option>
                    <?php foreach($grouped_categories as $parent_name => $subcategories): ?>
                        <optgroup label="<?php echo htmlspecialchars($parent_name); ?>">
                            <?php foreach($subcategories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>">
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Основная информация -->
            <div class="form-group">
                <label class="form-label required">Заголовок объявления:</label>
                <input type="text" name="title" class="form-input" required 
                       placeholder="Уютная квартира у моря, Прокат гидроциклов, Экскурсия к водопадам">
            </div>
            
            <div class="form-group">
                <label class="form-label required">Описание:</label>
                <textarea name="description" class="form-textarea" required 
                          placeholder="Подробное описание вашего предложения..."></textarea>
            </div>
            
            <!-- Цена и контакты -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
                <div class="form-group">
                    <label class="form-label">Цена (руб):</label>
                    <input type="number" name="price" class="form-input" 
                           placeholder="1500" min="0">
                    <span class="form-hint">Оставьте пустым для "Договорная"</span>
                </div>
                
                <div class="form-group">
                    <label class="form-label required">Телефон:</label>
                    <input type="tel" name="phone" class="form-input" required 
                           placeholder="+7 999 123-45-67">
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Местоположение:</label>
                <input type="text" name="location" class="form-input" 
                       placeholder="ул. Победы, 15 или Центральный пляж">
                <span class="form-hint">Укажите адрес или ориентир</span>
            </div>
            
            <div class="form-group">
                <label class="form-label">Email:</label>
                <input type="email" name="email" class="form-input" 
                       placeholder="ваш@email.com">
                <span class="form-hint">Для уведомлений о бронированиях</span>
            </div>
            
            <!-- Загрузка фото -->
            <div class="form-group">
                <label class="form-label">Фотографии:</label>
                
                <div class="file-input-wrapper">
                    <input type="file" id="photo-upload" name="photos[]" 
                           class="file-input" multiple accept="image/jpeg,image/png,image/webp">
                    <label for="photo-upload" class="file-input-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Нажмите для выбора фото или перетащите сюда</span>
                        <small style="display: block; margin-top: 5px; color: var(--secondary);">
                            Можно выбрать до 5 фотографий (JPG, PNG, WebP)
                        </small>
                    </label>
                </div>
                
                <!-- Контейнер для предпросмотра -->
                <div class="image-preview-container" id="image-preview">
                    <div class="image-preview-item empty-preview">
                        <i class="fas fa-images"></i>
                        <span>Фото появятся здесь</span>
                    </div>
                </div>
            </div>
            
            <!-- Кнопка отправки -->
            <button type="submit" class="cta-button" style="width: 100; background: var(--success); padding: 15px; font-size: 18px;">
                <i class="fas fa-paper-plane"></i> Опубликовать объявление
            </button>
        </form>
        
        <div style="text-align: center; margin-top: 25px;">
            <a href="../../index.php" class="profile-btn secondary" style="text-decoration: none; margin: 0 10px;">
                <i class="fas fa-arrow-left"></i> На главную
            </a>
            <a href="../../profile.php" class="profile-btn" style="text-decoration: none; margin: 0 10px;">
                <i class="fas fa-user"></i> Мой профиль
            </a>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('photo-upload');
    const previewContainer = document.getElementById('image-preview');
    const maxFiles = 5;
    
    // Обработка выбора файлов
    fileInput.addEventListener('change', function(e) {
        const files = Array.from(e.target.files).slice(0, maxFiles);
        updatePreview(files);
    });
    
    // Drag and drop
    const fileLabel = document.querySelector('.file-input-label');
    
    fileLabel.addEventListener('dragover', function(e) {
        e.preventDefault();
        fileLabel.style.borderColor = 'var(--primary)';
        fileLabel.style.background = 'var(--primary-light)';
    });
    
    fileLabel.addEventListener('dragleave', function(e) {
        e.preventDefault();
        fileLabel.style.borderColor = 'var(--gray)';
        fileLabel.style.background = 'var(--light)';
    });
    
    fileLabel.addEventListener('drop', function(e) {
        e.preventDefault();
        fileLabel.style.borderColor = 'var(--gray)';
        fileLabel.style.background = 'var(--light)';
        
        const files = Array.from(e.dataTransfer.files).slice(0, maxFiles);
        fileInput.files = createFileList(files);
        updatePreview(files);
    });
    
    function updatePreview(files) {
        previewContainer.innerHTML = '';
        
        if (files.length === 0) {
            previewContainer.innerHTML = `
                <div class="image-preview-item empty-preview">
                    <i class="fas fa-images"></i>
                    <span>Фото появятся здесь</span>
                </div>
            `;
            return;
        }
        
        files.forEach((file, index) => {
            if (!file.type.startsWith('image/')) return;
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const previewItem = document.createElement('div');
                previewItem.className = 'image-preview-item';
                previewItem.innerHTML = `
                    <img src="${e.target.result}" alt="Preview ${index + 1}">
                    <button type="button" class="remove-btn" data-index="${index}">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                previewContainer.appendChild(previewItem);
                
                // Удаление фото
                previewItem.querySelector('.remove-btn').addEventListener('click', function() {
                    removeFile(index);
                });
            };
            reader.readAsDataURL(file);
        });
    }
    
    function removeFile(index) {
        const dt = new DataTransfer();
        const files = Array.from(fileInput.files);
        files.splice(index, 1);
        
        files.forEach(file => dt.items.add(file));
        fileInput.files = dt.files;
        updatePreview(Array.from(fileInput.files));
    }
    
    function createFileList(files) {
        const dt = new DataTransfer();
        files.forEach(file => dt.items.add(file));
        return dt.files;
    }
});
</script>

<?php include '../../includes/layout/footer.php'; ?>
'''
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"✅ Создана улучшенная форма: {file_path}")

def create_improved_processor():
    """Создает улучшенный обработчик формы"""
    
    file_path = 'lazarevskoe/pages/ads/process_ad_fixed.php'
    
    content = '''<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: create.php');
    exit;
}

$database = new Database();
$db = $database->getConnection();

// Получаем данные из формы
$user_id = $_SESSION['user_id'];
$category_id = $_POST['category_id'] ?? '';
$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$price = !empty($_POST['price']) ? floatval($_POST['price']) : null;
$location = trim($_POST['location'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');

// Валидация
$errors = [];
if (empty($category_id)) $errors[] = "Выберите категорию";
if (empty($title)) $errors[] = "Введите заголовок";
if (empty($description)) $errors[] = "Введите описание";
if (empty($phone)) $errors[] = "Введите телефон";

if (!empty($errors)) {
    showErrorPage($errors);
    exit;
}

// Обработка фото - МНОЖЕСТВЕННАЯ ЗАГРУЗКА
$uploaded_images = [];
$upload_dir = '../../uploads/ads/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

if (isset($_FILES['photos']) && !empty($_FILES['photos']['name'][0])) {
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    foreach ($_FILES['photos']['name'] as $key => $name) {
        if ($_FILES['photos']['error'][$key] === UPLOAD_ERR_OK) {
            $file_extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            
            if (in_array($file_extension, $allowed_extensions)) {
                $file_name = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $name);
                $file_path = $upload_dir . $file_name;
                
                if (move_uploaded_file($_FILES['photos']['tmp_name'][$key], $file_path)) {
                    $uploaded_images[] = $file_name;
                }
            }
        }
    }
}

// Сохраняем в базу
try {
    $images_data = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
    
    $stmt = $db->prepare("
        INSERT INTO ads (user_id, category_id, title, description, price, location, phone, email, images, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())
    ");
    
    $stmt->execute([
        $user_id, 
        $category_id, 
        $title, 
        $description, 
        $price, 
        $location, 
        $phone, 
        $email,
        $images_data
    ]);
    
    $ad_id = $db->lastInsertId();
    
    showSuccessPage($title, $category_id, $price, $location, $db, count($uploaded_images));
    
} catch (Exception $e) {
    showErrorPage(["Ошибка сохранения: " . $e->getMessage()]);
}

function showErrorPage($errors) {
    $page_title = "Ошибка - Лазаревское";
    include '../../includes/layout/header-catalog.php';
    include '../../includes/layout/utility-bar.php';
    
    echo '<div class="page-container">';
    echo '<div style="max-width: 600px; margin: 0 auto; text-align: center;">';
    echo '<div style="background: var(--light); padding: 30px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">';
    echo '<h2 style="color: var(--error); margin-bottom: 20px;">❌ Ошибки в форме</h2>';
    
    foreach ($errors as $error) {
        echo '<div style="background: var(--error); color: white; padding: 10px; border-radius: 8px; margin-bottom: 10px;">' . htmlspecialchars($error) . '</div>';
    }
    
    echo '<div style="margin-top: 25px;">';
    echo '<a href="create.php" class="cta-button" style="text-decoration: none; margin: 0 10px;">← Вернуться к форме</a>';
    echo '<a href="../../index.php" class="profile-btn secondary" style="text-decoration: none; margin: 0 10px;">🏠 На главную</a>';
    echo '</div>';
    
    echo '</div></div></div>';
    include '../../includes/layout/footer.php';
    exit;
}

function showSuccessPage($title, $category_id, $price, $location, $db, $files_count = 0) {
    $page_title = "Успех - Лазаревское";
    include '../../includes/layout/header-catalog.php';
    include '../../includes/layout/utility-bar.php';
    
    echo '<div class="page-container">';
    echo '<div style="max-width: 600px; margin: 0 auto; text-align: center;">';
    echo '<div style="background: var(--light); padding: 40px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">';
    
    echo '<div style="font-size: 48px; color: var(--success); margin-bottom: 20px;">🎉</div>';
    echo '<h2 style="color: var(--success); margin-bottom: 15px;">Объявление успешно создано!</h2>';
    echo '<p style="color: var(--text); margin-bottom: 10px;">Загружено файлов: <strong>' . $files_count . '</strong></p>';
    
    echo '<div style="background: var(--gray); padding: 20px; border-radius: 10px; margin-bottom: 25px; text-align: left;">';
    echo '<h4 style="color: var(--primary); margin-bottom: 10px;">Информация:</h4>';
    echo '<p><strong>Заголовок:</strong> ' . htmlspecialchars($title) . '</p>';
    echo '<p><strong>Категория:</strong> ' . htmlspecialchars(getCategoryName($db, $category_id)) . '</p>';
    if ($price) echo '<p><strong>Цена:</strong> ' . number_format($price, 0, '', ' ') . ' ₽</p>';
    if ($location) echo '<p><strong>Местоположение:</strong> ' . htmlspecialchars($location) . '</p>';
    echo '<p><strong>Статус:</strong> <span style="color: var(--accent);">Активно</span></p>';
    echo '</div>';
    
    echo '<div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">';
    echo '<a href="create.php" class="cta-button" style="text-decoration: none;">➕ Добавить еще</a>';
    echo '<a href="../../profile.php" class="profile-btn" style="text-decoration: none;">👤 Мой профиль</a>';
    echo '<a href="../../index.php" class="profile-btn secondary" style="text-decoration: none;">🏠 На главную</a>';
    echo '</div>';
    
    echo '</div></div></div>';
    include '../../includes/layout/footer.php';
    exit;
}

function getCategoryName($db, $category_id) {
    $stmt = $db->prepare("SELECT name FROM categories WHERE id = ?");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch();
    return $category['name'] ?? 'Неизвестная категория';
}
?>
'''
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"✅ Создан улучшенный обработчик: {file_path}")

def main():
    print("🛠️ УЛУЧШЕНИЕ ФОРМЫ ДОБАВЛЕНИЯ ОБЪЯВЛЕНИЙ")
    print("=" * 60)
    
    create_improved_create_page()
    create_improved_processor()
    
    print("\n" + "=" * 60)
    print("🎯 ЧТО БЫЛО УЛУЧШЕНО:")
    print("✅ Группировка категорий по разделам")
    print("✅ Множественная загрузка фото (до 5 за раз)")
    print("✅ Drag & Drop для файлов")
    print("✅ Предпросмотр изображений перед загрузкой")
    print("✅ Удаление фото из предпросмотра")
    print("✅ Адаптивный дизайн согласно стилям сайта")
    print("✅ Улучшенная валидация и обработка ошибок")

if __name__ == "__main__":
    main()