<?php 
$page_title = "Лазаревское - Отдых и развлечения";
include 'includes/layout/header.php';
include 'includes/layout/utility-bar.php';
?>

<!-- Заголовок -->
<div class="header-title">
    <h1>Лазаревское</h1>
    <small>Здесь отдых и море круглый год</small>
</div>

<?php 
include 'includes/pages/main/nav-cards.php';
include 'includes/pages/main/recommended-places.php';
include 'includes/pages/main/popular-offers.php';
?>

<!-- Кнопка добавления -->
<div class="add-section">
    <button class="cta-button" onclick="window.location.href='pages/ads/create.php'">
        <i class="fas fa-plus-circle"></i> Добавить объявление
    </button>
</div>

<?php include 'includes/layout/footer.php'; ?>
