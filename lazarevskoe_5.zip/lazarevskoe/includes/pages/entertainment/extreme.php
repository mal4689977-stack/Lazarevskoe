<!-- Экстрим -->
<section class="cards-section" id="extreme">
    <h2 class="section-title">🧗 Экстрим</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Скалолазание">
                <div class="card-badge">Высота</div>
            </div>
            <div class="card-content">
                <h3>Скалолазание для начинающих</h3>
                <div class="card-meta">
                    <span class="price">2 200₽/сессия</span>
                    <span class="rating">★ 4.7</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 2 часа</li>
                    <li><i class="fas fa-helmet-safety"></i> Снаряжение</li>
                    <li><i class="fas fa-user-shield"></i> Инструктор</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Зиплайн">
                <div class="card-badge">Скорость</div>
            </div>
            <div class="card-content">
                <h3>Троллей (зиплайн) над ущельем</h3>
                <div class="card-meta">
                    <span class="price">1 000₽/спуск</span>
                    <span class="rating">★ 4.8</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 5-10 мин</li>
                    <li><i class="fas fa-mountain"></i> Высота 50м</li>
                    <li><i class="fas fa-video"></i> Видеосъемка</li>
                </ul>
            </div>
        </article>
    </div>
</section>