<!-- Водные развлечения -->
<section class="cards-section" id="water">
    <h2 class="section-title">🌊 Водные развлечения</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Бананы и плюшки">
                <div class="card-badge">Веселье</div>
            </div>
            <div class="card-content">
                <h3>Бананы, плюшки, ватрушки</h3>
                <div class="card-meta">
                    <span class="price">800₽/чел</span>
                    <span class="rating">★ 4.5</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 15-20 мин</li>
                    <li><i class="fas fa-users"></i> 2-6 чел</li>
                    <li><i class="fas fa-life-ring"></i> Спасатели</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Гидроциклы">
                <div class="card-badge">Скорость</div>
            </div>
            <div class="card-content">
                <h3>Аренда гидроциклов</h3>
                <div class="card-meta">
                    <span class="price">2 000₽/10 мин</span>
                    <span class="rating">★ 4.7</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 10-30 мин</li>
                    <li><i class="fas fa-user"></i> С инструктором</li>
                    <li><i class="fas fa-helmet-safety"></i> Экипировка</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Парашют">
                <div class="card-badge">Высота</div>
            </div>
            <div class="card-content">
                <h3>Парашют за катером</h3>
                <div class="card-meta">
                    <span class="price">1 500₽/полет</span>
                    <span class="rating">★ 4.9</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 10-15 мин</li>
                    <li><i class="fas fa-user"></i> Одиночный/парный</li>
                    <li><i class="fas fa-camera"></i> Видеосъемка</li>
                </ul>
            </div>
        </article>
    </div>
</section>