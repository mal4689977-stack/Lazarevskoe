<!-- Категории развлечений -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="#jeep" class="nav-card">
            <i class="fas fa-car"></i>
            <span>Джиппинг</span>
        </a>
        <a href="#horse" class="nav-card">
            <i class="fas fa-horse"></i>
            <span>Верховая езда</span>
        </a>
        <a href="#atv" class="nav-card">
            <i class="fas fa-motorcycle"></i>
            <span>Квадроциклы</span>
        </a>
        <a href="#water" class="nav-card">
            <i class="fas fa-water"></i>
            <span>Водные развлечения</span>
        </a>
        <a href="#hiking" class="nav-card">
            <i class="fas fa-hiking"></i>
            <span>Походы</span>
        </a>
        <a href="#extreme" class="nav-card">
            <i class="fas fa-mountain"></i>
            <span>Экстрим</span>
        </a>
    </div>
</section>