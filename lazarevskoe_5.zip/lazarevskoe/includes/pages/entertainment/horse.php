<!-- Верховая езда -->
<section class="cards-section" id="horse">
    <h2 class="section-title">🐎 Верховая езда</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Прогулка на лошадях">
                <div class="card-badge">Для начинающих</div>
            </div>
            <div class="card-content">
                <h3>Конная прогулка по лесу</h3>
                <div class="card-meta">
                    <span class="price">1 500₽/час</span>
                    <span class="rating">★ 4.7</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 1-2 часа</li>
                    <li><i class="fas fa-horse"></i> Опытный инструктор</li>
                    <li><i class="fas fa-child"></i> Для детей</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Конный тур">
                <div class="card-badge">Морской бриз</div>
            </div>
            <div class="card-content">
                <h3>Прогулка к морю верхом</h3>
                <div class="card-meta">
                    <span class="price">2 000₽/тур</span>
                    <span class="rating">★ 4.8</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 2.5 часа</li>
                    <li><i class="fas fa-camera"></i> Фотосессия</li>
                    <li><i class="fas fa-umbrella-beach"></i> Пляж</li>
                </ul>
            </div>
        </article>
    </div>
</section>