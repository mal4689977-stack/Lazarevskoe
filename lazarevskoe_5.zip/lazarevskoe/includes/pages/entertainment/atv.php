<!-- Квадроциклы -->
<section class="cards-section" id="atv">
    <h2 class="section-title">🏍️ Квадроциклы</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Квадроциклы по горам">
                <div class="card-badge">Адреналин</div>
            </div>
            <div class="card-content">
                <h3>Горный маршрут на квадроциклах</h3>
                <div class="card-meta">
                    <span class="price">2 500₽/30 мин</span>
                    <span class="rating">★ 4.6</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 30-60 мин</li>
                    <li><i class="fas fa-helmet-safety"></i> Экипировка</li>
                    <li><i class="fas fa-map"></i> 15 км маршрут</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Ночной квадроцикл">
                <div class="card-badge">Ночной тур</div>
            </div>
            <div class="card-content">
                <h3>Ночное сафари на квадроциклах</h3>
                <div class="card-meta">
                    <span class="price">3 000₽/тур</span>
                    <span class="rating">★ 4.9</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-moon"></i> После заката</li>
                    <li><i class="fas fa-camera"></i> Ночная съемка</li>
                    <li><i class="fas fa-users"></i> Групповой тур</li>
                </ul>
            </div>
        </article>
    </div>
</section>