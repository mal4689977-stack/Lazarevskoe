<!-- Джиппинг -->
<section class="cards-section" id="jeep">
    <h2 class="section-title">🚙 Джиппинг</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Джиппинг в горы">
                <div class="card-badge">Хит сезона</div>
            </div>
            <div class="card-content">
                <h3>Экстремальный джиппинг в горы</h3>
                <div class="card-meta">
                    <span class="price">3 500₽/тур</span>
                    <span class="rating">★ 4.8</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 3 часа</li>
                    <li><i class="fas fa-users"></i> До 6 чел</li>
                    <li><i class="fas fa-map-marker-alt"></i> 20 км</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Водопады на джипе">
                <div class="card-badge">Водопады</div>
            </div>
            <div class="card-content">
                <h3>Тур к горным водопадам</h3>
                <div class="card-meta">
                    <span class="price">2 800₽/тур</span>
                    <span class="rating">★ 4.9</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 2.5 часа</li>
                    <li><i class="fas fa-users"></i> До 4 чел</li>
                    <li><i class="fas fa-swimming-pool"></i> Купание</li>
                </ul>
            </div>
        </article>
    </div>
</section>