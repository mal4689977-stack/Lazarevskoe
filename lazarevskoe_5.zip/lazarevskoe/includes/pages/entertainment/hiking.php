<!-- Походы -->
<section class="cards-section" id="hiking">
    <h2 class="section-title">🥾 Походы и экскурсии</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Горный поход">
                <div class="card-badge">Природа</div>
            </div>
            <div class="card-content">
                <h3>Пеший поход в горы</h3>
                <div class="card-meta">
                    <span class="price">1 200₽/чел</span>
                    <span class="rating">★ 4.8</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 4 часа</li>
                    <li><i class="fas fa-mountain"></i> Виды на море</li>
                    <li><i class="fas fa-camera"></i> Фотостопы</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Экскурсия к водопаду">
                <div class="card-badge">Водопады</div>
            </div>
            <div class="card-content">
                <h3>Экскурсия "33 водопада"</h3>
                <div class="card-meta">
                    <span class="price">1 800₽/чел</span>
                    <span class="rating">★ 4.9</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> 5 часов</li>
                    <li><i class="fas fa-swimming-pool"></i> Купание</li>
                    <li><i class="fas fa-bus"></i> Трансфер включен</li>
                </ul>
            </div>
        </article>
    </div>
</section>