<!-- Основные карточки -->
<section class="cards-section">
    <h2 class="section-title">Популярные предложения</h2>
    
    <div class="cards-grid">
        <!-- Морские прогулки -->
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Морские прогулки">
                <div class="card-badge">Хит сезона</div>
            </div>
            <div class="card-content">
                <h3>Морские прогулки</h3>
                <div class="card-meta">
                    <span class="price">1 500₽/чел</span>
                    <span class="rating">★ 4.9</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-ship"></i> Яхта</li>
                    <li><i class="fas fa-clock"></i> 2 часа</li>
                    <li><i class="fas fa-users"></i> До 10 чел</li>
                </ul>
            </div>
        </article>

        <!-- Джиппинг -->
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Джиппинг">
                <div class="card-badge">Адреналин</div>
            </div>
            <div class="card-content">
                <h3>Джиппинг</h3>
                <div class="card-meta">
                    <span class="price">3 500₽/тур</span>
                    <span class="rating">★ 4.7</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-car"></i> Внедорожник</li>
                    <li><i class="fas fa-map"></i> 15 км маршрут</li>
                    <li><i class="fas fa-users"></i> До 6 чел</li>
                </ul>
            </div>
        </article>

        <!-- Походы в горы -->
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Походы в горы">
                <div class="card-badge">Природа</div>
            </div>
            <div class="card-content">
                <h3>Походы в горы</h3>
                <div class="card-meta">
                    <span class="price">2 000₽/чел</span>
                    <span class="rating">★ 4.8</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-mountain"></i> Горы</li>
                    <li><i class="fas fa-clock"></i> 4 часа</li>
                    <li><i class="fas fa-camera"></i> Фотосессия</li>
                </ul>
            </div>
        </article>
    </div>
</section>