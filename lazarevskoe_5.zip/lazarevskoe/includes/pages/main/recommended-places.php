<!-- Горизонтальные карточки -->
<section class="horizontal-cards-section">
    <h2 class="section-title">Рекомендуем посетить</h2>
    <div class="horizontal-cards-container">
        <div class="horizontal-cards-scroll">
            <!-- Карточка 1 -->
            <article class="horizontal-card">
                <div class="horizontal-card-image">
                    <img src="https://via.placeholder.com/300x200" alt="Парк">
                </div>
                <div class="horizontal-card-content">
                    <h3>Парк отдыха</h3>
                    <p>Уютное место для прогулок</p>
                </div>
            </article>

            <!-- Карточка 2 -->
            <article class="horizontal-card">
                <div class="horizontal-card-image">
                    <img src="https://via.placeholder.com/300x200" alt="Музей">
                </div>
                <div class="horizontal-card-content">
                    <h3>Музей истории</h3>
                    <p>Погрузитесь в прошлое</p>
                </div>
            </article>

            <!-- Карточка 3 -->
            <article class="horizontal-card">
                <div class="horizontal-card-image">
                    <img src="https://via.placeholder.com/300x200" alt="Кафе">
                </div>
                <div class="horizontal-card-content">
                    <h3>Кафе у моря</h3>
                    <p>Вкусная еда с видом на море</p>
                </div>
            </article>

            <!-- Карточка 4 -->
            <article class="horizontal-card">
                <div class="horizontal-card-image">
                    <img src="https://via.placeholder.com/300x200" alt="Рынок">
                </div>
                <div class="horizontal-card-content">
                    <h3>Местный рынок</h3>
                    <p>Свежие продукты и сувениры</p>
                </div>
            </article>

            <!-- Карточка 5 -->
            <article class="horizontal-card">
                <div class="horizontal-card-image">
                    <img src="https://via.placeholder.com/300x200" alt="Пляж">
                </div>
                <div class="horizontal-card-content">
                    <h3>Центральный пляж</h3>
                    <p>Чистый песок и море</p>
                </div>
            </article>
        </div>
    </div>
</section>