<!-- Навигационные карточки -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="/LAZAREVSKOE..../lazarevskoe/pages/categories/category_beaches.php" class="nav-card">
            <i class="fas fa-umbrella-beach"></i>
            <span>Пляжи</span>
        </a>
        
        <a href="/LAZAREVSKOE..../lazarevskoe/pages/categories/category_housing.php" class="nav-card">
            <i class="fas fa-bed"></i>
            <span>Жилье</span>
        </a>
        <a href="/LAZAREVSKOE..../lazarevskoe/pages/categories/category_active.php" class="nav-card">
            <i class="fas fa-hiking"></i>
            <span>Активный отдых</span>
        </a>
        <a href="/LAZAREVSKOE..../lazarevskoe/pages/categories/category_entertainment.php" class="nav-card">
            <i class="fas fa-binoculars"></i>
            <span>Развлечения</span>
        </a>
        <a href="/LAZAREVSKOE..../lazarevskoe/pages/categories/category_food.php" class="nav-card">
            <i class="fas fa-utensils"></i>
            <span>Рестораны</span>
        </a>
        <a href="/LAZAREVSKOE..../lazarevskoe/pages/categories/category_tours.php" class="nav-card">
            <i class="fas fa-bus"></i>
            <span>Экскурсии и туры</span>
        </a>
    </div>
</section>
