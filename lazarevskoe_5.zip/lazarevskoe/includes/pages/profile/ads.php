<!-- Мои объявления -->
<section class="section">
    <div class="section-header">
        <h2 class="section-title">Мои объявления</h2>
        <div class="section-actions">
            <button class="action-btn">Все</button>
            <button class="action-btn">Активные</button>
            <button class="action-btn">На модерации</button>
        </div>
    </div>

    <div class="ads-grid">
        <!-- Объявление 1 -->
        <div class="ad-card">
            <div class="ad-image">
                <img src="https://via.placeholder.com/300x200" alt="Квартира у моря">
            </div>
            <div class="ad-content">
                <div class="ad-title">Уютная квартира у моря</div>
                <div class="ad-price">5 000₽ / ночь</div>
                <span class="ad-status status-active">Активно</span>
                <div class="ad-actions">
                    <button class="ad-action-btn edit-btn">Редактировать</button>
                    <button class="ad-action-btn delete-btn">Удалить</button>
                </div>
            </div>
        </div>

        <!-- Объявление 2 -->
        <div class="ad-card">
            <div class="ad-image">
                <img src="https://via.placeholder.com/300x200" alt="Экскурсия">
            </div>
            <div class="ad-content">
                <div class="ad-title">Экскурсия по горам</div>
                <div class="ad-price">2 000₽ / чел</div>
                <span class="ad-status status-moderate">На модерации</span>
                <div class="ad-actions">
                    <button class="ad-action-btn edit-btn">Редактировать</button>
                    <button class="ad-action-btn delete-btn">Удалить</button>
                </div>
            </div>
        </div>

        <!-- Объявление 3 -->
        <div class="ad-card">
            <div class="ad-image">
                <img src="https://via.placeholder.com/300x200" alt="Лодка">
            </div>
            <div class="ad-content">
                <div class="ad-title">Прогулка на яхте</div>
                <div class="ad-price">1 500₽ / чел</div>
                <span class="ad-status status-active">Активно</span>
                <div class="ad-actions">
                    <button class="ad-action-btn edit-btn">Редактировать</button>
                    <button class="ad-action-btn delete-btn">Удалить</button>
                </div>
            </div>
        </div>
    </div>
</section>