<!-- Боковая панель - НА МОБИЛЬНЫХ БУДЕТ СВЕРХУ -->
<div class="profile-sidebar">
    <div class="profile-avatar">
        <img src="https://via.placeholder.com/150" alt="Аватар">
        <div class="profile-name">Иван Иванов
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>
        <div class="profile-location">Лазаревское, Сочи
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>
    
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>

    <div class="profile-stats">
        <div class="stat-item">
            <span class="stat-number">12</span>
            <span class="stat-label">Объявления</span>
        
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>
        <div class="stat-item">
            <span class="stat-number">47</span>
            <span class="stat-label">Избранное</span>
        
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>
        <div class="stat-item">
            <span class="stat-number">4.8</span>
            <span class="stat-label">Рейтинг</span>
        
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>
    
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>

    <div class="profile-actions">
        <button class="profile-btn">
            <i class="fas fa-edit"></i> Редактировать профиль
        </button>
        <button class="profile-btn">
            <i class="fas fa-cog"></i> Настройки
        </button>
        <button class="profile-btn secondary">
            <i class="fas fa-plus-circle"></i> Добавить объявление
        </button>
    
        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>

        <a href="pages/auth/logout.php" class="profile-btn secondary" style="background: var(--error); color: white; margin-top: 20px;">
            <i class="fas fa-sign-out-alt"></i> Выйти
        </a>
    
    </div>