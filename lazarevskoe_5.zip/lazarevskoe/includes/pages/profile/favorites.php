<!-- Избранное -->
<section class="section">
    <div class="section-header">
        <h2 class="section-title">Избранное</h2>
        <div class="section-actions">
            <button class="action-btn">Все</button>
            <button class="action-btn">Пляжи</button>
            <button class="action-btn">Развлечения</button>
        </div>
    </div>

    <div class="favorites-grid">
        <!-- Избранное 1 -->
        <div class="favorite-card">
            <div class="favorite-image">
                <img src="https://via.placeholder.com/250x150" alt="Парк">
            </div>
            <div class="favorite-content">
                <div class="favorite-title">Парк отдыха</div>
                <div class="favorite-location">ул. Центральная, 10</div>
                <button class="remove-btn">Удалить</button>
            </div>
        </div>

        <!-- Избранное 2 -->
        <div class="favorite-card">
            <div class="favorite-image">
                <img src="https://via.placeholder.com/250x150" alt="Музей">
            </div>
            <div class="favorite-content">
                <div class="favorite-title">Музей истории</div>
                <div class="favorite-location">ул. Ленина, 5</div>
                <button class="remove-btn">Удалить</button>
            </div>
        </div>

        <!-- Избранное 3 -->
        <div class="favorite-card">
            <div class="favorite-image">
                <img src="https://via.placeholder.com/250x150" alt="Кафе">
            </div>
            <div class="favorite-content">
                <div class="favorite-title">Кафе у моря</div>
                <div class="favorite-location">Набережная, 15</div>
                <button class="remove-btn">Удалить</button>
            </div>
        </div>
    </div>
</section>