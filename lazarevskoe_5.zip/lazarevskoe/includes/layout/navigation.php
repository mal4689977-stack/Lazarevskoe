<!-- Нижняя навигация -->
<div class="nav-cards-grid-bottom">
    <button class="nav-card-bottom" onclick="window.location.href='/LAZAREVSKOE..../lazarevskoe/index.php'">
        <i class="fas fa-home"></i>
        <span>Главная</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='/LAZAREVSKOE..../lazarevskoe/pages/categories/category_housing.php'">
        <i class="fas fa-bed"></i>
        <span>Жилье</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='/LAZAREVSKOE..../lazarevskoe/profile.php'">
        <i class="fas fa-user"></i>
        <span>Профиль</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='/LAZAREVSKOE..../lazarevskoe/pages/categories/category_active.php'">
        <i class="fas fa-hiking"></i>
        <span>Активный_отдых</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='/LAZAREVSKOE..../lazarevskoe/pages/ads/create.php'">
        <i class="fas fa-plus"></i>
        <span>Добавить</span>
    </button>
</div>