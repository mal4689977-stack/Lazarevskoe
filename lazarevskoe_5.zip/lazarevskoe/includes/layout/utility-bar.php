<!-- Верхняя панель -->
<div class="utility-bar">
    <div class="logo-text">
        <span class="handwritten">Лазаревское - online</span>
    </div>
    <div class="weather-block">
        <span class="weather-label">Погода: ☀️ +28°C 🌊 +24°C</span>
    </div>
</div>