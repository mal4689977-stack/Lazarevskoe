        <!-- Футер -->
        <footer class="main-footer">
            <div class="footer-content">
                <p>© 2024 Отдых в Лазаревском</p>
                <div class="footer-links">
                    <a href="#">О проекте</a>
                    <a href="#">Контакты</a>
                    <a href="#">Помощь</a>
                </div>
                <div class="social-links">
                    <a href="#"><i class="fab fa-vk"></i></a>
                    <a href="#"><i class="fab fa-telegram"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </footer>

        <?php include 'navigation.php'; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Анимация карточек
            const cards = document.querySelectorAll('.card, .nav-card, .horizontal-card, .ad-card, .favorite-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'all 0.6s ease';
                
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });

            // Плавная прокрутка к якорям (для развлечений)
            document.querySelectorAll('.nav-card[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // Обработка кликов по карточкам
            document.querySelectorAll('.card, .horizontal-card').forEach(card => {
                card.addEventListener('click', function() {
                    const title = this.querySelector('h3').textContent;
                    alert('Подробнее о: ' + title + '\n\nФункция бронирования скоро будет доступна!');
                });
            });

            // Обработка кнопок профиля
            document.querySelectorAll('.ad-action-btn, .remove-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    alert('Действие выполнено!');
                });
            });

            // Обработка кнопок профиля
            document.querySelectorAll('.profile-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const text = this.querySelector('i').className.includes('edit') ? 
                        'Редактирование профиля' : 
                        this.querySelector('i').className.includes('cog') ? 
                        'Настройки' : 'Добавление объявления';
                    alert(text + ' - функция в разработке!');
                });
            });
        });
    </script>
</body>
</html>
