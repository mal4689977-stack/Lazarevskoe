<?php
session_start();
require_once 'config/database.php';

$page_title = "Профиль - Лазаревское";

// Подключаемся к базе данных
$database = new Database();
$db = $database->getConnection();

// Если пользователь не авторизован
if (!isset($_SESSION['user_id'])) {
    include 'includes/layout/header.php';
    include 'includes/layout/utility-bar.php';
    ?>
    
    <div class="page-container">
        <div class="auth-container">
            <div class="auth-card">
                <div class="auth-icon">🔐</div>
                <h2 class="auth-title">Доступ к профилю</h2>
                <p class="auth-text">Войдите в аккаунт чтобы управлять своими объявлениями</p>
                
                <div class="auth-buttons">
                    <a href="pages/auth/login.php" class="cta-button mobile-button">
                        <i class="fas fa-sign-in-alt"></i> Войти в аккаунт
                    </a>
                    
                    <a href="pages/auth/register.php" class="profile-btn secondary mobile-button">
                        <i class="fas fa-user-plus"></i> Зарегистрироваться
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php
    include 'includes/layout/footer.php';
    exit;
}

// Получаем данные пользователя
$user_id = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT name, email, phone FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Получаем статистику пользователя
$ads_count = $db->query("SELECT COUNT(*) FROM ads WHERE user_id = $user_id")->fetchColumn();
$favorites_count = $db->query("SELECT COUNT(*) FROM favorites WHERE user_id = $user_id")->fetchColumn();

// Обработка добавления в избранное
if (isset($_POST['add_to_favorites'])) {
    $ad_id = $_POST['ad_id'];
    $stmt = $db->prepare("INSERT INTO favorites (user_id, ad_id) VALUES (?, ?)");
    $stmt->execute([$user_id, $ad_id]);
}

// Обработка удаления из избранного
if (isset($_POST['remove_favorite'])) {
    $favorite_id = $_POST['favorite_id'];
    $stmt = $db->prepare("DELETE FROM favorites WHERE id = ? AND user_id = ?");
    $stmt->execute([$favorite_id, $user_id]);
}

// Обработка удаления объявления
if (isset($_POST['delete_ad'])) {
    $ad_id = $_POST['ad_id'];
    $stmt = $db->prepare("DELETE FROM ads WHERE id = ? AND user_id = ?");
    $stmt->execute([$ad_id, $user_id]);
}

// Получаем объявления пользователя
$user_ads = $db->query("
    SELECT a.*, c.name as category_name 
    FROM ads a 
    LEFT JOIN categories c ON a.category_id = c.id 
    WHERE a.user_id = $user_id 
    ORDER BY a.created_at DESC
")->fetchAll();

// Получаем избранное пользователя
$user_favorites = $db->query("
    SELECT f.*, a.title, a.price, a.location, a.images, c.name as category_name
    FROM favorites f
    LEFT JOIN ads a ON f.ad_id = a.id
    LEFT JOIN categories c ON a.category_id = c.id
    WHERE f.user_id = $user_id
    ORDER BY f.created_at DESC
")->fetchAll();

// Красивый профиль для авторизованных
include 'includes/layout/header.php';
include 'includes/layout/utility-bar.php';
?>

<div class="page-container">
    <!-- Заголовок профиля -->
    <div class="header-title">
        <h1>Мой профиль</h1>
        <small>Управляйте своими объявлениями и настройками</small>
    </div>

    <!-- Мобильное меню (только для мобильных) -->
    <div class="mobile-profile-nav">
        <button class="mobile-nav-btn active" data-tab="ads">
            <i class="fas fa-th-list"></i>
            <span>Объявления</span>
        </button>
        <button class="mobile-nav-btn" data-tab="favorites">
            <i class="fas fa-heart"></i>
            <span>Избранное</span>
        </button>
        <button class="mobile-nav-btn" data-tab="settings">
            <i class="fas fa-cog"></i>
            <span>Настройки</span>
        </button>
    </div>

    <!-- Основной контент -->
    <div class="profile-layout">
        <!-- Боковая панель (скрывается на мобильных) -->
        <div class="profile-sidebar">
            <div class="user-card">
                <div class="user-avatar">
                    <img src="https://via.placeholder.com/120" alt="Аватар">
                    <div class="online-dot"></div>
                </div>
                <div class="user-info">
                    <h3><?php echo htmlspecialchars($user['name'] ?? 'Пользователь'); ?></h3>
                    <p class="user-location">📍 Лазаревское, Сочи</p>
                </div>
                <div class="user-stats">
                    <div class="stat">
                        <span class="number"><?php echo $ads_count; ?></span>
                        <span class="label">Объявления</span>
                    </div>
                    <div class="stat">
                        <span class="number"><?php echo $favorites_count; ?></span>
                        <span class="label">Избранное</span>
                    </div>
                    <div class="stat">
                        <span class="number">4.8</span>
                        <span class="label">Рейтинг</span>
                    </div>
                </div>
            </div>

            <div class="sidebar-menu">
                <a href="#" class="menu-item active" data-tab="ads">
                    <i class="fas fa-th-list"></i>
                    <span>Мои объявления</span>
                    <span class="badge"><?php echo $ads_count; ?></span>
                </a>
                <a href="#" class="menu-item" data-tab="favorites">
                    <i class="fas fa-heart"></i>
                    <span>Избранное</span>
                    <span class="badge"><?php echo $favorites_count; ?></span>
                </a>
                <a href="#" class="menu-item" data-tab="settings">
                    <i class="fas fa-cog"></i>
                    <span>Настройки</span>
                </a>
                <a href="pages/ads/create.php" class="menu-item add-button">
                    <i class="fas fa-plus-circle"></i>
                    <span>Добавить объявление</span>
                </a>
            </div>

            <div class="sidebar-actions">
                <a href="pages/auth/logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Выйти из аккаунта
                </a>
            </div>
        </div>

        <!-- Основная секция -->
        <div class="profile-main">
            <div class="mobile-user-card">
                <div class="mobile-user-info">
                    <div class="mobile-avatar">
                        <img src="https://via.placeholder.com/60" alt="Аватар">
                    </div>
                    <div>
                        <h3><?php echo htmlspecialchars($user['name'] ?? 'Пользователь'); ?></h3>
                        <p>Лазаревское, Сочи</p>
                    </div>
                </div>
                <div class="mobile-stats">
                    <div class="stat">
                        <span class="number"><?php echo $ads_count; ?></span>
                        <span class="label">Объявления</span>
                    </div>
                    <div class="stat">
                        <span class="number"><?php echo $favorites_count; ?></span>
                        <span class="label">Избранное</span>
                    </div>
                </div>
            </div>

            <!-- Контент вкладок -->
            <div class="tab-content active" id="ads-tab">
                <div class="section-header">
                    <h2>Мои объявления</h2>
                    <div class="section-actions">
                        <button class="action-btn active">Все</button>
                        <button class="action-btn">Активные</button>
                        <button class="action-btn">На модерации</button>
                    </div>
                </div>

                <?php if (empty($user_ads)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">📝</div>
                        <h3>У вас пока нет объявлений</h3>
                        <p>Создайте первое объявление и начните получать заявки</p>
                        <a href="pages/ads/create.php" class="cta-button">
                            <i class="fas fa-plus-circle"></i> Создать объявление
                        </a>
                    </div>
                <?php else: ?>
                    <div class="ads-grid">
                        <?php foreach($user_ads as $ad): 
                            $images = json_decode($ad['images'] ?? '[]', true);
                            $first_image = !empty($images) ? '../uploads/ads/' . $images[0] : 'https://via.placeholder.com/300x200';
                        ?>
                            <div class="ad-card">
                                <div class="ad-image">
                                    <img src="<?php echo $first_image; ?>" alt="<?php echo htmlspecialchars($ad['title']); ?>">
                                    <div class="ad-status status-<?php echo $ad['status']; ?>">
                                        <?php 
                                        $status_text = [
                                            'active' => 'Активно',
                                            'moderation' => 'На модерации',
                                            'rejected' => 'Отклонено'
                                        ];
                                        echo $status_text[$ad['status']] ?? $ad['status'];
                                        ?>
                                    </div>
                                </div>
                                <div class="ad-content">
                                    <div class="ad-category"><?php echo htmlspecialchars($ad['category_name']); ?></div>
                                    <div class="ad-title"><?php echo htmlspecialchars($ad['title']); ?></div>
                                    <div class="ad-price"><?php echo number_format($ad['price'], 0, '', ' '); ?>₽</div>
                                    <div class="ad-location">📍 <?php echo htmlspecialchars($ad['location'] ?? ''); ?></div>
                                    
                                    <form method="POST" class="ad-actions">
                                        <input type="hidden" name="ad_id" value="<?php echo $ad['id']; ?>">
                                        <button type="submit" name="delete_ad" class="ad-action-btn delete-btn" 
                                                onclick="return confirm('Удалить это объявление?')">
                                            <i class="fas fa-trash"></i> Удалить
                                        </button>
                                        <a href="pages/ads/edit.php?id=<?php echo $ad['id']; ?>" class="ad-action-btn edit-btn">
                                            <i class="fas fa-edit"></i> Редактировать
                                        </a>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
            
            </div>
            
            <div class="tab-content" id="favorites-tab">
                <div class="section-header">
                    <h2>Избранное</h2>
                    <div class="section-actions">
                        <button class="action-btn active">Все</button>
                        <button class="action-btn">Жилье</button>
                        <button class="action-btn">Развлечения</button>
                    </div>
                </div>

                <?php if (empty($user_favorites)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">❤️</div>
                        <h3>В избранном пока пусто</h3>
                        <p>Добавляйте понравившиеся объявления в избранное</p>
                        <a href="../index.php" class="cta-button">
                            <i class="fas fa-search"></i> Найти объявления
                        </a>
                    </div>
                <?php else: ?>
                    <div class="favorites-grid">
                        <?php foreach($user_favorites as $favorite): 
                            $images = json_decode($favorite['images'] ?? '[]', true);
                            $first_image = !empty($images) ? '../uploads/ads/' . $images[0] : 'https://via.placeholder.com/250x150';
                        ?>
                            <div class="favorite-card">
                                <div class="favorite-image">
                                    <img src="<?php echo $first_image; ?>" alt="<?php echo htmlspecialchars($favorite['title']); ?>">
                                </div>
                                <div class="favorite-content">
                                    <div class="favorite-category"><?php echo htmlspecialchars($favorite['category_name']); ?></div>
                                    <div class="favorite-title"><?php echo htmlspecialchars($favorite['title']); ?></div>
                                    <div class="favorite-price"><?php echo number_format($favorite['price'], 0, '', ' '); ?>₽</div>
                                    <div class="favorite-location">📍 <?php echo htmlspecialchars($favorite['location']); ?></div>
                                    
                                    <form method="POST" class="favorite-actions">
                                        <input type="hidden" name="favorite_id" value="<?php echo $favorite['id']; ?>">
                                        <button type="submit" name="remove_favorite" class="remove-btn">
                                            <i class="fas fa-times"></i> Удалить
                                        </button>
                                        <a href="../pages/ads/view.php?id=<?php echo $favorite['ad_id']; ?>" class="view-btn">
                                            <i class="fas fa-eye"></i> Посмотреть
                                        </a>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="tab-content" id="settings-tab">
                <div class="settings-section">
                    <h3>Настройки профиля</h3>
                    <div class="settings-list">
                        <div class="setting-item">
                            <i class="fas fa-user-edit"></i>
                            <span>Редактировать профиль</span>
                            <i class="fas fa-chevron-right"></i>
                        </div>
                        <div class="setting-item">
                            <i class="fas fa-bell"></i>
                            <span>Уведомления</span>
                            <i class="fas fa-chevron-right"></i>
                        </div>
                        <div class="setting-item">
                            <i class="fas fa-shield-alt"></i>
                            <span>Безопасность</span>
                            <i class="fas fa-chevron-right"></i>
                        </div>
                        <a href="pages/auth/logout.php" class="setting-item logout-setting">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Выйти из аккаунта</span>
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </div>
                </div>

                <!-- Форма редактирования профиля -->
                <div class="edit-profile-section">
                    <h3>Редактировать профиль</h3>
                    <form method="POST" class="profile-form">
                        <div class="form-group">
                            <label>Имя:</label>
                            <input type="text" name="name" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Телефон:</label>
                            <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        <button type="submit" name="update_profile" class="cta-button">
                            <i class="fas fa-save"></i> Сохранить изменения
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Переключение вкладок
    const tabBtns = document.querySelectorAll('.mobile-nav-btn, .menu-item');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (this.getAttribute('href') === '#') {
                e.preventDefault();
            }
            
            const tabId = this.getAttribute('data-tab');
            
            // Убираем активные классы
            tabBtns.forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Добавляем активные классы
            this.classList.add('active');
            if (this.classList.contains('menu-item')) {
                const mobileBtn = document.querySelector(`.mobile-nav-btn[data-tab="${tabId}"]`);
                if (mobileBtn) mobileBtn.classList.add('active');
            }
            document.getElementById(tabId + '-tab').classList.add('active');
        });
    });
    
    // Анимация появления
    const animateElements = () => {
        const elements = document.querySelectorAll('.profile-layout > *');
        elements.forEach((el, index) => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'all 0.5s ease';
            
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 150);
        });
    };
    
    animateElements();
});
</script>



<?php include 'includes/layout/footer.php'; ?>
