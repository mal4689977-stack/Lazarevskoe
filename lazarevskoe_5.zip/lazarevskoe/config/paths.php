<?php
// config/paths.php - автоматическое определение базового URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$base_url = $protocol . "://" . $host . "/";

// Определяем константу BASE_URL
define('BASE_URL', $base_url);

// Также можно определить базовый путь для файловых операций
define('BASE_PATH', realpath(dirname(__FILE__) . '/../'));

// Для отладки (можно удалить после проверки)
// echo "<!-- BASE_URL: " . BASE_URL . " -->";
// echo "<!-- BASE_PATH: " . BASE_PATH . " -->";
?>