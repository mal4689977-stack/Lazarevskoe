<?php
define('SITE_NAME', 'Лазаревское - online');
define('SITE_URL', 'http://localhost:8080');
define('UPLOAD_PATH', 'uploads/');
?>