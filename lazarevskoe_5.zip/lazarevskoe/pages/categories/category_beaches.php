<?php
include '../../config/paths.php';

$page_title = "🌊 Пляжи и море - Лазаревское";
include '../../includes/layout/header.php';
include '../../includes/layout/utility-bar.php';
?>

<style>
@import url('../../assets/css/style.css');
</style>

<div class="header-title">
    <h1>🌊 Пляжи и море</h1>
    <small>Выберите подкатегорию для просмотра объявлений</small>
</div>

<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <div class="empty-state">
            <h3>Объявления на пляжах</h3>
            <p>Здесь будут отображаться все объявления связанные с пляжным отдыхом</p>
        </div>
    </div>
</section>

<div class="add-section">
    <button class="cta-button" onclick="window.location.href='<?php echo BASE_URL; ?>LAZAREVSKOE..../lazarevskoe/pages/ads/create.php'">
        <i class="fas fa-plus-circle"></i> Добавить объявление
    </button>
</div>

<?php include '../../includes/layout/footer.php'; ?>
