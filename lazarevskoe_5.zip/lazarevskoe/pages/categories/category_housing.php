<?php
include '../../config/paths.php';
include '../../config/database.php';

$page_title = "🏠 Жилье - Лазаревское";
include '../../includes/layout/header.php';
include '../../includes/layout/utility-bar.php';
?>

<style>
@import url('../../assets/css/style.css');
</style>

<div class="header-title">
    <h1>🏠 Жилье</h1>
    <small>Выберите подкатегорию для просмотра объявлений</small>
</div>

<!-- Верхние иконки-карточки -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="housing/hotels.php" class="nav-card">
            <i class="fas fa-hotel"></i>
            <span>Отели и гостиницы</span>
        </a>
        <a href="housing/guest_houses.php" class="nav-card">
            <i class="fas fa-house-user"></i>
            <span>Гостевые дома</span>
        </a>
        <a href="housing/apartments.php" class="nav-card">
            <i class="fas fa-building"></i>
            <span>Квартиры посуточно</span>
        </a>
        <a href="housing/camping.php" class="nav-card">
            <i class="fas fa-campground"></i>
            <span>Турбазы и кемпинги</span>
        </a>
        <a href="housing/cottages.php" class="nav-card">
            <i class="fas fa-home"></i>
            <span>Дома и коттеджи</span>
        </a>
        <a href="housing/private_rooms.php" class="nav-card">
            <i class="fas fa-bed"></i>
            <span>Частный сектор</span>
        </a>
    </div>
</section>

<!-- Новые объявления из БД -->
<section class="cards-section">
    <h2 class="section-title">🏆 Новые предложения по жилью</h2>
    
    <div class="cards-grid">
        <?php
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            // Получаем ID категории "Жилье" и её подкатегорий
            $category_query = $db->query("
                SELECT id FROM categories 
                WHERE name LIKE '%жилье%' OR parent_id IN (
                    SELECT id FROM categories WHERE name LIKE '%жилье%'
                )
            ")->fetchAll();
            
            $category_ids = array_column($category_query, 'id');
            
            if (empty($category_ids)) {
                echo '<div class="empty-state">
                    <h3>Категории жилья не найдены</h3>
                    <p>Обратитесь к администратору</p>
                </div>';
            } else {
                $placeholders = str_repeat('?,', count($category_ids) - 1) . '?';
                
                // Получаем 10 последних объявлений по жилью
                $ads_query = $db->prepare("
                    SELECT a.*, u.name as user_name, c.name as category_name 
                    FROM ads a 
                    LEFT JOIN users u ON a.user_id = u.id 
                    LEFT JOIN categories c ON a.category_id = c.id 
                    WHERE a.category_id IN ($placeholders)
                    ORDER BY a.created_at DESC 
                    LIMIT 10
                ");
                
                $ads_query->execute($category_ids);
                $ads = $ads_query->fetchAll();
                
                if (empty($ads)) {
                    echo '<div class="empty-state">
                        <h3>Пока нет объявлений по жилью</h3>
                        <p>Будьте первым, кто добавит объявление!</p>
                    </div>';
                } else {
                    foreach($ads as $ad) {
                        $images = json_decode($ad['images'] ?? '[]', true);
                        $first_image = !empty($images) ? '../../uploads/ads/' . $images[0] : 'https://via.placeholder.com/400x250';
                        
                        echo '
                        <article class="card">
                            <div class="card-image">
                                <img src="' . $first_image . '" alt="' . htmlspecialchars($ad['title']) . '">
                                <div class="card-badge">Новинка</div>
                            </div>
                            <div class="card-content">
                                <h3>' . htmlspecialchars($ad['title']) . '</h3>
                                <div class="card-meta">
                                    <span class="price">' . number_format($ad['price'], 0, '', ' ') . '₽</span>
                                    <span class="rating">★ 4.8</span>
                                </div>
                                <p class="card-description">' . htmlspecialchars(substr($ad['description'], 0, 100)) . '...</p>
                                <ul class="card-features">
                                    <li><i class="fas fa-user"></i> ' . htmlspecialchars($ad['user_name']) . '</li>
                                    <li><i class="fas fa-tag"></i> ' . htmlspecialchars($ad['category_name']) . '</li>
                                    <li><i class="fas fa-clock"></i> ' . date('d.m.Y', strtotime($ad['created_at'])) . '</li>
                                </ul>
                            </div>
                        </article>';
                    }
                }
            }
        } catch (Exception $e) {
            echo '<div class="error-message">Ошибка загрузки объявлений: ' . $e->getMessage() . '</div>';
        }
        ?>
    </div>
</section>

<div class="add-section">
    <button class="cta-button" onclick="window.location.href='<?php echo BASE_URL; ?>LAZAREVSKOE..../lazarevskoe/pages/ads/create.php'">
        <i class="fas fa-plus-circle"></i> Добавить объявление
    </button>
</div>


<?php include '../../includes/layout/footer.php'; ?>