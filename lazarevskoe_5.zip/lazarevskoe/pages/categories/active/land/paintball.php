<?php
include '../../../../config/paths.php';

$page_title = "Пейнтбол - Лазаревское";
include '../../../../includes/layout/header.php';
include '../../../../includes/layout/utility-bar.php';
?>

<style>
@import url('../../../../assets/css/style.css');
</style>

<div class="header-title">
    <h1><i class="fas fa-bullseye"></i> Пейнтбол</h1>
    <small>Объявления в категории "Пейнтбол"</small>
</div>

<div class="ads-container">
    <div class="empty-state">
        <h3>Пока нет объявлений</h3>
        <p>Будьте первым, кто добавит объявление в эту категорию!</p>
        <button class="cta-button" onclick="window.location.href='<?php echo BASE_URL; ?>pages/ads/create.php'">
            <i class="fas fa-plus-circle"></i> Добавить объявление
        </button>
    </div>
</div>

<div class="back-section">
    <a href="../group_land.php" class="back-button">← Назад к категориям</a>
</div>

<?php include '../../../../includes/layout/footer.php'; ?>
