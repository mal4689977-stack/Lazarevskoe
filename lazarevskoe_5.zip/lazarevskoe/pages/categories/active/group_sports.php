<?php
include '../../../config/paths.php';

$page_title = "Спортивный отдых - Лазаревское";
include '../../../includes/layout/header.php';
include '../../../includes/layout/utility-bar.php';
?>

<style>
@import url('../../../assets/css/style.css');
</style>

<div class="header-title">
    <h1>🎯 Спортивный отдых</h1>
    <small>Выберите вид активного отдыха</small>
</div>

<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="sports/sports_activities.php" class="nav-card">
            <i class="fas fa-futbol"></i>
            <span>Спортивные мероприятия</span>
        </a>
    </div>
</section>

<div class="add-section">
    <button class="cta-button" onclick="window.location.href='<?php echo BASE_URL; ?>pages/ads/create.php'">
        <i class="fas fa-plus-circle"></i> Добавить объявление
    </button>
</div>

<?php include '../../../includes/layout/footer.php'; ?>
