<?php
include '../../../config/paths.php';

$page_title = "Воздушный отдых - Лазаревское";
include '../../../includes/layout/header.php';
include '../../../includes/layout/utility-bar.php';
?>

<style>
@import url('../../../assets/css/style.css');
</style>

<div class="header-title">
    <h1>🪂 Воздушный отдых</h1>
    <small>Выберите вид активного отдыха</small>
</div>

<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="air/parachuting.php" class="nav-card">
            <i class="fas fa-parachute-box"></i>
            <span>Парашюты и парапланы</span>
        </a>
    </div>
</section>

<div class="add-section">
    <button class="cta-button" onclick="window.location.href='<?php echo BASE_URL; ?>pages/ads/create.php'">
        <i class="fas fa-plus-circle"></i> Добавить объявление
    </button>
</div>

<?php include '../../../includes/layout/footer.php'; ?>
