<?php
include '../../../config/paths.php';
include '../../../config/database.php';

$page_title = "🌊 Морской отдых - Лазаревское";
include '../../../includes/layout/header.php';
include '../../../includes/layout/utility-bar.php';
?>

<style>
@import url('../../../assets/css/style.css');
</style>

<div class="header-title">
    <h1>🌊 Морской отдых</h1>
    <small>Выберите вид морского активного отдыха</small>
</div>

<!-- Верхние иконки-карточки (ПОДКАТЕГОРИИ) -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="sea/jet_skis.php" class="nav-card">
            <i class="fas fa-ship"></i>
            <span>Гидроциклы</span>
        </a>
        <a href="sea/catamarans.php" class="nav-card">
            <i class="fas fa-sailboat"></i>
            <span>Катамараны</span>
        </a>
        <a href="sea/boat_tours.php" class="nav-card">
            <i class="fas fa-ship"></i>
            <span>Прогулки на катерах</span>
        </a>
        <a href="sea/diving.php" class="nav-card">
            <i class="fas fa-mask"></i>
            <span>Дайвинг</span>
        </a>
        <a href="sea/water_attractions.php" class="nav-card">
            <i class="fas fa-tent"></i>
            <span>Водные аттракционы</span>
        </a>
        <a href="sea/fishing.php" class="nav-card">
            <i class="fas fa-fish"></i>
            <span>Морская рыбалка</span>
        </a>
    </div>
</section>

<!-- Новые объявления из БД -->
<section class="cards-section">
    <h2 class="section-title">⛵ Новые объявления</h2>
    
    <div class="cards-grid">
        <?php
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            // Получаем ID подкатегорий морского отдыха
            $category_query = $db->query("
                SELECT id FROM categories 
                WHERE name IN ('гидроциклы', 'катамараны', 'прогулки на катерах', 'дайвинг', 'водные аттракционы', 'морская рыбалка')
                OR parent_id IN (
                    SELECT id FROM categories WHERE name = 'морской отдых'
                )
            ")->fetchAll();
            
            $category_ids = array_column($category_query, 'id');
            
            if (empty($category_ids)) {
                echo '<div class="empty-ads-state">
                    <div class="empty-ads-icon">📝</div>
                    <h3>Объявления не найдены</h3>
                </div>';
            } else {
                $placeholders = str_repeat('?,', count($category_ids) - 1) . '?';
                
                // Получаем 10 последних объявлений по морскому отдыху
                $ads_query = $db->prepare("
                    SELECT a.*, u.name as user_name, c.name as category_name 
                    FROM ads a 
                    LEFT JOIN users u ON a.user_id = u.id 
                    LEFT JOIN categories c ON a.category_id = c.id 
                    WHERE a.category_id IN ($placeholders)
                    ORDER BY a.created_at DESC 
                    LIMIT 10
                ");
                
                $ads_query->execute($category_ids);
                $ads = $ads_query->fetchAll();
                
                if (!empty($ads)) {
                    foreach($ads as $ad) {
                        $images = json_decode($ad['images'] ?? '[]', true);
                        $first_image = !empty($images) ? '../../../uploads/ads/' . $images[0] : 'https://via.placeholder.com/400x250';
                        
                        echo '
                        <article class="card">
                            <div class="card-image">
                                <img src="' . $first_image . '" alt="' . htmlspecialchars($ad['title']) . '">
                                <div class="card-badge">Море</div>
                            </div>
                            <div class="card-content">
                                <h3>' . htmlspecialchars($ad['title']) . '</h3>
                                <div class="card-meta">
                                    <span class="price">' . number_format($ad['price'], 0, '', ' ') . '₽</span>
                                    <span class="rating">★ 4.7</span>
                                </div>
                                <p class="card-description">' . htmlspecialchars(substr($ad['description'], 0, 100)) . '...</p>
                                <ul class="card-features">
                                    <li><i class="fas fa-user"></i> ' . htmlspecialchars($ad['user_name']) . '</li>
                                    <li><i class="fas fa-tag"></i> ' . htmlspecialchars($ad['category_name']) . '</li>
                                    <li><i class="fas fa-clock"></i> ' . date('d.m.Y', strtotime($ad['created_at'])) . '</li>
                                </ul>
                            </div>
                        </article>';
                    }
                }
                // Если объявлений нет - ничего не выводим, только кнопка ниже
            }
        } catch (Exception $e) {
            echo '<div class="error-message">Ошибка загрузки объявлений: ' . $e->getMessage() . '</div>';
        }
        ?>
    </div>
</section>

<!-- Кнопка добавления ВСЕГДА показывается -->
<div class="add-section">
    <button class="cta-button" onclick="window.location.href='/LAZAREVSKOE..../lazarevskoe/pages/ads/create.php'">
        <i class="fas fa-plus-circle"></i> Добавить объявление
    </button>
</div>

<?php include '../../../includes/layout/footer.php'; ?>    