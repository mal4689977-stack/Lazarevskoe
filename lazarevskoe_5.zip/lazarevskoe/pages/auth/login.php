<?php
session_start();
require_once '../../config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    if (!empty($email) && !empty($password)) {
        $database = new Database();
        $db = $database->getConnection();
        
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            
            header('Location: ../../index.php');
            exit;
        } else {
            $error = "Неверный email или пароль";
        }
    } else {
        $error = "Заполните все поля";
    }
}

$page_title = "Вход - Лазаревское";
include '../../includes/layout/header-auth.php';
include '../../includes/layout/utility-bar.php';
?>

<div class="page-container">
    <div style="max-width: 400px; margin: 0 auto; padding: 40px 20px;">
        <div style="background: var(--light); padding: 40px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            
            <!-- Заголовок с иконкой -->
            <div style="text-align: center; margin-bottom: 30px;">
                <div style="font-size: 48px; color: var(--primary); margin-bottom: 15px;">🔐</div>
                <h2 style="color: var(--primary); margin-bottom: 10px;">Вход в аккаунт</h2>
                <p style="color: var(--secondary);">Введите ваши данные для входа</p>
            </div>
            
            <?php if(!empty($error)): ?>
                <div style="background: var(--error); color: white; padding: 12px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 600;">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Email:</label>
                    <input type="email" name="email" required 
                           style="width: 100%; padding: 14px; border: 2px solid var(--gray); border-radius: 10px; font-size: 16px; transition: border-color 0.3s;"
                           onfocus="this.style.borderColor='var(--primary)'"
                           onblur="this.style.borderColor='var(--gray)'"
                           placeholder="your@email.com">
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Пароль:</label>
                    <input type="password" name="password" required 
                           style="width: 100%; padding: 14px; border: 2px solid var(--gray); border-radius: 10px; font-size: 16px; transition: border-color 0.3s;"
                           onfocus="this.style.borderColor='var(--primary)'"
                           onblur="this.style.borderColor='var(--gray)'"
                           placeholder="Введите пароль">
                </div>
                
                <button type="submit" class="cta-button" style="width: 100%; background: var(--primary);">
                    <i class="fas fa-sign-in-alt"></i> Войти
                </button>
            </form>
            
            <div style="text-align: center; margin-top: 25px; padding-top: 20px; border-top: 1px solid var(--gray);">
                <p style="color: var(--secondary); margin-bottom: 15px;">Нет аккаунта?</p>
                <a href="register.php" class="profile-btn secondary" style="text-decoration: none; width: 100%; text-align: center; display: block;">
                    <i class="fas fa-user-plus"></i> Зарегистрироваться
                </a>
            </div>

            <div style="margin-top: 20px; padding: 15px; background: var(--gray); border-radius: 8px; text-align: center;">
                <p style="color: var(--secondary); font-size: 14px; margin: 0;">
                    <strong>Тестовые данные:</strong><br>
                    admin@lazarevskoe.ru / 123456
                </p>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/layout/footer.php'; ?>
