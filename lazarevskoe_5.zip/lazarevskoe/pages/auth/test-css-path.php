<?php
$page_title = "ТЕСТ ПУТИ CSS";
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ТЕСТ ПУТИ</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        .test-info {
            background: blue;
            color: white;
            padding: 20px;
            margin: 20px;
            text-align: center;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="utility-bar">
        <div class="logo-text">Лазаревское - online</div>
    </div>
    
    <div class="page-container">
        <div class="test-info">
            🎯 ЕСЛИ ВИДИШЬ СТИЛИ - ПУТЬ РАБОТАЕТ!<br>
            Путь: ../../assets/css/style.css
        </div>
        
        <div style="text-align: center;">
            <button class="cta-button">Тест кнопки</button>
            <div class="nav-card" style="display: inline-block; margin: 20px;">
                <i class="fas fa-star"></i>
                <span>Тест карточки</span>
            </div>
        </div>
    </div>
</body>
</html>
