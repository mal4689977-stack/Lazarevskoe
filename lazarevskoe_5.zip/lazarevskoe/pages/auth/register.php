<?php
session_start();
require_once '../../config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $phone = trim($_POST['phone']);
    
    if (!empty($name) && !empty($email) && !empty($password)) {
        // Валидация пароля
        if (strlen($password) < 6) {
            $error = "Пароль должен быть не менее 6 символов";
        } else {
            $database = new Database();
            $db = $database->getConnection();
            
            // Проверяем нет ли такого email
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $error = "Пользователь с таким email уже существует";
            } else {
                // Создаем пользователя
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, 'user')");
                if ($stmt->execute([$name, $email, $hashed_password, $phone])) {
                    $_SESSION['user_id'] = $db->lastInsertId();
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_role'] = 'user';
                    
                    header('Location: ../../index.php');
                    exit;
                } else {
                    $error = "Ошибка при создании пользователя";
                }
            }
        }
    } else {
        $error = "Заполните все обязательные поля";
    }
}

$page_title = "Регистрация - Лазаревское";
include '../../includes/layout/header-auth.php';
include '../../includes/layout/utility-bar.php';
?>

<div class="page-container">
    <div style="max-width: 450px; margin: 0 auto; padding: 40px 20px;">
        <div style="background: var(--light); padding: 40px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            
            <!-- Заголовок с иконкой -->
            <div style="text-align: center; margin-bottom: 30px;">
                <div style="font-size: 48px; color: var(--primary); margin-bottom: 15px;">👤</div>
                <h2 style="color: var(--primary); margin-bottom: 10px;">Регистрация</h2>
                <p style="color: var(--secondary);">Создайте новый аккаунт</p>
            </div>
            
            <?php if(!empty($error)): ?>
                <div style="background: var(--error); color: white; padding: 12px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 600;">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div style="margin-bottom: 18px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Имя:</label>
                    <input type="text" name="name" required 
                           style="width: 100%; padding: 14px; border: 2px solid var(--gray); border-radius: 10px; font-size: 16px; transition: border-color 0.3s;"
                           onfocus="this.style.borderColor='var(--primary)'"
                           onblur="this.style.borderColor='var(--gray)'"
                           placeholder="Ваше имя">
                </div>
                
                <div style="margin-bottom: 18px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Email:</label>
                    <input type="email" name="email" required 
                           style="width: 100%; padding: 14px; border: 2px solid var(--gray); border-radius: 10px; font-size: 16px; transition: border-color 0.3s;"
                           onfocus="this.style.borderColor='var(--primary)'"
                           onblur="this.style.borderColor='var(--gray)'"
                           placeholder="your@email.com">
                </div>
                
                <div style="margin-bottom: 18px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Телефон:</label>
                    <input type="tel" name="phone" 
                           style="width: 100%; padding: 14px; border: 2px solid var(--gray); border-radius: 10px; font-size: 16px; transition: border-color 0.3s;"
                           onfocus="this.style.borderColor='var(--primary)'"
                           onblur="this.style.borderColor='var(--gray)'"
                           placeholder="+7 999 123-45-67">
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Пароль:</label>
                    <input type="password" name="password" required 
                           style="width: 100%; padding: 14px; border: 2px solid var(--gray); border-radius: 10px; font-size: 16px; transition: border-color 0.3s;"
                           onfocus="this.style.borderColor='var(--primary)'"
                           onblur="this.style.borderColor='var(--gray)'"
                           placeholder="Не менее 6 символов">
                    <small style="color: var(--secondary); display: block; margin-top: 5px;">Минимум 6 символов</small>
                </div>
                
                <button type="submit" class="cta-button" style="width: 100%; background: var(--success);">
                    <i class="fas fa-user-plus"></i> Зарегистрироваться
                </button>
            </form>
            
            <div style="text-align: center; margin-top: 25px; padding-top: 20px; border-top: 1px solid var(--gray);">
                <p style="color: var(--secondary); margin-bottom: 15px;">Уже есть аккаунт?</p>
                <a href="login.php" class="profile-btn secondary" style="text-decoration: none; width: 100%; text-align: center; display: block;">
                    <i class="fas fa-sign-in-alt"></i> Войти
                </a>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/layout/footer.php'; ?>
