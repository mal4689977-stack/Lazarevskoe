<?php
$page_title = "ТЕСТ AUTH СТРАНИЦЫ";
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ТЕСТ AUTH</title>
    <link rel="stylesheet" href="../../assets/scc/style.css">
</head>
<body>
    <div class="utility-bar">
        <div class="logo-text">Лазаревское - online</div>
    </div>
    <div class="page-container">
        <h1>ТЕСТ AUTH СТРАНИЦЫ</h1>
        <p>Путь: ../../assets/scc/style.css</p>
        <button class="cta-button">Тест кнопки</button>
    </div>
</body>
</html>
