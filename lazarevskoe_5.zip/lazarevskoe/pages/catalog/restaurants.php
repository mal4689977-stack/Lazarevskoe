<?php 
$page_title = "Рестораны - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';
?>

<div class="header-title">
    <h1>Рестораны и кафе</h1>
    <small>Лучшие места для вкусного отдыха</small>
</div>

<!-- Навигационные карточки -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="#restaurants" class="nav-card">
            <i class="fas fa-utensils"></i>
            <span>Рестораны</span>
        </a>
        <a href="#cafes" class="nav-card">
            <i class="fas fa-coffee"></i>
            <span>Кафе</span>
        </a>
        <a href="#bars" class="nav-card">
            <i class="fas fa-cocktail"></i>
            <span>Бары</span>
        </a>
    </div>
</section>

<section class="cards-section">
    <h2 class="section-title">Популярные заведения</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Ресторан у моря">
                <div class="card-badge">Премиум</div>
            </div>
            <div class="card-content">
                <h3>Ресторан "У моря"</h3>
                <div class="card-meta">
                    <span class="price">$$$</span>
                    <span class="rating">★ 4.7</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-fish"></i> Морепродукты</li>
                    <li><i class="fas fa-umbrella"></i> Веранда</li>
                    <li><i class="fas fa-music"></i> Живая музыка</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Кафе Быстро">
                <div class="card-badge">Быстро</div>
            </div>
            <div class="card-content">
                <h3>Кафе "Быстрое"</h3>
                <div class="card-meta">
                    <span class="price">$</span>
                    <span class="rating">★ 4.3</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-clock"></i> Быстрое обслуживание</li>
                    <li><i class="fas fa-hamburger"></i> Бургеры</li>
                    <li><i class="fas fa-coffee"></i> Кофе навынос</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Бар Вечерний">
                <div class="card-badge">Вечеринки</div>
            </div>
            <div class="card-content">
                <h3>Бар "Вечерний"</h3>
                <div class="card-meta">
                    <span class="price">$$</span>
                    <span class="rating">★ 4.5</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-cocktail"></i> Коктейли</li>
                    <li><i class="fas fa-music"></i> DJ</li>
                    <li><i class="fas fa-dance"></i> Танцпол</li>
                </ul>
            </div>
        </article>
    </div>
</section>

<?php include '../../includes/layout/footer.php'; ?>