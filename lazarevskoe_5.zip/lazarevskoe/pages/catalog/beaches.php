<?php 
$page_title = "Пляжи - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';
?>

<!-- Заголовок -->
<div class="header-title">
    <h1>Пляжи</h1>
    <small>Лучшие пляжи Лазаревского района</small>
</div>

<!-- Навигационные карточки пляжей -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="#central" class="nav-card">
            <i class="fas fa-umbrella-beach"></i>
            <span>Центральный пляж</span>
        </a>
        <a href="#wild" class="nav-card">
            <i class="fas fa-tree"></i>
            <span>Дикие пляжи</span>
        </a>
        <a href="#family" class="nav-card">
            <i class="fas fa-child"></i>
            <span>Семейные пляжи</span>
        </a>
    </div>
</section>

<!-- Карточки пляжей -->
<section class="cards-section">
    <h2 class="section-title">Популярные пляжи</h2>
    
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Центральный пляж">
                <div class="card-badge">Бесплатный</div>
            </div>
            <div class="card-content">
                <h3>Центральный пляж</h3>
                <div class="card-meta">
                    <span class="price">Бесплатно</span>
                    <span class="rating">★ 4.5</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-sun"></i> Песчаный</li>
                    <li><i class="fas fa-shower"></i> Души</li>
                    <li><i class="fas fa-utensils"></i> Кафе</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Дикий пляж">
                <div class="card-badge">Уединенный</div>
            </div>
            <div class="card-content">
                <h3>Дикий пляж "Скала"</h3>
                <div class="card-meta">
                    <span class="price">Бесплатно</span>
                    <span class="rating">★ 4.8</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-tree"></i> Среди природы</li>
                    <li><i class="fas fa-water"></i> Чистая вода</li>
                    <li><i class="fas fa-camera"></i> Красивые виды</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Семейный пляж">
                <div class="card-badge">Для детей</div>
            </div>
            <div class="card-content">
                <h3>Семейный пляж "Радуга"</h3>
                <div class="card-meta">
                    <span class="price">100₽ вход</span>
                    <span class="rating">★ 4.6</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-child"></i> Детская зона</li>
                    <li><i class="fas fa-umbrella"></i> Лежаки</li>
                    <li><i class="fas fa-life-ring"></i> Спасатели</li>
                </ul>
            </div>
        </article>
    </div>
</section>

<?php include '../../includes/layout/footer.php'; ?>