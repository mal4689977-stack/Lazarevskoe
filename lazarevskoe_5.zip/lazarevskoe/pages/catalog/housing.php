<?php 
$page_title = "Жилье - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';
?>

<div class="header-title">
    <h1>Жилье</h1>
    <small>Отели, квартиры, гостевые дома</small>
</div>

<!-- Навигационные карточки -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="#apartments" class="nav-card">
            <i class="fas fa-building"></i>
            <span>Квартиры</span>
        </a>
        <a href="#hotels" class="nav-card">
            <i class="fas fa-hotel"></i>
            <span>Отели</span>
        </a>
        <a href="#guesthouses" class="nav-card">
            <i class="fas fa-home"></i>
            <span>Гостевые дома</span>
        </a>
    </div>
</section>

<section class="cards-section">
    <h2 class="section-title">Доступное жилье</h2>
    <div class="cards-grid">
        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Квартира у моря">
                <div class="card-badge">У моря</div>
            </div>
            <div class="card-content">
                <h3>Квартира у моря</h3>
                <div class="card-meta">
                    <span class="price">3 000₽/ночь</span>
                    <span class="rating">★ 4.8</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-user"></i> До 4 человек</li>
                    <li><i class="fas fa-wifi"></i> Wi-Fi</li>
                    <li><i class="fas fa-umbrella-beach"></i> 200м до моря</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Отель Премиум">
                <div class="card-badge">Премиум</div>
            </div>
            <div class="card-content">
                <h3>Отель "Морской бриз"</h3>
                <div class="card-meta">
                    <span class="price">5 000₽/ночь</span>
                    <span class="rating">★ 4.9</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-swimming-pool"></i> Бассейн</li>
                    <li><i class="fas fa-utensils"></i> Ресторан</li>
                    <li><i class="fas fa-spa"></i> СПА</li>
                </ul>
            </div>
        </article>

        <article class="card">
            <div class="card-image">
                <img src="https://via.placeholder.com/400x250" alt="Гостевой дом">
                <div class="card-badge">Уютно</div>
            </div>
            <div class="card-content">
                <h3>Гостевой дом "У камина"</h3>
                <div class="card-meta">
                    <span class="price">2 000₽/ночь</span>
                    <span class="rating">★ 4.7</span>
                </div>
                <ul class="card-features">
                    <li><i class="fas fa-tree"></i> В лесу</li>
                    <li><i class="fas fa-fire"></i> Камин</li>
                    <li><i class="fas fa-parking"></i> Парковка</li>
                </ul>
            </div>
        </article>
    </div>
</section>

<?php include '../../includes/layout/footer.php'; ?>