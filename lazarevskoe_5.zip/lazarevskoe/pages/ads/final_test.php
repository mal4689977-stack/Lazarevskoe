<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Финальный тест</title>
    <style>
        body { font-family: Arial; padding: 20px; max-width: 800px; margin: 0 auto; }
        .test-section { background: white; padding: 20px; margin: 20px 0; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <h1>🎯 Финальный тест загрузки</h1>";

// ТЕСТ 1: Простая загрузка
echo "<div class='test-section'>
    <h2>🧪 Тест 1: Простая загрузка файла</h2>
    <form method='post' enctype='multipart/form-data'>
        <input type='hidden' name='test_type' value='simple'>
        <input type='file' name='test_file' required>
        <button type='submit'>Тест простой загрузки</button>
    </form>";

if ($_POST['test_type'] ?? '' === 'simple') {
    echo "<h3>Результат:</h3><pre>";
    print_r($_FILES);
    echo "</pre>";
    
    if (isset($_FILES['test_file']) && $_FILES['test_file']['error'] === 0) {
        echo "<p class='success'>✅ Простая загрузка РАБОТАЕТ</p>";
    } else {
        echo "<p class='error'>❌ Простая загрузка НЕ РАБОТАЕТ</p>";
    }
}
echo "</div>";

// ТЕСТ 2: Мульти-загрузка (как в основной форме)
echo "<div class='test-section'>
    <h2>🧪 Тест 2: Мульти-загрузка (photos[])</h2>
    <form method='post' enctype='multipart/form-data'>
        <input type='hidden' name='test_type' value='multi'>
        <input type='file' name='photos[]' multiple required>
        <button type='submit'>Тест мульти-загрузки</button>
    </form>";

if ($_POST['test_type'] ?? '' === 'multi') {
    echo "<h3>Результат:</h3><pre>";
    print_r($_FILES);
    echo "</pre>";
    
    if (isset($_FILES['photos']) && is_array($_FILES['photos']['name'])) {
        $file_count = count(array_filter($_FILES['photos']['name']));
        if ($file_count > 0) {
            echo "<p class='success'>✅ Мульти-загрузка РАБОТАЕТ (файлов: $file_count)</p>";
        } else {
            echo "<p class='error'>❌ Мульти-загрузка НЕ РАБОТАЕТ (файлы не пришли)</p>";
        }
    } else {
        echo "<p class='error'>❌ Мульти-загрузка НЕ РАБОТАЕТ</p>";
    }
}
echo "</div>";

echo "<div style='text-align: center; margin-top: 30px;'>
        <a href='upload_ad.php' style='padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>📝 Проверить основную форму</a>
    </div>";

echo "</body></html>";
?>