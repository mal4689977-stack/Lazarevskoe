<?php
echo "<!DOCTYPE html>
<html>
<head>
    <title>Тест маленького файла</title>
    <style>
        body { font-family: Arial; padding: 20px; max-width: 600px; margin: 0 auto; }
        form { background: #e8f5e8; padding: 20px; border-radius: 10px; }
        input[type='file'] { padding: 15px; margin: 10px 0; width: 100%; }
        button { padding: 15px 30px; background: #28a745; color: white; border: none; border-radius: 5px; font-size: 16px; }
        .result { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }
    </style>
</head>
<body>
    <h1>🧪 Тест маленького файла</h1>
    <p>Попробуй загрузить ОЧЕНЬ маленький файл (до 100KB)</p>
    
    <form method='post' enctype='multipart/form-data'>
        <input type='file' name='small_file' accept='image/*' required>
        <button type='submit'>🚀 Тестировать</button>
    </form>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<div class='result'>
        <h3>📊 Результат:</h3>
        <pre>";
    print_r($_FILES);
    echo "</pre>";
    
    if (isset($_FILES['small_file']) && $_FILES['small_file']['error'] === 0) {
        echo "<p style='color: green; font-weight: bold;'>✅ УСПЕХ! Файл загружен!</p>";
        
        // Сохраняем файл
        $upload_dir = '../../uploads/ads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        
        $new_name = 'test_small_' . uniqid() . '_' . $_FILES['small_file']['name'];
        $dest = $upload_dir . $new_name;
        
        if (move_uploaded_file($_FILES['small_file']['tmp_name'], $dest)) {
            echo "<p style='color: green;'>✅ Файл сохранен: " . $new_name . "</p>";
            echo "<img src='$dest' style='max-width: 300px; border: 2px solid green;'>";
        }
    } else {
        echo "<p style='color: red; font-weight: bold;'>❌ ОШИБКА: ";
        if (isset($_FILES['small_file'])) {
            echo "Код ошибки: " . $_FILES['small_file']['error'];
        } else {
            echo "Файл не пришел в \$_FILES";
        }
        echo "</p>";
    }
    echo "</div>";
}

echo "</body></html>";
?>