<?php
echo "<h1>🧪 Тест правильности путей</h1>";

// Проверяем database.php
$db_paths = [
    '../../config/database.php',
    '../config/database.php', 
    '../../../config/database.php'
];

echo "<h3>Проверка database.php:</h3>";
foreach($db_paths as $path) {
    if (file_exists($path)) {
        echo "<p style='color: green;'>✅ Найден: $path</p>";
    } else {
        echo "<p style='color: red;'>❌ Не найден: $path</p>";
    }
}

// Проверяем папку uploads
$upload_paths = [
    '../../uploads/ads/',
    '../uploads/ads/',
    '../../../uploads/ads/'
];

echo "<h3>Проверка папки uploads:</h3>";
foreach($upload_paths as $path) {
    if (is_dir($path)) {
        $files = array_diff(scandir($path), ['.', '..']);
        echo "<p style='color: green;'>✅ Папка существует: $path (файлов: " . count($files) . ")</p>";
    } else {
        echo "<p style='color: red;'>❌ Папка не существует: $path</p>";
    }
}

echo "<hr>";
echo "<p><a href='upload_ad.php'>📝 Перейти к форме добавления</a></p>";
?>
