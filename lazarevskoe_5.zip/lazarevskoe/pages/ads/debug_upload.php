<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<div style='background: #fff3cd; padding: 20px; border-radius: 10px; margin: 20px 0;'>";
    echo "<h3>🔍 ДЕБАГ ПОСТ-ЗАПРОСА:</h3>";
    echo "<strong>POST данные:</strong><br>";
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
    
    echo "<strong>FILES данные:</strong><br>";
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";
    echo "</div>";
    
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    if (empty($title) || empty($description) || $price <= 0 || $category_id <= 0) {
        $error = 'Заполните все обязательные поля';
    } else {
        // ЗАГРУЗКА ФАЙЛОВ
        $uploaded_images = [];
        $upload_dir = '../../uploads/ads/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // ПРОСТАЯ ЗАГРУЗКА БЕЗ ПРОВЕРОК
        if(isset($_FILES['photos'])) {
            echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 8px; margin: 15px 0;'>";
            echo "<h4>📁 ПРОЦЕСС ЗАГРУЗКИ:</h4>";
            
            foreach($_FILES['photos']['name'] as $key => $name) {
                if($_FILES['photos']['error'][$key] === 0 && $_FILES['photos']['size'][$key] > 0) {
                    echo "<p>⚡ Обрабатываем файл: " . $name . "</p>";
                    
                    $file_tmp = $_FILES['photos']['tmp_name'][$key];
                    $file_new = uniqid() . '_' . $name;
                    $file_dest = $upload_dir . $file_new;
                    
                    if(move_uploaded_file($file_tmp, $file_dest)) {
                        $uploaded_images[] = $file_new;
                        echo "<p style='color: green;'>✅ Успешно: " . $file_new . "</p>";
                    } else {
                        echo "<p style='color: red;'>❌ Ошибка загрузки: " . $name . "</p>";
                    }
                } else {
                    echo "<p style='color: orange;'>⚠️ Пропущен файл: " . $name . " (ошибка: " . $_FILES['photos']['error'][$key] . ")</p>";
                }
            }
            echo "</div>";
        } else {
            echo "<p style='color: red;'>❌ Файлы не были отправлены (photos не в FILES)</p>";
        }
        
        // СОХРАНЕНИЕ В БАЗУ
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $images_json = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
            
            echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 8px; margin: 15px 0;'>";
            echo "<h4>💾 СОХРАНЕНИЕ В БАЗУ:</h4>";
            echo "<p>JSON изображений: " . $images_json . "</p>";
            
            $sql = "INSERT INTO ads (user_id, category_id, title, description, price, images, phone, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, '', NOW())";
            
            $stmt = $db->prepare($sql);
            
            if($stmt->execute([$user_id, $category_id, $title, $description, $price, $images_json])) {
                $ad_id = $db->lastInsertId();
                $success = '✅ Объявление успешно создано! ID: ' . $ad_id;
                if(!empty($uploaded_images)) {
                    $success .= ' | Загружено фото: ' . count($uploaded_images);
                }
                $_POST = [];
            } else {
                $error = '❌ Ошибка сохранения в базу данных';
            }
            echo "</div>";
        } catch (Exception $e) {
            $error = '❌ Ошибка базы данных: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Добавить объявление - Дебаг</title>
    <style>
        body { font-family: Arial; max-width: 800px; margin: 0 auto; padding: 20px; background: #f8f9fa; }
        .form-container { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .form-group { margin: 25px 0; }
        label { display: block; margin-bottom: 10px; font-weight: bold; font-size: 18px; color: #333; }
        input, textarea, select { 
            width: 100%; 
            padding: 15px; 
            border: 3px solid #007bff; 
            border-radius: 10px; 
            font-size: 16px;
            box-sizing: border-box;
        }
        input[type="file"] {
            padding: 25px;
            border: 3px dashed #28a745;
            background: #f8fff9;
            font-size: 18px;
        }
        button { 
            background: #28a745; 
            color: white; 
            padding: 20px; 
            border: none; 
            border-radius: 10px; 
            font-size: 20px; 
            width: 100%;
            margin-top: 20px;
            cursor: pointer;
            font-weight: bold;
        }
        .message { padding: 20px; margin: 20px 0; border-radius: 10px; text-align: center; font-size: 18px; }
        .success { background: #d4edda; color: #155724; border: 2px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 2px solid #f5c6cb; }
        .debug-info { background: #e7f3ff; padding: 15px; border-radius: 8px; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="form-container">
        <h1 style="text-align: center; color: #28a745; margin-bottom: 30px;">🚀 ДОБАВИТЬ ОБЪЯВЛЕНИЕ (Дебаг)</h1>
        
        <?php if($success): ?>
            <div class="message success">
                <?= $success ?>
                <br><br>
                <a href="../profile.php" style="color: #155724; font-weight: bold;">← Перейти в профиль</a>
            </div>
        <?php elseif($error): ?>
            <div class="message error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label>📝 Заголовок *</label>
                <input type="text" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label>📄 Описание *</label>
                <textarea name="description" rows="4" required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
            </div>
            
            <div class="form-group">
                <label>💰 Цена (руб) *</label>
                <input type="number" name="price" required min="1" value="<?= $_POST['price'] ?? '' ?>">
            </div>
            
            <div class="form-group">
                <label>📂 Категория *</label>
                <select name="category_id" required>
                    <option value="">Выберите категорию</option>
                    <?php
                    $database = new Database();
                    $db = $database->getConnection();
                    $categories = $db->query("SELECT * FROM categories WHERE parent_id IS NULL")->fetchAll();
                    foreach($categories as $cat) {
                        $selected = ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '';
                        echo '<option value="' . $cat['id'] . '" ' . $selected . '>' . $cat['name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>📷 ФОТОГРАФИИ *</label>
                <input type="file" name="photos[]" multiple accept="image/*" required>
                <div class="debug-info">
                    <strong>⚠️ ВАЖНО:</strong> Эта форма покажет весь процесс загрузки<br>
                    💡 Выберите фото и нажмите "ОПУБЛИКОВАТЬ"<br>
                    🔍 Вы увидите что происходит с файлами
                </div>
            </div>
            
            <button type="submit">🚀 ОПУБЛИКОВАТЬ ОБЪЯВЛЕНИЕ</button>
        </form>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="../profile.php" style="color: #007bff; font-size: 16px;">← Назад в профиль</a>
        </div>
    </div>
</body>
</html>