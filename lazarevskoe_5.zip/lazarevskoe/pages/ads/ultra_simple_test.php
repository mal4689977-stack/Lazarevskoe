<?php
echo "<!DOCTYPE html><html><head><title>Ультра-простой тест</title></head><body>";
echo "<h1>🧪 Ультра-простой тест загрузки</h1>";

if ($_FILES) {
    echo "<h3>Полученные файлы:</h3>";
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";
    
    if (isset($_FILES['test_file']) && $_FILES['test_file']['error'] === 0) {
        $upload_dir = '/storage/emulated/0/Е/123/LAZAREVSKOE/lazarevskoe/uploads/ads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        
        $new_name = uniqid() . '_' . $_FILES['test_file']['name'];
        $dest = $upload_dir . $new_name;
        
        if (move_uploaded_file($_FILES['test_file']['tmp_name'], $dest)) {
            echo "<p style='color: green;'>✅ Файл загружен: " . $new_name . "</p>";
            echo "<img src='" . $dest . "' style='max-width: 300px;'>";
        } else {
            echo "<p style='color: red;'>❌ Ошибка загрузки</p>";
        }
    }
}

echo "<form method='post' enctype='multipart/form-data'>";
echo "<input type='file' name='test_file'><br><br>";
echo "<button type='submit'>Тест загрузки</button>";
echo "</form>";
echo "</body></html>";
?>