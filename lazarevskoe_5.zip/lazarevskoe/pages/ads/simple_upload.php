<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    if (empty($title) || empty($description) || $price <= 0 || $category_id <= 0) {
        $error = 'Заполните все обязательные поля';
    } else {
        // Загрузка файлов
        $uploaded_images = [];
        $upload_dir = '../../uploads/ads/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // ПРОСТАЯ загрузка файлов
        if(isset($_FILES['photos'])) {
            foreach($_FILES['photos']['name'] as $key => $name) {
                if($_FILES['photos']['error'][$key] === 0 && $_FILES['photos']['size'][$key] > 0) {
                    $file_tmp = $_FILES['photos']['tmp_name'][$key];
                    $file_new = uniqid() . '_' . $name;
                    $file_dest = $upload_dir . $file_new;
                    
                    if(move_uploaded_file($file_tmp, $file_dest)) {
                        $uploaded_images[] = $file_new;
                    }
                }
            }
        }
        
        // Сохраняем в базу данных С phone полем
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $images_json = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
            
            $sql = "INSERT INTO ads (user_id, category_id, title, description, price, images, phone, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, '', NOW())";
            
            $stmt = $db->prepare($sql);
            
            if($stmt->execute([$user_id, $category_id, $title, $description, $price, $images_json])) {
                $success = '✅ Объявление успешно создано!';
                if(!empty($uploaded_images)) {
                    $success .= ' Загружено фото: ' . count($uploaded_images);
                }
                $_POST = [];
            } else {
                $error = '❌ Ошибка сохранения в базу данных';
            }
        } catch (Exception $e) {
            $error = '❌ Ошибка базы данных: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Добавить объявление</title>
    <style>
        body { font-family: Arial; max-width: 600px; margin: 0 auto; padding: 20px; }
        .form-group { margin: 20px 0; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input, textarea, select { 
            width: 100%; 
            padding: 12px; 
            border: 2px solid #ddd; 
            border-radius: 5px; 
            margin: 5px 0; 
            font-size: 16px;
        }
        input[type="file"] {
            padding: 20px;
            border: 2px dashed #28a745;
            background: #f8fff8;
        }
        button { 
            background: #28a745; 
            color: white; 
            padding: 15px; 
            border: none; 
            border-radius: 5px; 
            font-size: 18px; 
            width: 100%;
            margin-top: 20px;
        }
        .message { padding: 15px; margin: 20px 0; border-radius: 5px; text-align: center; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        .file-info { background: #e7f3ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1 style="text-align: center; color: #28a745;">📝 Добавить объявление</h1>
    
    <?php if($success): ?>
        <div class="message success">
            <?= $success ?>
            <br><br>
            <a href="../profile.php" style="color: #155724;">← Перейти в профиль</a>
        </div>
    <?php elseif($error): ?>
        <div class="message error"><?= $error ?></div>
    <?php endif; ?>
    
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Заголовок *</label>
            <input type="text" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
        </div>
        
        <div class="form-group">
            <label>Описание *</label>
            <textarea name="description" rows="4" required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
        </div>
        
        <div class="form-group">
            <label>Цена (руб) *</label>
            <input type="number" name="price" required min="1" value="<?= $_POST['price'] ?? '' ?>">
        </div>
        
        <div class="form-group">
            <label>Категория *</label>
            <select name="category_id" required>
                <option value="">Выберите категорию</option>
                <?php
                $database = new Database();
                $db = $database->getConnection();
                $categories = $db->query("SELECT * FROM categories WHERE parent_id IS NULL")->fetchAll();
                foreach($categories as $cat) {
                    $selected = ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '';
                    echo '<option value="' . $cat['id'] . '" ' . $selected . '>' . $cat['name'] . '</option>';
                }
                ?>
            </select>
        </div>
        
        <div class="form-group">
            <label style="color: #dc3545; font-size: 20px; font-weight: bold;">📷 ФОТОГРАФИИ *</label>
            <input type="file" name="photos[]" multiple accept="image/*" required 
                   style="padding: 30px; border: 4px dashed #dc3545; background: #fff5f5; border-radius: 15px; width: 100%; box-sizing: border-box; font-size: 20px;">
            <div class="file-info" style="background: #fff3cd; padding: 20px; border-radius: 10px; margin: 15px 0; border: 2px solid #ffeaa7;">
                <div style="color: #856404; font-size: 18px; font-weight: bold; margin-bottom: 15px;">⚠️ ФОТО ОБЯЗАТЕЛЬНЫ ДЛЯ ПУБЛИКАЦИИ!</div>
                💡 <strong>Как выбрать:</strong> Нажмите на цветное поле выше<br>
                📁 <strong>Несколько файлов:</strong> Удерживайте Ctrl при выборе<br>
                🖼️ <strong>Форматы:</strong> JPG, PNG, GIF, WebP<br>
                ✅ <strong>После выбора</strong> файлов нажмите "Опубликовать"
            </div>
        </div>
        
        <button type="submit">🚀 Опубликовать объявление</button>
    </form>
    
    <div style="text-align: center; margin-top: 20px;">
        <a href="../profile.php" style="color: #007bff;">← Назад в профиль</a>
    </div>
</body>
</html>