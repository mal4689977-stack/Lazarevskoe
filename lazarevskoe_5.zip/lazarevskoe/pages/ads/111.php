<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}



$page_title = "Добавить объявление - Лазаревское";
include '../../includes/layout/header.php';
include '../../includes/layout/utility-bar.php';

$database = new Database();
$db = $database->getConnection();

// Получаем ВСЕ подкатегории (как в старой версии)
$categories = $db->query("
    SELECT id, name 
    FROM categories 
    WHERE parent_id IS NOT NULL 
    ORDER BY name
")->fetchAll();
?>


<style>
@import url('../../assets/css/style.css');
</style>


<div class="page-container">
    <!-- Заголовок -->
    <div class="profile-header">
        <h1>📋 Добавить объявление</h1>
        <p>Расскажите о вашем предложении в Лазаревском</p>
    </div>

    <!-- Уведомление об успешной загрузке -->
    <div class="section" style="text-align: center; margin-bottom: 30px;">
        <h3 style="color: var(--success); margin-bottom: 10px;">✅ Форма работает!</h3>
        <p style="color: var(--text); margin-bottom: 15px;">Теперь можно загружать до 5 фотографий</p>
        <div style="display: flex; justify-content: center; gap: 10px; flex-wrap: wrap;">
            <div class="nav-card" style="padding: 15px; min-width: 100px;">
                <i class="fas fa-camera"></i>
                <span>5 фото</span>
            </div>
            <div class="nav-card" style="padding: 15px; min-width: 100px;">
                <i class="fas fa-check"></i>
                <span>Работает</span>
            </div>
        </div>
    </div>

    <!-- Основная форма -->
    <div class="section">
        <form action="process_ad_fixed.php" method="POST" enctype="multipart/form-data">
            
            <!-- Категория (простой выбор как в старой версии) -->
            <div class="form-group">
                <label class="form-label required">Категория:</label>
                <select name="category_id" required class="form-select">
                    <option value="">-- Выберите категорию --</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>">
                            <?php echo htmlspecialchars($cat['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Основная информация -->
            <div class="form-group">
                <label class="form-label required">Название объявления</label>
                <input type="text" class="form-input" name="title" required 
                       placeholder="Например: Гостевой дом 'У моря' или 'Прогулки на катерах'">
            </div>

            <div class="form-group">
                <label class="form-label required">Описание</label>
                <textarea class="form-textarea" name="description" required 
                          placeholder="Подробно опишите ваше предложение, условия, преимущества..."></textarea>
            </div>

            <!-- Контакты и цена -->
            <div class="form-row">
                <div class="form-group half">
                    <label class="form-label required">Телефон для связи</label>
                    <input type="tel" class="form-input" name="phone" required 
                           placeholder="+7 999 123-45-67">
                </div>

                <div class="form-group half">
                    <label class="form-label">Цена (руб)</label>
                    <input type="number" class="form-input" name="price" 
                           placeholder="1500">
                </div>
            </div>

            <!-- Местоположение -->
            <div class="form-group">
                <label class="form-label">Местоположение</label>
                <input type="text" class="form-input" name="location" 
                       placeholder="ул. Победы, 15 или Центральный пляж">
            </div>

            <!-- Фотографии (отдельные поля как в старой версии) -->
            <div class="form-group">
                <label class="form-label">Фотографии (до 5):</label>
                
                <div class="photo-fields">
                    <div class="photo-field">
                        <div class="photo-label">Фото 1 (основное):</div>
                        <input type="file" class="form-input" name="photo1" accept="image/jpeg,image/png">
                    </div>
                    
                    <div class="photo-field">
                        <div class="photo-label">Фото 2:</div>
                        <input type="file" class="form-input" name="photo2" accept="image/jpeg,image/png">
                    </div>
                    
                    <div class="photo-field">
                        <div class="photo-label">Фото 3:</div>
                        <input type="file" class="form-input" name="photo3" accept="image/jpeg,image/png">
                    </div>
                    
                    <div class="photo-field">
                        <div class="photo-label">Фото 4:</div>
                        <input type="file" class="form-input" name="photo4" accept="image/jpeg,image/png">
                    </div>
                    
                    <div class="photo-field">
                        <div class="photo-label">Фото 5:</div>
                        <input type="file" class="form-input" name="photo5" accept="image/jpeg,image/png">
                    </div>
                </div>
                
                <div class="photo-hint">
                    📷 Форматы: JPG, PNG. Первое фото будет главным в объявлении
                </div>
            </div>

            <!-- Кнопка отправки -->
            <div class="submit-section">
                <button type="submit" class="cta-button">
                    <i class="fas fa-paper-plane"></i> Опубликовать объявление
                </button>
            </div>
        </form>
        
        <!-- Кнопка назад -->
        <div style="text-align: center; margin-top: 20px;">
            <a href="../../index.php" class="profile-btn secondary" style="text-decoration: none; display: inline-flex; align-items: center; gap: 8px;">
                <i class="fas fa-arrow-left"></i> На главную
            </a>
        </div>
    </div>
</div>


<?php include '../../includes/layout/footer.php'; ?>