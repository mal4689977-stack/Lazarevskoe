<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

$page_title = "Добавить объявление - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';

$database = new Database();
$db = $database->getConnection();

$categories = $db->query("
    SELECT id, name 
    FROM categories 
    WHERE parent_id IS NOT NULL 
    ORDER BY name
")->fetchAll();
?>

<div class="header-title">
    <h1>Добавить объявление</h1>
    <small>Красивая форма с удобной загрузкой фото 🎨</small>
</div>

<div class="page-container">
    <div style="max-width: 700px; margin: 0 auto;">
        
        <!-- Статус загрузки -->
        <div id="uploadStatus" style="display: none; margin-bottom: 20px; padding: 15px; border-radius: 10px; background: #e8f5e8; color: #2e7d32;">
            <i class="fas fa-spinner fa-spin"></i> <span id="statusText">Загрузка...</span>
        </div>

        <form action="process_ad_beautiful.php" method="POST" enctype="multipart/form-data" id="uploadForm"
              style="background: var(--light); padding: 30px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            
            <!-- Основные поля -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-tag"></i> Категория:
                    </label>
                    <select name="category_id" required 
                            style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px; background: white;">
                        <option value="">-- Выберите категорию --</option>
                        <?php foreach($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>">
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-ruble-sign"></i> Цена (руб):
                    </label>
                    <input type="number" name="price" placeholder="1500" 
                           style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
                </div>
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                    <i class="fas fa-heading"></i> Заголовок объявления:
                </label>
                <input type="text" name="title" required placeholder="Уютная квартира у моря" 
                       style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                    <i class="fas fa-align-left"></i> Описание:
                </label>
                <textarea name="description" required rows="4" placeholder="Расскажите подробно о вашем предложении..."
                          style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;"></textarea>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-phone"></i> Телефон:
                    </label>
                    <input type="tel" name="phone" required placeholder="+7 999 123-45-67" 
                           style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
                </div>
                
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-map-marker-alt"></i> Местоположение:
                    </label>
                    <input type="text" name="location" placeholder="ул. Победы, 15 или Центральный пляж" 
                           style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
                </div>
            </div>

            <!-- КРАСИВАЯ ЗОНА ЗАГРУЗКИ ФОТО -->
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 15px; font-weight: 600; color: var(--primary);">
                    <i class="fas fa-camera"></i> Фотографии объявления:
                </label>
                
                <!-- Drag & Drop зона -->
                <div id="dropZone" 
                     style="border: 2px dashed #ccc; border-radius: 12px; padding: 40px; text-align: center; background: #fafafa; cursor: pointer; transition: all 0.3s ease; margin-bottom: 20px;">
                    <div id="dropContent">
                        <i class="fas fa-cloud-upload-alt" style="font-size: 48px; color: #ccc; margin-bottom: 15px;"></i>
                        <h3 style="color: #666; margin-bottom: 10px;">Перетащите фото сюда</h3>
                        <p style="color: #999; margin-bottom: 15px;">или нажмите для выбора файлов</p>
                        <button type="button" class="profile-btn" style="background: var(--primary);">
                            <i class="fas fa-folder-open"></i> Выбрать файлы
                        </button>
                    </div>
                </div>
                
                <!-- Скрытые поля для файлов -->
                <input type="file" id="fileInput" name="photos[]" multiple accept="image/*" style="display: none;">
                
                <!-- Preview галерея -->
                <div id="previewGallery" style="display: none;">
                    <h4 style="color: var(--primary); margin-bottom: 15px;">Выбранные фото:</h4>
                    <div id="imagePreviews" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px;"></div>
                </div>
                
                <small style="color: var(--secondary); display: block; margin-top: 10px;">
                    <i class="fas fa-info-circle"></i> Можно выбрать до 10 фото. Форматы: JPG, PNG
                </small>
            </div>
            
            <button type="submit" class="cta-button" style="width: 100%; background: var(--success); font-size: 18px;">
                <i class="fas fa-paper-plane"></i> Опубликовать объявление
            </button>
        </form>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="../../index.php" class="profile-btn secondary" style="text-decoration: none;">
                <i class="fas fa-arrow-left"></i> На главную
            </a>
        </div>
    </div>
</div>

<!-- JavaScript для красивой загрузки -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const previewGallery = document.getElementById('previewGallery');
    const imagePreviews = document.getElementById('imagePreviews');
    const uploadStatus = document.getElementById('uploadStatus');
    const statusText = document.getElementById('statusText');
    
    let selectedFiles = [];
    
    // Обработчик клика по зоне
    dropZone.addEventListener('click', () => fileInput.click());
    
    // Обработчик выбора файлов
    fileInput.addEventListener('change', handleFileSelect);
    
    // Drag & Drop функционал
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });
    
    function highlight() {
        dropZone.style.borderColor = 'var(--accent)';
        dropZone.style.background = '#fff3e0';
    }
    
    function unhighlight() {
        dropZone.style.borderColor = '#ccc';
        dropZone.style.background = '#fafafa';
    }
    
    dropZone.addEventListener('drop', handleDrop, false);
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }
    
    function handleFileSelect(e) {
        const files = e.target.files;
        handleFiles(files);
    }
    
    function handleFiles(files) {
        selectedFiles = Array.from(files);
        
        // Обновляем input
        const dataTransfer = new DataTransfer();
        selectedFiles.forEach(file => dataTransfer.items.add(file));
        fileInput.files = dataTransfer.files;
        
        // Показываем превью
        showPreviews(selectedFiles);
        
        // Обновляем интерфейс
        updateDropZone();
    }
    
    function showPreviews(files) {
        imagePreviews.innerHTML = '';
        
        files.forEach((file, index) => {
            if (!file.type.match('image.*')) return;
            
            const reader = new FileReader();
            
            reader.onload = (function(file, index) {
                return function(e) {
                    const preview = document.createElement('div');
                    preview.style.position = 'relative';
                    preview.style.borderRadius = '8px';
                    preview.style.overflow = 'hidden';
                    preview.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
                    
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.width = '100%';
                    img.style.height = '100px';
                    img.style.objectFit = 'cover';
                    img.style.display = 'block';
                    
                    const removeBtn = document.createElement('button');
                    removeBtn.innerHTML = '×';
                    removeBtn.style.position = 'absolute';
                    removeBtn.style.top = '5px';
                    removeBtn.style.right = '5px';
                    removeBtn.style.background = 'rgba(255,0,0,0.7)';
                    removeBtn.style.color = 'white';
                    removeBtn.style.border = 'none';
                    removeBtn.style.borderRadius = '50%';
                    removeBtn.style.width = '24px';
                    removeBtn.style.height = '24px';
                    removeBtn.style.cursor = 'pointer';
                    removeBtn.style.fontSize = '16px';
                    removeBtn.style.fontWeight = 'bold';
                    
                    removeBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        removeFile(index);
                    });
                    
                    preview.appendChild(img);
                    preview.appendChild(removeBtn);
                    imagePreviews.appendChild(preview);
                };
            })(file, index);
            
            reader.readAsDataURL(file);
        });
        
        previewGallery.style.display = 'block';
    }
    
    function removeFile(index) {
        selectedFiles.splice(index, 1);
        
        // Обновляем input
        const dataTransfer = new DataTransfer();
        selectedFiles.forEach(file => dataTransfer.items.add(file));
        fileInput.files = dataTransfer.files;
        
        // Обновляем превью
        showPreviews(selectedFiles);
        updateDropZone();
    }
    
    function updateDropZone() {
        const dropContent = document.getElementById('dropContent');
        if (selectedFiles.length > 0) {
            dropContent.innerHTML = `
                <i class="fas fa-check-circle" style="font-size: 48px; color: var(--success); margin-bottom: 15px;"></i>
                <h3 style="color: var(--success); margin-bottom: 10px;">Выбрано ${selectedFiles.length} файлов</h3>
                <p style="color: #999;">Нажмите для добавления еще фото</p>
            `;
        } else {
            dropContent.innerHTML = `
                <i class="fas fa-cloud-upload-alt" style="font-size: 48px; color: #ccc; margin-bottom: 15px;"></i>
                <h3 style="color: #666; margin-bottom: 10px;">Перетащите фото сюда</h3>
                <p style="color: #999; margin-bottom: 15px;">или нажмите для выбора файлов</p>
                <button type="button" class="profile-btn" style="background: var(--primary);">
                    <i class="fas fa-folder-open"></i> Выбрать файлы
                </button>
            `;
            previewGallery.style.display = 'none';
        }
    }
    
    // Обработчик отправки формы
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        if (selectedFiles.length === 0) {
            e.preventDefault();
            alert('Пожалуйста, добавьте хотя бы одно фото');
            return;
        }
        
        // Показываем статус загрузки
        uploadStatus.style.display = 'block';
        statusText.textContent = `Загружаем ${selectedFiles.length} файлов...`;
    });
});

// Анимация появления
document.addEventListener('DOMContentLoaded', function() {
    const elements = document.querySelectorAll('.page-container > *');
    elements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'all 0.5s ease';
        
        setTimeout(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, index * 100);
    });
});
</script>

<style>
#dropZone:hover {
    border-color: var(--accent);
    background: #fff8e1;
}

#dropZone.dragover {
    border-color: var(--accent);
    background: #e3f2fd;
}

/* Адаптивность */
@media (max-width: 768px) {
    .page-container > div {
        grid-template-columns: 1fr;
    }
    
    #imagePreviews {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
    }
}
</style>

<?php include '../../includes/layout/footer.php'; ?>