<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

$page_title = "Добавить объявление - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';

$database = new Database();
$db = $database->getConnection();

// Получаем основные категории
$main_categories = $db->query("
    SELECT id, name 
    FROM categories 
    WHERE parent_id IS NULL 
    ORDER BY name
")->fetchAll();

// Получаем все подкатегории
$all_subcategories = $db->query("
    SELECT id, name, parent_id 
    FROM categories 
    WHERE parent_id IS NOT NULL 
    ORDER BY parent_id, name
")->fetchAll();

// Группируем подкатегории по родительским категориям
$subcategories_by_parent = [];
foreach ($all_subcategories as $subcat) {
    $subcategories_by_parent[$subcat['parent_id']][] = $subcat;
}
?>

<div class="header-title">
    <h1>➕ Добавить объявление</h1>
    <small>Создайте привлекательное объявление с фото</small>
</div>

<div class="page-container">
    <div style="max-width: 800px; margin: 0 auto; padding: 0 10px;">
        
        <!-- Прогресс шагов -->
        <div class="form-progress" style="margin-bottom: 30px;">
            <div class="progress-steps">
                <div class="step active">1. Категория</div>
                <div class="step">2. Информация</div>
                <div class="step">3. Фото</div>
                <div class="step">4. Публикация</div>
            </div>
        </div>

        <form action="process_ad_modern.php" method="POST" enctype="multipart/form-data" id="uploadForm"
              style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 2px; border-radius: 20px;">
            <div style="background: white; padding: 30px; border-radius: 18px;">
                
                <!-- Шаг 1: Выбор категории -->
                <div class="form-step active" id="step1">
                    <h2 style="color: #333; margin-bottom: 25px; text-align: center;">
                        <i class="fas fa-tag"></i> Выберите категорию
                    </h2>
                    
                    <div style="margin-bottom: 25px;">
                        <label style="display: block; margin-bottom: 12px; font-weight: 700; color: #333; font-size: 16px;">
                            Основная категория:
                        </label>
                        <select name="main_category" id="mainCategory" required 
                                style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px; background: white; transition: all 0.3s;">
                            <option value="">-- Выберите основную категорию --</option>
                            <?php foreach($main_categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>">
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div style="margin-bottom: 25px; display: none;" id="subcategoryContainer">
                        <label style="display: block; margin-bottom: 12px; font-weight: 700; color: #333; font-size: 16px;">
                            Подкатегория:
                        </label>
                        <select name="category_id" id="subCategory" required 
                                style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px; background: white;">
                            <option value="">-- Сначала выберите основную категорию --</option>
                        </select>
                    </div>
                    
                    <button type="button" class="next-step" style="width: 100%; padding: 15px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer;">
                        Далее → Информация
                    </button>
                </div>

                <!-- Шаг 2: Основная информация -->
                <div class="form-step" id="step2">
                    <h2 style="color: #333; margin-bottom: 25px; text-align: center;">
                        <i class="fas fa-info-circle"></i> Основная информация
                    </h2>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                            📝 Заголовок объявления:
                        </label>
                        <input type="text" name="title" required placeholder="Например: Уютная квартира у моря с видом на закат" 
                               style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px; transition: border 0.3s;">
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                            📄 Описание:
                        </label>
                        <textarea name="description" required rows="5" placeholder="Опишите подробно ваше предложение: условия, особенности, преимущества..."
                                  style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px; resize: vertical; transition: border 0.3s;"></textarea>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 25px;">
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                                💰 Цена (руб):
                            </label>
                            <input type="number" name="price" placeholder="1500" 
                                   style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px;">
                        </div>
                        
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                                📍 Местоположение:
                            </label>
                            <input type="text" name="location" placeholder="ул. Победы, 15" 
                                   style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px;">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 25px;">
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                                📞 Телефон:
                            </label>
                            <input type="tel" name="phone" required placeholder="+7 999 123-45-67" 
                                   style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px;">
                        </div>
                        
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                                📧 Email:
                            </label>
                            <input type="email" name="email" placeholder="your@email.ru" 
                                   style="width: 100%; padding: 15px; border: 2px solid #e1e5e9; border-radius: 12px; font-size: 16px;">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <button type="button" class="prev-step" style="padding: 15px; background: #6c757d; color: white; border: none; border-radius: 12px; font-size: 16px; cursor: pointer;">
                            ← Назад
                        </button>
                        <button type="button" class="next-step" style="padding: 15px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer;">
                            Далее → Фото
                        </button>
                    </div>
                </div>

                <!-- Шаг 3: Загрузка фото -->
                <div class="form-step" id="step3">
                    <h2 style="color: #333; margin-bottom: 25px; text-align: center;">
                        <i class="fas fa-camera"></i> Добавьте фото
                    </h2>
                    
                    <div style="margin-bottom: 25px;">
                        <label style="display: block; margin-bottom: 15px; font-weight: 700; color: #333; font-size: 16px;">
                            📷 Фотографии объявления:
                        </label>
                        
                        <!-- Drag & Drop зона -->
                        <div id="dropZone" 
                             style="border: 3px dashed #667eea; border-radius: 16px; padding: 40px 20px; text-align: center; background: #f8f9ff; cursor: pointer; transition: all 0.3s; margin-bottom: 20px;">
                            <div id="dropContent">
                                <i class="fas fa-cloud-upload-alt" style="font-size: 52px; color: #667eea; margin-bottom: 15px;"></i>
                                <h3 style="color: #667eea; margin-bottom: 10px; font-weight: 600;">Добавьте фото</h3>
                                <p style="color: #6c757d; margin-bottom: 20px;">Перетащите сюда или нажмите для выбора</p>
                                <button type="button" id="selectFilesBtn" style="padding: 12px 30px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; border-radius: 25px; font-size: 16px; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-images"></i> Выбрать файлы
                                </button>
                            </div>
                        </div>
                        
                        <!-- Скрытое поле для файлов -->
                        <input type="file" id="fileInput" name="photos[]" multiple accept="image/*" style="display: none;">
                        
                        <!-- Preview галерея -->
                        <div id="previewGallery" style="display: none;">
                            <h4 style="color: #333; margin-bottom: 15px; font-weight: 600;">
                                <i class="fas fa-check-circle" style="color: #28a745;"></i> Выбранные фото:
                            </h4>
                            <div id="imagePreviews" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 12px; margin-bottom: 20px;"></div>
                            <div style="text-align: center;">
                                <button type="button" id="addMoreBtn" style="padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 8px; cursor: pointer;">
                                    <i class="fas fa-plus"></i> Добавить еще фото
                                </button>
                            </div>
                        </div>
                        
                        <div style="background: #e7f3ff; padding: 15px; border-radius: 10px; margin-top: 15px;">
                            <p style="margin: 0; color: #0066cc; font-size: 14px;">
                                <i class="fas fa-lightbulb"></i> <strong>Совет:</strong> Первое фото будет главным в объявлении. 
                                Добавьте 3-5 качественных фото для лучшего эффекта.
                            </p>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <button type="button" class="prev-step" style="padding: 15px; background: #6c757d; color: white; border: none; border-radius: 12px; font-size: 16px; cursor: pointer;">
                            ← Назад
                        </button>
                        <button type="submit" style="padding: 15px; background: linear-gradient(135deg, #28a745, #20c997); color: white; border: none; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer;">
                            <i class="fas fa-paper-plane"></i> Опубликовать
                        </button>
                    </div>
                </div>
            </div>
        </form>
        
        <div style="text-align: center; margin-top: 25px;">
            <a href="../../index.php" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 25px; background: white; color: #667eea; border: 2px solid #667eea; border-radius: 25px; text-decoration: none; font-weight: 600; transition: all 0.3s;">
                <i class="fas fa-arrow-left"></i> На главную
            </a>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Элементы
    const steps = document.querySelectorAll('.form-step');
    const nextButtons = document.querySelectorAll('.next-step');
    const prevButtons = document.querySelectorAll('.prev-step');
    const mainCategory = document.getElementById('mainCategory');
    const subcategoryContainer = document.getElementById('subcategoryContainer');
    const subCategory = document.getElementById('subCategory');
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const selectFilesBtn = document.getElementById('selectFilesBtn');
    const addMoreBtn = document.getElementById('addMoreBtn');
    const previewGallery = document.getElementById('previewGallery');
    const imagePreviews = document.getElementById('imagePreviews');
    const uploadForm = document.getElementById('uploadForm');
    
    let currentStep = 1;
    let selectedFiles = [];
    
    // Данные подкатегорий из PHP
    const subcategoriesData = <?php echo json_encode($subcategories_by_parent); ?>;
    
    // === УПРАВЛЕНИЕ ШАГАМИ ===
    function showStep(stepNumber) {
        steps.forEach(step => step.classList.remove('active'));
        document.getElementById(`step${stepNumber}`).classList.add('active');
        currentStep = stepNumber;
        
        // Обновляем прогресс
        updateProgress(stepNumber);
    }
    
    function updateProgress(step) {
        const progressSteps = document.querySelectorAll('.progress-steps .step');
        progressSteps.forEach((stepEl, index) => {
            if (index + 1 <= step) {
                stepEl.classList.add('active');
            } else {
                stepEl.classList.remove('active');
            }
        });
    }
    
    nextButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (validateStep(currentStep)) {
                showStep(currentStep + 1);
            }
        });
    });
    
    prevButtons.forEach(button => {
        button.addEventListener('click', function() {
            showStep(currentStep - 1);
        });
    });
    
    function validateStep(step) {
        switch(step) {
            case 1:
                if (!mainCategory.value) {
                    alert('Пожалуйста, выберите основную категорию');
                    return false;
                }
                if (!subCategory.value && document.querySelectorAll('#subCategory option').length > 1) {
                    alert('Пожалуйста, выберите подкатегорию');
                    return false;
                }
                return true;
            case 2:
                const title = document.querySelector('input[name="title"]');
                const description = document.querySelector('textarea[name="description"]');
                const phone = document.querySelector('input[name="phone"]');
                
                if (!title.value.trim()) {
                    alert('Пожалуйста, введите заголовок объявления');
                    title.focus();
                    return false;
                }
                if (!description.value.trim()) {
                    alert('Пожалуйста, добавьте описание');
                    description.focus();
                    return false;
                }
                if (!phone.value.trim()) {
                    alert('Пожалуйста, укажите телефон для связи');
                    phone.focus();
                    return false;
                }
                return true;
            default:
                return true;
        }
    }
    
    // === КАТЕГОРИИ И ПОДКАТЕГОРИИ ===
    mainCategory.addEventListener('change', function() {
        const parentId = this.value;
        subCategory.innerHTML = '<option value="">-- Выберите подкатегорию --</option>';
        
        if (parentId && subcategoriesData[parentId]) {
            subcategoriesData[parentId].forEach(subcat => {
                const option = document.createElement('option');
                option.value = subcat.id;
                option.textContent = subcat.name;
                subCategory.appendChild(option);
            });
            subcategoryContainer.style.display = 'block';
        } else {
            subcategoryContainer.style.display = 'none';
        }
    });
    
    // === ЗАГРУЗКА ФАЙЛОВ ===
    selectFilesBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        fileInput.click();
    });
    
    addMoreBtn?.addEventListener('click', function() {
        fileInput.click();
    });
    
    fileInput.addEventListener('change', handleFileSelect);
    
    // Drag & Drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.style.background = '#e3f2fd');
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.style.background = '#f8f9ff');
    });
    
    dropZone.addEventListener('drop', handleDrop, false);
    
    function handleDrop(e) {
        const files = e.dataTransfer.files;
        handleFiles(files);
    }
    
    function handleFileSelect(e) {
        const files = e.target.files;
        handleFiles(files);
    }
    
    function handleFiles(files) {
        const newFiles = Array.from(files);
        selectedFiles = [...selectedFiles, ...newFiles].slice(0, 10); // Максимум 10 файлов
        
        // Обновляем input
        const dataTransfer = new DataTransfer();
        selectedFiles.forEach(file => dataTransfer.items.add(file));
        fileInput.files = dataTransfer.files;
        
        // Показываем превью
        showPreviews(selectedFiles);
        updateDropZone();
    }
    
    function showPreviews(files) {
        imagePreviews.innerHTML = '';
        
        files.forEach((file, index) => {
            if (!file.type.match('image.*')) return;
            
            const reader = new FileReader();
            
            reader.onload = (function(file, index) {
                return function(e) {
                    const preview = document.createElement('div');
                    preview.style.position = 'relative';
                    preview.style.borderRadius = '12px';
                    preview.style.overflow = 'hidden';
                    preview.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
                    preview.style.transition = 'transform 0.2s';
                    
                    preview.addEventListener('mouseenter', () => preview.style.transform = 'scale(1.05)');
                    preview.addEventListener('mouseleave', () => preview.style.transform = 'scale(1)');
                    
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.width = '100%';
                    img.style.height = '120px';
                    img.style.objectFit = 'cover';
                    img.style.display = 'block';
                    
                    const removeBtn = document.createElement('button');
                    removeBtn.innerHTML = '×';
                    removeBtn.style.position = 'absolute';
                    removeBtn.style.top = '8px';
                    removeBtn.style.right = '8px';
                    removeBtn.style.background = 'rgba(255,0,0,0.8)';
                    removeBtn.style.color = 'white';
                    removeBtn.style.border = 'none';
                    removeBtn.style.borderRadius = '50%';
                    removeBtn.style.width = '28px';
                    removeBtn.style.height = '28px';
                    removeBtn.style.cursor = 'pointer';
                    removeBtn.style.fontSize = '18px';
                    removeBtn.style.fontWeight = 'bold';
                    removeBtn.style.transition = 'background 0.2s';
                    
                    removeBtn.addEventListener('mouseenter', () => removeBtn.style.background = 'rgba(255,0,0,1)');
                    removeBtn.addEventListener('mouseleave', () => removeBtn.style.background = 'rgba(255,0,0,0.8)');
                    
                    removeBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        removeFile(index);
                    });
                    
                    preview.appendChild(img);
                    preview.appendChild(removeBtn);
                    imagePreviews.appendChild(preview);
                };
            })(file, index);
            
            reader.readAsDataURL(file);
        });
        
        previewGallery.style.display = 'block';
    }
    
    function removeFile(index) {
        selectedFiles.splice(index, 1);
        
        // Обновляем input
        const dataTransfer = new DataTransfer();
        selectedFiles.forEach(file => dataTransfer.items.add(file));
        fileInput.files = dataTransfer.files;
        
        // Обновляем превью
        showPreviews(selectedFiles);
        updateDropZone();
    }
    
    function updateDropZone() {
        const dropContent = document.getElementById('dropContent');
        if (selectedFiles.length > 0) {
            dropContent.innerHTML = `
                <i class="fas fa-check-circle" style="font-size: 52px; color: #28a745; margin-bottom: 15px;"></i>
                <h3 style="color: #28a745; margin-bottom: 10px; font-weight: 600;">Добавлено ${selectedFiles.length} фото</h3>
                <p style="color: #6c757d;">Можно добавить еще ${10 - selectedFiles.length} фото</p>
            `;
        } else {
            dropContent.innerHTML = `
                <i class="fas fa-cloud-upload-alt" style="font-size: 52px; color: #667eea; margin-bottom: 15px;"></i>
                <h3 style="color: #667eea; margin-bottom: 10px; font-weight: 600;">Добавьте фото</h3>
                <p style="color: #6c757d; margin-bottom: 20px;">Перетащите сюда или нажмите для выбора</p>
                <button type="button" id="selectFilesBtn" style="padding: 12px 30px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; border-radius: 25px; font-size: 16px; font-weight: 600; cursor: pointer;">
                    <i class="fas fa-images"></i> Выбрать файлы
                </button>
            `;
            // Перепривязываем событие
            document.getElementById('selectFilesBtn').addEventListener('click', function(e) {
                e.stopPropagation();
                fileInput.click();
            });
            previewGallery.style.display = 'none';
        }
    }
    
    // === ВАЛИДАЦИЯ ПРИ ОТПРАВКЕ ===
    uploadForm.addEventListener('submit', function(e) {
        if (selectedFiles.length === 0) {
            e.preventDefault();
            alert('Пожалуйста, добавьте хотя бы одно фото для объявления');
            showStep(3); // Переходим к шагу с фото
            return;
        }
        
        // Показываем статус загрузки
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Публикуем...';
        submitBtn.disabled = true;
        
        // Через 5 секунд восстанавливаем кнопку (на случай ошибки)
        setTimeout(() => {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }, 5000);
    });
});

// Анимации
document.addEventListener('DOMContentLoaded', function() {
    const elements = document.querySelectorAll('.page-container > *');
    elements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'all 0.6s ease';
        
        setTimeout(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, index * 150);
    });
});
</script>

<style>
/* Стили прогресса */
.form-progress {
    background: white;
    padding: 20px;
    border-radius: 16px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.progress-steps {
    display: flex;
    justify-content: space-between;
    position: relative;
}

.progress-steps::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 3px;
    background: #e1e5e9;
    transform: translateY(-50%);
    z-index: 1;
}

.step {
    padding: 10px 20px;
    background: white;
    border: 2px solid #e1e5e9;
    border-radius: 25px;
    font-weight: 600;
    color: #6c757d;
    position: relative;
    z-index: 2;
    transition: all 0.3s;
    text-align: center;
    flex: 1;
    margin: 0 5px;
}

.step.active {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border-color: #667eea;
    transform: scale(1.05);
}

/* Стили шагов */
.form-step {
    display: none;
}

.form-step.active {
    display: block;
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Адаптивность */
@media (max-width: 768px) {
    .page-container > div {
        padding: 0 5px;
    }
    
    .progress-steps {
        flex-direction: column;
        gap: 10px;
    }
    
    .progress-steps::before {
        display: none;
    }
    
    .step {
        margin: 0;
    }
    
    .form-step .grid-2 {
        grid-template-columns: 1fr;
    }
    
    #imagePreviews {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
    }
    
    #dropZone {
        padding: 30px 15px;
    }
}

@media (max-width: 480px) {
    .header-title h1 {
        font-size: 24px;
    }
    
    .form-progress {
        padding: 15px;
    }
    
    .step {
        padding: 8px 15px;
        font-size: 14px;
    }
}

/* Улучшения для инпутов */
input, select, textarea {
    transition: all 0.3s ease;
}

input:focus, select:focus, textarea:focus {
    border-color: #667eea !important;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1) !important;
    outline: none;
}

/* Ховер эффекты */
button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}

#dropZone:hover {
    border-color: #5a67d8;
    background: #f0f4ff;
}
</style>

<?php include '../../includes/layout/footer.php'; ?>