<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$success = '';
$error = '';
$selected_files = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    if (empty($title) || empty($description) || $price <= 0 || $category_id <= 0) {
        $error = 'Заполните все обязательные поля';
    } else {
        $uploaded_images = [];
        $upload_dir = '../../uploads/ads/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // Сохраняем информацию о выбранных файлах для показа
        if(isset($_FILES['photos']) && is_array($_FILES['photos']['name'])) {
            foreach($_FILES['photos']['name'] as $key => $name) {
                if(!empty($name)) {
                    $selected_files[] = $name;
                    
                    if($_FILES['photos']['error'][$key] === 0) {
                        $file_tmp = $_FILES['photos']['tmp_name'][$key];
                        $file_new = uniqid() . '_' . $name;
                        $file_dest = $upload_dir . $file_new;
                        
                        if(move_uploaded_file($file_tmp, $file_dest)) {
                            $uploaded_images[] = $file_new;
                        }
                    }
                }
            }
        }
        
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $images_json = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
            
            $sql = "INSERT INTO ads (user_id, category_id, title, description, price, images, phone, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, '', NOW())";
            
            $stmt = $db->prepare($sql);
            
            if($stmt->execute([$user_id, $category_id, $title, $description, $price, $images_json])) {
                $success = '✅ Объявление успешно создано!';
                if(!empty($uploaded_images)) {
                    $success .= ' Загружено фото: ' . count($uploaded_images);
                    // Показываем какие именно файлы загружены
                    $success .= '<br>📁 Файлы: ' . implode(', ', $selected_files);
                } else {
                    $success .= ' (фото не загружены)';
                }
            } else {
                $error = '❌ Ошибка сохранения';
            }
        } catch (Exception $e) {
            $error = '❌ Ошибка базы данных: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить объявление</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            padding: 20px; 
            background: linear-gradient(135deg, #667eea, #764ba2);
            min-height: 100vh;
            margin: 0;
        }
        .form-container { 
            background: white; 
            padding: 30px; 
            border-radius: 15px; 
            max-width: 500px; 
            margin: 0 auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        h1 { 
            text-align: center; 
            color: #333; 
            margin-bottom: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .form-group { 
            margin: 25px 0; 
        }
        label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: bold; 
            color: #333;
        }
        input, textarea, select { 
            width: 100%; 
            padding: 15px; 
            border: 2px solid #ddd; 
            border-radius: 8px; 
            font-size: 16px;
            box-sizing: border-box;
        }
        input:focus, textarea:focus, select:focus {
            border-color: #667eea;
            outline: none;
        }
        .file-section {
            border: 3px dashed #28a745;
            border-radius: 10px;
            padding: 20px;
            background: #f8fff9;
            text-align: center;
            margin: 20px 0;
        }
        .file-input-wrapper {
            position: relative;
            display: inline-block;
            width: 100%;
        }
        .file-input {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .file-label {
            display: block;
            padding: 20px;
            background: #28a745;
            color: white;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .file-label:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        .selected-files {
            background: #e8f5e8;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            border-left: 4px solid #28a745;
        }
        .file-item {
            padding: 5px 0;
            border-bottom: 1px solid #d4edda;
        }
        .file-item:last-child {
            border-bottom: none;
        }
        button { 
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white; 
            padding: 18px; 
            border: none; 
            border-radius: 8px; 
            font-size: 18px; 
            width: 100%;
            cursor: pointer;
            font-weight: bold;
            margin-top: 10px;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
        }
        .message { 
            padding: 20px; 
            border-radius: 10px; 
            margin: 20px 0;
            text-align: center;
        }
        .success { 
            background: #d4edda; 
            color: #155724; 
            border: 2px solid #c3e6cb; 
        }
        .error { 
            background: #f8d7da; 
            color: #721c24; 
            border: 2px solid #f5c6cb; 
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
        }
        .file-info {
            background: #e7f3ff;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>📝 Добавить объявление</h1>
        
        <?php if($success): ?>
            <div class="message success">
                <?= $success ?>
                <br><br>
                <a href="../profile.php" class="back-link">← Перейти в профиль</a>
            </div>
        <?php elseif($error): ?>
            <div class="message error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post" enctype="multipart/form-data" id="adForm">
            <div class="form-group">
                <label>📝 Заголовок *</label>
                <input type="text" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label>📄 Описание *</label>
                <textarea name="description" rows="4" required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
            </div>
            
            <div class="form-group">
                <label>💰 Цена (руб) *</label>
                <input type="number" name="price" required min="1" value="<?= $_POST['price'] ?? '' ?>">
            </div>
            
            <div class="form-group">
                <label>📂 Категория *</label>
                <select name="category_id" required>
                    <option value="">-- Выберите категорию --</option>
                    <?php
                    $database = new Database();
                    $db = $database->getConnection();
                    $categories = $db->query("SELECT * FROM categories WHERE parent_id IS NULL")->fetchAll();
                    foreach($categories as $cat) {
                        $selected = ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '';
                        echo '<option value="' . $cat['id'] . '" ' . $selected . '>' . $cat['name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>📷 Фотографии</label>
                
                <div class="file-section">
                    <div class="file-input-wrapper">
                        <input type="file" name="photos[]" multiple accept="image/*" class="file-input" id="fileInput">
                        <label for="fileInput" class="file-label">
                            📁 ВЫБРАТЬ ФОТО
                        </label>
                    </div>
                    
                    <div class="file-info">
                        💡 Нажмите кнопку выше чтобы выбрать фото<br>
                        📸 Можно выбрать несколько файлов<br>
                        🖼️ Поддерживаются: JPG, PNG, GIF
                    </div>
                </div>
                
                <div class="selected-files" id="selectedFiles">
                    <strong>📋 Выбранные файлы:</strong>
                    <div id="filesList">Файлы не выбраны</div>
                </div>
            </div>
            
            <button type="submit">
                🚀 ОПУБЛИКОВАТЬ ОБЪЯВЛЕНИЕ
            </button>
        </form>
        
        <a href="../profile.php" class="back-link">← Назад в профиль</a>
    </div>

    <script>
    // ПРОСТОЙ И НАДЕЖНЫЙ СКРИПТ ДЛЯ ПОКАЗА ФАЙЛОВ
    document.getElementById('fileInput').addEventListener('change', function(e) {
        var filesList = document.getElementById('filesList');
        var selectedFiles = document.getElementById('selectedFiles');
        
        if (this.files.length > 0) {
            var html = '';
            for (var i = 0; i < this.files.length; i++) {
                html += '<div class="file-item">✅ ' + this.files[i].name + '</div>';
            }
            filesList.innerHTML = html;
            selectedFiles.style.display = 'block';
        } else {
            filesList.innerHTML = 'Файлы не выбраны';
            selectedFiles.style.display = 'block';
        }
    });
    
    // Показываем блок с выбранными файлами при загрузке страницы
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('selectedFiles').style.display = 'block';
    });
    </script>
</body>
</html>