<?php
echo "<!DOCTYPE html>
<html>
<head>
    <title>Тест выбора файлов</title>
    <style>
        body { font-family: Arial; max-width: 600px; margin: 0 auto; padding: 20px; }
        .test-section { border: 2px solid #007bff; padding: 20px; margin: 20px 0; border-radius: 10px; }
        input[type='file'] { padding: 20px; margin: 10px 0; width: 100%; box-sizing: border-box; }
        .result { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>🧪 Тест выбора файлов</h1>
    
    <div class='test-section'>
        <h3>Тест 1: Простой input file</h3>
        <input type='file' id='test1' onchange='showResult(\"test1\")'>
        <div class='result' id='result1'>Файлы не выбраны</div>
    </div>
    
    <div class='test-section'>
        <h3>Тест 2: Multiple files</h3>
        <input type='file' multiple id='test2' onchange='showResult(\"test2\")'>
        <div class='result' id='result2'>Файлы не выбраны</div>
    </div>
    
    <div class='test-section'>
        <h3>Тест 3: С атрибутом required</h3>
        <form onsubmit='return testSubmit()'>
            <input type='file' required id='test3' onchange='showResult(\"test3\")'>
            <div class='result' id='result3'>Файлы не выбраны</div>
            <button type='submit'>Проверить required</button>
        </form>
    </div>
    
    <script>
    function showResult(inputId) {
        const input = document.getElementById(inputId);
        const result = document.getElementById('result' + inputId.slice(-1));
        
        if (input.files.length > 0) {
            let html = '<strong style=\"color: green;\">✅ Выбрано файлов: ' + input.files.length + '</strong><br>';
            for(let i = 0; i < input.files.length; i++) {
                html += '📄 ' + input.files[i].name + ' (' + input.files[i].type + ')<br>';
            }
            result.innerHTML = html;
        } else {
            result.innerHTML = '<strong style=\"color: red;\">❌ Файлы не выбраны</strong>';
        }
    }
    
    function testSubmit() {
        const input = document.getElementById('test3');
        if (input.files.length === 0) {
            alert('⚠️ Required поле: выберите файл!');
            return false;
        }
        alert('✅ Required поле: файл выбран!');
        return false;
    }
    </script>
    
    <div style='margin-top: 30px;'>
        <a href='upload_ad.php'>📝 Основная форма</a> | 
        <a href='simple_upload.php'>🚀 Простая форма</a> |
        <a href='../profile.php'>👤 Профиль</a>
    </div>
</body>
</html>";
?>