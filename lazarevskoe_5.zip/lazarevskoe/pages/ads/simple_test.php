<?php
// Простой тест загрузки файлов
echo "<h1>🧪 Простой тест загрузки файлов</h1>";
echo "<p>Эта форма поможет проверить базовую загрузку файлов</p>";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['test_file'])) {
    echo "<h3>📊 Результат загрузки:</h3>";
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";
    
    if ($_FILES['test_file']['error'] === 0) {
        $upload_dir = '../../uploads/ads/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = uniqid() . '_' . $_FILES['test_file']['name'];
        $file_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['test_file']['tmp_name'], $file_path)) {
            echo "<div style='color: green;'>✅ Файл успешно загружен: " . $file_name . "</div>";
            echo "<div>📁 Путь: " . $file_path . "</div>";
            
            if (file_exists($file_path)) {
                echo "<div style='color: green;'>✅ Файл существует на сервере</div>";
                echo "<img src='$file_path' style='max-width: 300px; border: 2px solid green; margin: 10px 0;'>";
            } else {
                echo "<div style='color: red;'>❌ Файл не найден после загрузки</div>";
            }
        } else {
            echo "<div style='color: red;'>❌ Ошибка перемещения файла</div>";
        }
    } else {
        echo "<div style='color: red;'>❌ Ошибка загрузки: код " . $_FILES['test_file']['error'] . "</div>";
    }
    
    echo "<hr>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Простой тест загрузки</title>
    <style>
        body { font-family: Arial; max-width: 600px; margin: 0 auto; padding: 20px; }
        .form-group { margin: 20px 0; }
        input, button { padding: 10px; margin: 5px 0; }
        button { background: #007bff; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <h2>📤 Тестовая форма загрузки</h2>
    
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Выберите тестовый файл:</label><br>
            <input type="file" name="test_file" accept="image/*" required>
        </div>
        
        <div class="form-group">
            <button type="submit">🚀 Проверить загрузку</button>
        </div>
    </form>
    
    <div style="margin-top: 30px; padding: 15px; background: #f8f9fa; border-radius: 5px;">
        <h3>💡 Что проверяем:</h3>
        <ul>
            <li>Выбор файла в форме</li>
            <li>Загрузку на сервер</li>
            <li>Сохранение в папку uploads</li>
            <li>Отображение изображения</li>
        </ul>
    </div>
    
    <div style="margin-top: 20px;">
        <a href="/">← На главную</a> | 
        <a href="../profile.php">👤 Профиль</a>
    </div>
</body>
</html>
