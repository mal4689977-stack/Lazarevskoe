<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

$page_title = "Добавить объявление - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';

$database = new Database();
$db = $database->getConnection();

$categories = $db->query("
    SELECT id, name 
    FROM categories 
    WHERE parent_id IS NOT NULL 
    ORDER BY name
")->fetchAll();
?>

<div class="header-title">
    <h1>Добавить объявление</h1>
    <small>Исправленная версия формы</small>
</div>

<div class="page-container">
    <div style="max-width: 600px; margin: 0 auto;">
        
        <div style="text-align: center; margin-bottom: 20px; padding: 15px; background: #e3f2fd; border-radius: 10px;">
            <h4 style="color: #1976d2; margin: 0;">🔄 Исправленная форма загрузки</h4>
        </div>

        <!-- ПРОСТАЯ ТЕСТОВАЯ ФОРМА -->
        <div style="background: var(--light); padding: 30px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h3 style="color: var(--primary); margin-bottom: 15px;">🧪 Тестовая форма</h3>
            <form action="process_ad_simple.php" method="POST" enctype="multipart/form-data">
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Категория:</label>
                    <select name="category_id" required style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px;">
                        <option value="">-- Выберите категорию --</option>
                        <?php foreach($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Заголовок:</label>
                    <input type="text" name="title" required placeholder="Тестовое объявление" style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px;">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">Файлы:</label>
                    <input type="file" name="photos[]" multiple accept="image/*" style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px;">
                    <small style="color: var(--secondary);">Можно выбрать несколько файлов</small>
                </div>
                
                <input type="hidden" name="description" value="Тестовое описание">
                <input type="hidden" name="price" value="1000">
                <input type="hidden" name="location" value="Тест">
                <input type="hidden" name="phone" value="+79991234567">
                <input type="hidden" name="email" value="test@test.ru">
                
                <button type="submit" class="cta-button" style="width: 100%; background: var(--success);">
                    <i class="fas fa-paper-plane"></i> Протестировать загрузку
                </button>
            </form>
        </div>

        <!-- Оригинальная форма (для сравнения) -->
        <div style="background: #fff3cd; padding: 20px; border-radius: 10px;">
            <h4 style="color: #856404;">📝 Оригинальная форма</h4>
            <a href="create.php" style="color: #007bff;">Вернуться к оригинальной форме →</a>
        </div>
    </div>
</div>

<?php include '../../includes/layout/footer.php'; ?>