<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Диагностика</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .section { background: white; padding: 20px; margin: 15px 0; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .debug { background: #fff3cd; padding: 15px; border-radius: 8px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>🔧 ДИАГНОСТИКА ФОРМЫ</h1>";

// ТЕСТ 1: Проверка сессии и прав
echo "<div class='section'>
    <h2>🔐 Проверка сессии и прав</h2>
    <pre>";
echo "User ID: " . ($_SESSION['user_id'] ?? 'НЕТ') . "\n";
echo "User Name: " . ($_SESSION['user_name'] ?? 'НЕТ') . "\n";
echo "Session статус: " . (session_status() === PHP_SESSION_ACTIVE ? 'АКТИВНА' : 'НЕАКТИВНА') . "\n";
echo "</pre>
</div>";

// ТЕСТ 2: Проверка загрузки файлов
echo "<div class='section'>
    <h2>📁 Тест загрузки файлов</h2>
    <form method='post' enctype='multipart/form-data'>
        <input type='hidden' name='test_type' value='file_upload'>
        <div style='margin: 15px 0;'>
            <strong>Выберите файл:</strong><br>
            <input type='file' name='test_file' required style='padding: 10px; margin: 10px 0;'>
        </div>
        <button type='submit' style='padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px;'>Тестировать загрузку</button>
    </form>";

if ($_POST['test_type'] ?? '' === 'file_upload') {
    echo "<div class='debug'>
        <h3>📊 РЕЗУЛЬТАТ ТЕСТА:</h3>
        <strong>Данные FILES:</strong>
        <pre>";
    print_r($_FILES);
    echo "</pre>";
    
    if (isset($_FILES['test_file'])) {
        echo "<strong>Информация о файле:</strong><br>";
        echo "Имя: " . ($_FILES['test_file']['name'] ?? 'НЕТ') . "<br>";
        echo "Размер: " . ($_FILES['test_file']['size'] ?? '0') . " байт<br>";
        echo "Тип: " . ($_FILES['test_file']['type'] ?? 'НЕТ') . "<br>";
        echo "Временный файл: " . ($_FILES['test_file']['tmp_name'] ?? 'НЕТ') . "<br>";
        echo "Ошибка: " . ($_FILES['test_file']['error'] ?? '0') . "<br>";
        
        if ($_FILES['test_file']['error'] === 0) {
            $upload_dir = '../../uploads/ads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $new_name = 'diagnostic_' . uniqid() . '_' . $_FILES['test_file']['name'];
            $dest = $upload_dir . $new_name;
            
            if (move_uploaded_file($_FILES['test_file']['tmp_name'], $dest)) {
                echo "<p class='success'>✅ Файл успешно сохранен: " . $new_name . "</p>";
                echo "<p>Полный путь: " . realpath($dest) . "</p>";
                
                if (file_exists($dest)) {
                    echo "<p class='success'>✅ Файл существует на сервере</p>";
                    echo "<img src='$dest' style='max-width: 300px; border: 2px solid green;'>";
                }
            } else {
                echo "<p class='error'>❌ Ошибка сохранения файла</p>";
            }
        } else {
            echo "<p class='error'>❌ Ошибка загрузки: код " . $_FILES['test_file']['error'] . "</p>";
        }
    } else {
        echo "<p class='error'>❌ Файл не пришел в \$_FILES</p>";
    }
    echo "</div>";
}
echo "</div>";

// ТЕСТ 3: Проверка основной формы
echo "<div class='section'>
    <h2>📝 Тест основной формы (photos[])</h2>
    <form method='post' enctype='multipart/form-data'>
        <input type='hidden' name='test_type' value='main_form'>
        
        <div style='margin: 10px 0;'>
            <strong>Заголовок:</strong><br>
            <input type='text' name='title' value='Тестовое объявление' required style='width: 100%; padding: 8px;'>
        </div>
        
        <div style='margin: 10px 0;'>
            <strong>Фотографии (photos[]):</strong><br>
            <input type='file' name='photos[]' multiple accept='image/*' style='padding: 10px; margin: 10px 0;'>
            <div style='background: #e7f3ff; padding: 10px; border-radius: 5px;'>
                💡 Это поле name='photos[]' как в основной форме
            </div>
        </div>
        
        <button type='submit' style='padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 5px;'>Тестировать основную форму</button>
    </form>";

if ($_POST['test_type'] ?? '' === 'main_form') {
    echo "<div class='debug'>
        <h3>📊 РЕЗУЛЬТАТ ОСНОВНОЙ ФОРМЫ:</h3>
        <strong>POST данные:</strong>
        <pre>";
    print_r($_POST);
    echo "</pre>
        <strong>FILES данные (photos[]):</strong>
        <pre>";
    print_r($_FILES);
    echo "</pre>";
    
    if (isset($_FILES['photos']) && is_array($_FILES['photos']['name'])) {
        $file_count = count(array_filter($_FILES['photos']['name']));
        if ($file_count > 0) {
            echo "<p class='success'>✅ Файлы пришли в \$_FILES['photos']: " . $file_count . " файл(ов)</p>";
            
            // Пробуем сохранить
            $upload_dir = '../../uploads/ads/';
            $uploaded_count = 0;
            
            foreach($_FILES['photos']['name'] as $key => $name) {
                if(!empty($name) && $_FILES['photos']['error'][$key] === 0) {
                    $file_new = uniqid() . '_' . $name;
                    $file_dest = $upload_dir . $file_new;
                    
                    if(move_uploaded_file($_FILES['photos']['tmp_name'][$key], $file_dest)) {
                        $uploaded_count++;
                        echo "<p class='success'>✅ Сохранен: " . $file_new . "</p>";
                    }
                }
            }
            
            echo "<p class='success'>✅ Итого сохранено: " . $uploaded_count . " файл(ов)</p>";
            
        } else {
            echo "<p class='error'>❌ Файлы НЕ пришли в \$_FILES['photos']</p>";
        }
    } else {
        echo "<p class='error'>❌ \$_FILES['photos'] не существует или не массив</p>";
    }
    echo "</div>";
}
echo "</div>";

// ТЕСТ 4: Проверка сохранения в БД
echo "<div class='section'>
    <h2>💾 Тест сохранения в БД</h2>
    <form method='post'>
        <input type='hidden' name='test_type' value='db_test'>
        <button type='submit' style='padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px;'>Тестировать подключение к БД</button>
    </form>";

if ($_POST['test_type'] ?? '' === 'db_test') {
    echo "<div class='debug'>
        <h3>📊 РЕЗУЛЬТАТ ПРОВЕРКИ БД:</h3>";
    
    try {
        $database = new Database();
        $db = $database->getConnection();
        
        echo "<p class='success'>✅ Подключение к БД успешно</p>";
        
        // Пробуем вставить тестовую запись
        $test_title = 'Тест ' . uniqid();
        $test_images = json_encode(['test1.jpg', 'test2.jpg']);
        
        $sql = "INSERT INTO ads (user_id, category_id, title, description, price, images, phone, created_at) 
                VALUES (?, 1, ?, 'Тестовое описание', 1000, ?, '', NOW())";
        
        $stmt = $db->prepare($sql);
        
        if($stmt->execute([$_SESSION['user_id'], $test_title, $test_images])) {
            $ad_id = $db->lastInsertId();
            echo "<p class='success'>✅ Запись успешно сохранена в БД! ID: " . $ad_id . "</p>";
            
            // Проверяем что запись есть
            $check_sql = "SELECT * FROM ads WHERE id = ?";
            $check_stmt = $db->prepare($check_sql);
            $check_stmt->execute([$ad_id]);
            $ad = $check_stmt->fetch();
            
            if ($ad) {
                echo "<p class='success'>✅ Запись найдена в БД</p>";
                echo "<pre>";
                print_r($ad);
                echo "</pre>";
            }
        } else {
            echo "<p class='error'>❌ Ошибка сохранения в БД</p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='error'>❌ Ошибка БД: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
}
echo "</div>";

echo "<div style='text-align: center; margin-top: 30px;'>
        <a href='../profile.php' style='color: #007bff;'>← Назад в профиль</a>
    </div>";

echo "</body></html>";
?>