<?php
echo "<!DOCTYPE html>
<html>
<head>
    <title>Проверка сервера</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .section { background: white; padding: 20px; margin: 15px 0; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .good { color: green; font-weight: bold; }
        .bad { color: red; font-weight: bold; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>🔧 Проверка настроек сервера</h1>";

// Проверяем настройки загрузки файлов
echo "<div class='section'>
    <h2>📁 Настройки загрузки файлов</h2>
    <pre>";
echo "file_uploads: " . ini_get('file_uploads') . "\n";
echo "upload_max_filesize: " . ini_get('upload_max_filesize') . "\n";
echo "post_max_size: " . ini_get('post_max_size') . "\n"; 
echo "max_file_uploads: " . ini_get('max_file_uploads') . "\n";
echo "max_execution_time: " . ini_get('max_execution_time') . "\n";
echo "memory_limit: " . ini_get('memory_limit') . "\n";
echo "</pre>";

// Проверяем временную папку
echo "<h2>📂 Временная папка</h2>
    <pre>";
$upload_tmp_dir = ini_get('upload_tmp_dir') ?: sys_get_temp_dir();
echo "upload_tmp_dir: " . $upload_tmp_dir . "\n";
echo "Существует: " . (is_dir($upload_tmp_dir) ? 'ДА' : 'НЕТ') . "\n";
echo "Доступна для записи: " . (is_writable($upload_tmp_dir) ? 'ДА' : 'НЕТ') . "\n";
echo "</pre>";

// Проверяем папку загрузок
echo "<h2>📂 Папка загрузок</h2>
    <pre>";
$upload_dir = '../../uploads/ads/';
echo "upload_dir: " . realpath($upload_dir) . "\n";
echo "Существует: " . (is_dir($upload_dir) ? 'ДА' : 'НЕТ') . "\n";
echo "Доступна для записи: " . (is_writable($upload_dir) ? 'ДА' : 'НЕТ') . "\n";
echo "</pre>";

// Проверяем информацию о сервере
echo "<h2>🖥️ Информация о сервере</h2>
    <pre>";
echo "PHP Version: " . phpversion() . "\n";
echo "Server Software: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Неизвестно') . "\n";
echo "Document Root: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'Неизвестно') . "\n";
echo "</pre>";
echo "</div>";

// Тестовая форма
echo "<div class='section'>
    <h2>🧪 Тест загрузки маленького файла</h2>
    <form method='post' enctype='multipart/form-data'>
        <input type='file' name='test_file' required>
        <button type='submit'>Тестировать загрузку</button>
    </form>";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['test_file'])) {
    echo "<h3>Результат:</h3>
        <pre>";
    print_r($_FILES['test_file']);
    echo "</pre>";
    
    if ($_FILES['test_file']['error'] === 0) {
        echo "<p class='good'>✅ Файл успешно загружен!</p>";
    } else {
        echo "<p class='bad'>❌ Ошибка: " . $_FILES['test_file']['error'] . " - ";
        switch($_FILES['test_file']['error']) {
            case 1: echo 'Файл слишком большой (UPLOAD_ERR_INI_SIZE)'; break;
            case 2: echo 'Файл слишком большой (UPLOAD_ERR_FORM_SIZE)'; break;
            case 3: echo 'Файл загружен частично'; break;
            case 4: echo 'Файл не был загружен'; break;
            case 6: echo 'Отсутствует временная папка'; break;
            case 7: echo 'Ошибка записи на диск'; break;
            case 8: echo 'PHP расширение остановило загрузку'; break;
            default: echo 'Неизвестная ошибка'; break;
        }
        echo "</p>";
    }
}

echo "</div>";

echo "<div class='section'>
    <h2>💡 Рекомендации</h2>
    <p>Если <strong>upload_max_filesize</strong> маленький, создай файл <strong>.htaccess</strong> в корне сайта:</p>
    <pre>
php_value upload_max_filesize 20M
php_value post_max_size 20M  
php_value max_execution_time 300
php_value memory_limit 256M
    </pre>
    </div>";

echo "</body></html>";
?>