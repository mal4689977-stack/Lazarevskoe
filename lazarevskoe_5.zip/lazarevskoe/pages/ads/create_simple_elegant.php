<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

$page_title = "Добавить объявление - Лазаревское";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';

$database = new Database();
$db = $database->getConnection();

// Получаем все категории
$categories = $db->query("
    SELECT id, name 
    FROM categories 
    WHERE parent_id IS NOT NULL 
    ORDER BY name
")->fetchAll();
?>

<div class="header-title">
    <h1>Добавить объявление</h1>
    <small>Расскажите о вашем предложении</small>
</div>

<div class="page-container">
    <div style="max-width: 600px; margin: 0 auto;">
        
        <!-- Информация о форме -->
        <div style="text-align: center; margin-bottom: 30px; padding: 20px; background: var(--light); border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            <h3 style="color: var(--success); margin-bottom: 10px;">✨ Создайте объявление</h3>
            <p style="color: var(--text);">Заполните форму ниже чтобы добавить ваше предложение</p>
        </div>

        <form action="process_ad_simple.php" method="POST" enctype="multipart/form-data" 
              style="background: var(--light); padding: 30px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            
            <!-- Категория -->
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                    <i class="fas fa-tag"></i> Категория:
                </label>
                <select name="category_id" required 
                        style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px; background: white;">
                    <option value="">-- Выберите категорию --</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>">
                            <?php echo htmlspecialchars($cat['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Заголовок -->
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                    <i class="fas fa-heading"></i> Заголовок:
                </label>
                <input type="text" name="title" required placeholder="Уютная квартира у моря" 
                       style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
            </div>
            
            <!-- Описание -->
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                    <i class="fas fa-align-left"></i> Описание:
                </label>
                <textarea name="description" required rows="4" placeholder="Подробное описание вашего предложения..."
                          style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;"></textarea>
            </div>

            <!-- Цена и локация -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-ruble-sign"></i> Цена (руб):
                    </label>
                    <input type="number" name="price" placeholder="1500" 
                           style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
                </div>
                
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-map-marker-alt"></i> Местоположение:
                    </label>
                    <input type="text" name="location" placeholder="ул. Победы, 15" 
                           style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
                </div>
            </div>

            <!-- Контакты -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-phone"></i> Телефон:
                    </label>
                    <input type="tel" name="phone" required placeholder="+7 999 123-45-67" 
                           style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
                </div>
                
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                        <i class="fas fa-envelope"></i> Email:
                    </label>
                    <input type="email" name="email" placeholder="your@email.ru" 
                           style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px; font-size: 16px;">
                </div>
            </div>

            <!-- Фотографии - ПРОСТОЙ ВАРИАНТ -->
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--primary);">
                    <i class="fas fa-camera"></i> Фотографии:
                </label>
                
                <div style="border: 2px dashed var(--gray); border-radius: 10px; padding: 20px; text-align: center; background: #fafafa; margin-bottom: 10px;">
                    <input type="file" name="photos[]" multiple accept="image/jpeg,image/png" 
                           style="width: 100%; padding: 10px; border-radius: 5px;">
                </div>
                
                <small style="color: var(--secondary);">
                    <i class="fas fa-info-circle"></i> Можно выбрать несколько фото. Форматы: JPG, PNG
                </small>
            </div>
            
            <!-- Кнопка отправки -->
            <button type="submit" class="cta-button" style="width: 100%; background: var(--success); font-size: 16px;">
                <i class="fas fa-paper-plane"></i> Опубликовать объявление
            </button>
        </form>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="../../index.php" class="profile-btn secondary" style="text-decoration: none;">
                <i class="fas fa-arrow-left"></i> На главную
            </a>
        </div>
    </div>
</div>

<script>
// Простая валидация формы
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    
    form.addEventListener('submit', function(e) {
        const category = document.querySelector('select[name="category_id"]');
        const files = document.querySelector('input[name="photos[]"]');
        
        // Проверка категории
        if (!category.value) {
            e.preventDefault();
            alert('Пожалуйста, выберите категорию');
            category.focus();
            return;
        }
        
        // Проверка файлов (необязательно, но желательно)
        if (!files.files.length) {
            if (!confirm('Вы не добавили фотографии. Продолжить без фото?')) {
                e.preventDefault();
                files.focus();
                return;
            }
        }
        
        // Показываем статус загрузки
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Публикуем...';
        submitBtn.disabled = true;
    });
});
</script>

<?php include '../../includes/layout/footer.php'; ?>