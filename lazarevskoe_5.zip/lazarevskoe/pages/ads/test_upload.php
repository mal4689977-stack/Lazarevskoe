<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тест загрузки изображений</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .form-group { margin: 15px 0; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, textarea, select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .result { margin: 20px 0; padding: 15px; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .debug-info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>🧪 Тест загрузки изображений</h1>
    
    <div class="debug-info">
        <h3>📝 Информация:</h3>
        <p><strong>Папка загрузки:</strong> uploads/ads/</p>
        <p><strong>Разрешенные типы:</strong> JPG, PNG, GIF, WebP</p>
        <p><strong>Макс. размер:</strong> 5MB</p>
    </div>

    <form action="test_upload_process.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Заголовок объявления:</label>
            <input type="text" id="title" name="title" value="Тестовое объявление" required>
        </div>
        
        <div class="form-group">
            <label for="description">Описание:</label>
            <textarea id="description" name="description" rows="4" required>Тестовое описание</textarea>
        </div>
        
        <div class="form-group">
            <label for="price">Цена (руб):</label>
            <input type="number" id="price" name="price" value="1000" required>
        </div>
        
        <div class="form-group">
            <label for="category">Категория:</label>
            <select id="category" name="category_id" required>
                <option value="1">Недвижимость</option>
                <option value="2">Транспорт</option>
                <option value="3">Электроника</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="photos">Изображения (можно выбрать несколько):</label>
            <input type="file" id="photos" name="photos[]" multiple accept="image/*" required>
            <small>Выберите 1-5 изображений</small>
        </div>
        
        <button type="submit">📤 Загрузить тестовое объявление</button>
    </form>
    
    <div style="margin-top: 30px;">
        <a href="debug_images.php" style="color: #007bff;">🔍 Перейти к отладке изображений</a> |
        <a href="upload_ad.php" style="color: #007bff;">📝 Основная форма добавления</a> |
        <a href="../profile.php" style="color: #007bff;">👤 Вернуться в профиль</a>
    </div>
</body>
</html>