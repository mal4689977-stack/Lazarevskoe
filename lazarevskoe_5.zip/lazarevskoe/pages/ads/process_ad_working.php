<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: create.php');
    exit;
}

$database = new Database();
$db = $database->getConnection();

// Получаем данные из формы
$user_id = $_SESSION['user_id'];
$category_id = $_POST['category_id'] ?? '';
$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$price = !empty($_POST['price']) ? floatval($_POST['price']) : null;
$location = trim($_POST['location'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');

// Валидация
$errors = [];
if (empty($category_id)) $errors[] = "Выберите категорию";
if (empty($title)) $errors[] = "Введите заголовок";
if (empty($description)) $errors[] = "Введите описание";
if (empty($phone)) $errors[] = "Введите телефон";

if (!empty($errors)) {
    showErrorPage($errors);
    exit;
}

// Обработка фото - УПРОЩЕННАЯ И РАБОЧАЯ ВЕРСИЯ
$uploaded_images = [];
if (isset($_FILES['photos']) && !empty($_FILES['photos']['name'][0])) {
    $upload_dir = '../../uploads/ads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
    
    for ($i = 0; $i < count($_FILES['photos']['name']); $i++) {
        if ($_FILES['photos']['error'][$i] === UPLOAD_ERR_OK) {
            $original_name = $_FILES['photos']['name'][$i];
            $file_extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
            $file_name = uniqid() . '_' . $original_name;
            $file_path = $upload_dir . $file_name;
            
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (in_array($file_extension, $allowed_extensions)) {
                if (move_uploaded_file($_FILES['photos']['tmp_name'][$i], $file_path)) {
                    $uploaded_images[] = $file_name;
                }
            }
            
            if (count($uploaded_images) >= 10) break;
        }
    }
}

// Сохраняем в базу
try {
    $images_data = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
    
    $stmt = $db->prepare("
        INSERT INTO ads (user_id, category_id, title, description, price, location, phone, email, images, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
    ");
    
    $stmt->execute([
        $user_id, 
        $category_id, 
        $title, 
        $description, 
        $price, 
        $location, 
        $phone, 
        $email,
        $images_data
    ]);
    
    $ad_id = $db->lastInsertId();
    
    // Показываем успех с информацией о загруженных файлах
    showSuccessPage($title, $category_id, $price, $location, $db, count($uploaded_images));
    
} catch (Exception $e) {
    showErrorPage(["Ошибка сохранения: " . $e->getMessage()]);
}

function showErrorPage($errors) {
    $page_title = "Ошибка - Лазаревское";
    include '../../includes/layout/header-catalog.php';
    include '../../includes/layout/utility-bar.php';
    
    echo '<div class="page-container">';
    echo '<div style="max-width: 600px; margin: 0 auto; text-align: center;">';
    echo '<div style="background: var(--light); padding: 30px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">';
    echo '<h2 style="color: var(--error); margin-bottom: 20px;">❌ Ошибки в форме</h2>';
    
    // Показываем информацию о загрузке файлов
    if (isset($_FILES['photos'])) {
        echo '<div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: left;">';
        echo '<h4>Информация о файлах:</h4>';
        echo '<p><strong>Файлов в запросе:</strong> ' . count($_FILES['photos']['name']) . '</p>';
        echo '<p><strong>Имена файлов:</strong> ' . implode(', ', $_FILES['photos']['name']) . '</p>';
        echo '</div>';
    }
    
    foreach ($errors as $error) {
        echo '<div style="background: var(--error); color: white; padding: 10px; border-radius: 8px; margin-bottom: 10px;">' . htmlspecialchars($error) . '</div>';
    }
    echo '<a href="create.php" class="cta-button" style="display: inline-block; margin-top: 20px;">← Вернуться к форме</a>';
    echo '</div></div></div>';
    include '../../includes/layout/footer.php';
    exit;
}

function showSuccessPage($title, $category_id, $price, $location, $db, $files_count = 0) {
    $page_title = "Успех - Лазаревское";
    include '../../includes/layout/header-catalog.php';
    include '../../includes/layout/utility-bar.php';
    
    echo '<div class="page-container">';
    echo '<div style="max-width: 600px; margin: 0 auto; text-align: center;">';
    echo '<div style="background: var(--light); padding: 40px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">';
    
    echo '<div style="font-size: 48px; color: var(--success); margin-bottom: 20px;">🎉</div>';
    echo '<h2 style="color: var(--success); margin-bottom: 15px;">Объявление успешно создано!</h2>';
    echo '<p style="color: var(--text); margin-bottom: 10px;">Загружено файлов: <strong>' . $files_count . '</strong></p>';
    
    echo '<div style="background: var(--gray); padding: 20px; border-radius: 10px; margin-bottom: 25px; text-align: left;">';
    echo '<h4 style="color: var(--primary); margin-bottom: 10px;">Информация:</h4>';
    echo '<p><strong>Заголовок:</strong> ' . htmlspecialchars($title) . '</p>';
    echo '<p><strong>Категория:</strong> ' . htmlspecialchars(getCategoryName($db, $category_id)) . '</p>';
    if ($price) echo '<p><strong>Цена:</strong> ' . number_format($price, 0, '', ' ') . ' ₽</p>';
    if ($location) echo '<p><strong>Местоположение:</strong> ' . htmlspecialchars($location) . '</p>';
    echo '<p><strong>Статус:</strong> <span style="color: var(--accent);">Активно</span></p>';
    echo '</div>';
    
    echo '<div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">';
    echo '<a href="create.php" class="cta-button" style="text-decoration: none;">➕ Добавить еще</a>';
    echo '<a href="../../profile.php" class="profile-btn" style="text-decoration: none;">👤 Мой профиль</a>';
    echo '<a href="../../index.php" class="profile-btn secondary" style="text-decoration: none;">🏠 На главную</a>';
    echo '</div>';
    
    echo '</div></div></div>';
    include '../../includes/layout/footer.php';
    exit;
}

function getCategoryName($db, $category_id) {
    $stmt = $db->prepare("SELECT name FROM categories WHERE id = ?");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch();
    return $category['name'] ?? 'Неизвестная категория';
}
?>
