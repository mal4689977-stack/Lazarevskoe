<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    if (empty($title) || empty($description) || $price <= 0 || $category_id <= 0) {
        $error = 'Заполните все обязательные поля';
    } else {
        $uploaded_images = [];
        $upload_dir = '../../uploads/ads/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // ОБРАБОТКА МНОЖЕСТВЕННЫХ ФАЙЛОВ
        if(isset($_FILES['photos']) && is_array($_FILES['photos']['name'])) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            
            // Обрабатываем каждый файл
            for($i = 0; $i < count($_FILES['photos']['name']); $i++) {
                if($_FILES['photos']['error'][$i] === 0 && $_FILES['photos']['name'][$i] != '') {
                    $file_type = $_FILES['photos']['type'][$i];
                    if(in_array($file_type, $allowed_types)) {
                        $file_tmp = $_FILES['photos']['tmp_name'][$i];
                        $file_name = $_FILES['photos']['name'][$i];
                        
                        // Генерируем уникальное имя
                        $file_new = uniqid() . '_' . $file_name;
                        $file_dest = $upload_dir . $file_new;
                        
                        if(move_uploaded_file($file_tmp, $file_dest)) {
                            $uploaded_images[] = $file_new;
                        }
                    }
                }
            }
        }
        
        // Сохраняем в базу данных
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $images_json = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
            
            $sql = "INSERT INTO ads (user_id, category_id, title, description, price, images, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, NOW())";
            
            $stmt = $db->prepare($sql);
            
            if($stmt->execute([$user_id, $category_id, $title, $description, $price, $images_json])) {
                $success = 'Объявление успешно создано! Загружено фото: ' . count($uploaded_images);
                $_POST = [];
            } else {
                $error = 'Ошибка сохранения в базу данных';
            }
        } catch (Exception $e) {
            $error = 'Ошибка базы данных: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить объявление</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 20px;
            background: #f5f5f5;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group { 
            margin: 20px 0; 
        }
        label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: bold;
            color: #333;
        }
        input, textarea, select { 
            width: 100%; 
            padding: 12px; 
            border: 2px solid #ddd; 
            border-radius: 5px; 
            box-sizing: border-box;
            font-size: 16px;
        }
        .file-input {
            padding: 20px;
            border: 2px dashed #007bff;
            border-radius: 10px;
            background: #f8f9fa;
            text-align: center;
            cursor: pointer;
        }
        .file-input:hover {
            background: #e9ecef;
        }
        .file-info {
            margin-top: 10px;
            font-size: 14px;
            color: #666;
        }
        .selected-files {
            margin-top: 10px;
            padding: 10px;
            background: #e8f5e8;
            border-radius: 5px;
            display: none;
        }
        button { 
            background: #007bff; 
            color: white; 
            padding: 15px 40px; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            font-size: 18px;
            width: 100%;
            margin-top: 20px;
        }
        button:hover { 
            background: #0056b3; 
        }
        .message { 
            padding: 15px; 
            border-radius: 5px; 
            margin: 20px 0;
            text-align: center;
            font-weight: bold;
        }
        .success { 
            background: #d4edda; 
            color: #155724; 
            border: 1px solid #c3e6cb; 
        }
        .error { 
            background: #f8d7da; 
            color: #721c24; 
            border: 1px solid #f5c6cb; 
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1 style="text-align: center; color: #333; margin-bottom: 30px;">📝 Добавить объявление</h1>
        
        <?php if($success): ?>
            <div class="message success">
                <?= $success ?>
                <br><br>
                <a href="../profile.php" style="color: #155724; text-decoration: underline;">← Перейти в профиль</a>
            </div>
        <?php elseif($error): ?>
            <div class="message error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Заголовок *</label>
                <input type="text" id="title" name="title" required 
                       value="<?= htmlspecialchars($_POST['title'] ?? '') ?>"
                       placeholder="Например: iPhone 13 Pro">
            </div>
            
            <div class="form-group">
                <label for="description">Описание *</label>
                <textarea id="description" name="description" rows="5" required 
                          placeholder="Подробное описание товара..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="price">Цена (руб) *</label>
                <input type="number" id="price" name="price" required min="1" 
                       value="<?= $_POST['price'] ?? '' ?>"
                       placeholder="1000">
            </div>
            
            <div class="form-group">
                <label for="category_id">Категория *</label>
                <select id="category_id" name="category_id" required>
                    <option value="">Выберите категорию</option>
                    <?php
                    $database = new Database();
                    $db = $database->getConnection();
                    $categories = $db->query("SELECT * FROM categories WHERE parent_id IS NULL")->fetchAll();
                    foreach($categories as $cat) {
                        $selected = ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '';
                        echo '<option value="' . $cat['id'] . '" ' . $selected . '>' . $cat['name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="photos">Фотографии (можно выбрать несколько)</label>
                <div class="file-input" onclick="document.getElementById('photos').click()">
                    📷 Нажмите чтобы выбрать фото
                    <div class="file-info">
                        ✅ Можно выбрать несколько файлов одновременно<br>
                        📸 Поддерживаются: JPG, PNG, GIF, WebP
                    </div>
                </div>
                <input type="file" id="photos" name="photos[]" multiple accept="image/*" style="display: none;" 
                       onchange="showSelectedFiles(this)">
                <div class="selected-files" id="selectedFiles">
                    Выбранные файлы:
                    <div id="fileList"></div>
                </div>
            </div>
            
            <button type="submit">📤 Опубликовать объявление</button>
        </form>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="../profile.php" style="color: #007bff; text-decoration: none;">← Назад в профиль</a>
        </div>
    </div>

    <script>
    function showSelectedFiles(input) {
        const selectedFiles = document.getElementById('selectedFiles');
        const fileList = document.getElementById('fileList');
        
        if (input.files.length > 0) {
            fileList.innerHTML = '';
            for (let i = 0; i < input.files.length; i++) {
                fileList.innerHTML += '<div>📄 ' + input.files[i].name + '</div>';
            }
            selectedFiles.style.display = 'block';
        } else {
            selectedFiles.style.display = 'none';
        }
    }
    </script>
</body>
</html>