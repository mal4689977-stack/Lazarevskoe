<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<div style='background: #fff3cd; padding: 15px; margin: 15px 0; border-radius: 8px;'>";
    echo "<h3>🔍 ДЕБАГ ДАННЫХ:</h3>";
    echo "<strong>POST данные:</strong><br><pre>";
    print_r($_POST);
    echo "</pre>";
    echo "<strong>FILES данные:</strong><br><pre>";
    print_r($_FILES);
    echo "</pre>";
    echo "</div>";
    
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    if (empty($title) || empty($description) || $price <= 0 || $category_id <= 0) {
        $error = 'Заполните все обязательные поля';
    } else {
        $uploaded_images = [];
        $upload_dir = '../../uploads/ads/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        if(isset($_FILES['photos']) && is_array($_FILES['photos']['name'])) {
            echo "<div style='background: #e8f5e8; padding: 15px; margin: 15px 0; border-radius: 8px;'>";
            echo "<h4>📁 ПРОЦЕСС ЗАГРУЗКИ:</h4>";
            
            foreach($_FILES['photos']['name'] as $key => $name) {
                if(!empty($name)) {
                    echo "<p>⚡ Обрабатываем: " . $name . "</p>";
                    
                    if($_FILES['photos']['error'][$key] === 0) {
                        $file_tmp = $_FILES['photos']['tmp_name'][$key];
                        $file_new = uniqid() . '_' . $name;
                        $file_dest = $upload_dir . $file_new;
                        
                        if(move_uploaded_file($file_tmp, $file_dest)) {
                            $uploaded_images[] = $file_new;
                            echo "<p style='color: green;'>✅ Успешно: " . $file_new . "</p>";
                        } else {
                            echo "<p style='color: red;'>❌ Ошибка: " . $name . "</p>";
                        }
                    } else {
                        echo "<p style='color: orange;'>⚠️ Ошибка файла: " . $name . " (код: " . $_FILES['photos']['error'][$key] . ")</p>";
                    }
                }
            }
            echo "</div>";
        }
        
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $images_json = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
            
            $sql = "INSERT INTO ads (user_id, category_id, title, description, price, images, phone, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, '', NOW())";
            
            $stmt = $db->prepare($sql);
            
            if($stmt->execute([$user_id, $category_id, $title, $description, $price, $images_json])) {
                $success = '✅ Объявление успешно создано!';
                if(!empty($uploaded_images)) {
                    $success .= ' Загружено фото: ' . count($uploaded_images);
                }
            } else {
                $error = '❌ Ошибка сохранения';
            }
        } catch (Exception $e) {
            $error = '❌ Ошибка базы данных: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Простая форма</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        form { max-width: 500px; margin: 0 auto; }
        input, textarea, select, button { width: 100%; padding: 10px; margin: 5px 0; }
        button { background: #28a745; color: white; border: none; padding: 15px; }
    </style>
</head>
<body>
    <h1>📝 Добавить объявление</h1>
    
    <?php if($success): ?>
        <div style="background: #d4edda; padding: 15px; color: #155724;">
            <?= $success ?>
            <br><a href="../profile.php">← Профиль</a>
        </div>
    <?php elseif($error): ?>
        <div style="background: #f8d7da; padding: 15px; color: #721c24;">
            <?= $error ?>
        </div>
    <?php endif; ?>
    
    <form method="post" enctype="multipart/form-data">
        <div>
            <label>Заголовок *</label>
            <input type="text" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
        </div>
        
        <div>
            <label>Описание *</label>
            <textarea name="description" rows="4" required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
        </div>
        
        <div>
            <label>Цена *</label>
            <input type="number" name="price" required value="<?= $_POST['price'] ?? '' ?>">
        </div>
        
        <div>
            <label>Категория *</label>
            <select name="category_id" required>
                <option value="">Выберите</option>
                <?php
                $database = new Database();
                $db = $database->getConnection();
                $categories = $db->query("SELECT * FROM categories WHERE parent_id IS NULL")->fetchAll();
                foreach($categories as $cat) {
                    $selected = ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '';
                    echo '<option value="' . $cat['id'] . '" ' . $selected . '>' . $cat['name'] . '</option>';
                }
                ?>
            </select>
        </div>
        
        <div>
            <label>Фотографии</label>
            <input type="file" name="photos[]" multiple accept="image/*">
            <div style="background: #e7f3ff; padding: 10px; margin: 10px 0;">
                💡 Выберите файлы и нажмите "Опубликовать"<br>
                📁 Можно несколько файлов
            </div>
        </div>
        
        <button type="submit">📤 Опубликовать</button>
    </form>
    
    <div style="text-align: center; margin-top: 20px;">
        <a href="../profile.php">← Профиль</a>
    </div>
</body>
</html>