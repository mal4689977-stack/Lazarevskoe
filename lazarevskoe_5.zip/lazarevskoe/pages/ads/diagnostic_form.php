<?php
echo "<h2>🔍 ДИАГНОСТИКА ФОРМЫ ЗАГРУЗКИ</h2>";
echo "<hr>";

// Проверяем данные формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<h3>📤 Полученные данные:</h3>";
    echo "<p><strong>Метод:</strong> " . $_SERVER['REQUEST_METHOD'] . "</p>";
    echo "<p><strong>Content-Type:</strong> " . ($_SERVER['CONTENT_TYPE'] ?? 'не указан') . "</p>";
    
    echo "<h4>POST данные:</h4>";
    echo "<pre>";
    foreach ($_POST as $key => $value) {
        echo "$key: $value\n";
    }
    echo "</pre>";
    
    echo "<h4>FILES данные:</h4>";
    if (empty($_FILES)) {
        echo "<p style='color: red;'><strong>❌ Массив FILES ПУСТ!</strong></p>";
    } else {
        echo "<pre>";
        print_r($_FILES);
        echo "</pre>";
        
        // Пробуем загрузить файлы
        $upload_dir = '../../uploads/ads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        
        foreach ($_FILES as $field => $file_data) {
            if (is_array($file_data['name'])) {
                // Multiple files
                foreach ($file_data['name'] as $i => $name) {
                    if ($file_data['error'][$i] === UPLOAD_ERR_OK) {
                        $new_name = 'test_' . time() . '_' . $name;
                        $path = $upload_dir . $new_name;
                        if (move_uploaded_file($file_data['tmp_name'][$i], $path)) {
                            echo "<p style='color: green;'>✅ Загружен: $name -> $new_name</p>";
                        }
                    }
                }
            }
        }
    }
}
?>
<hr>
<h3>🧪 Тестовая форма:</h3>
<form method="POST" enctype="multipart/form-data">
    <div>
        <label>Текстовое поле:</label><br>
        <input type="text" name="test_text" value="тест">
    </div>
    <br>
    <div>
        <label>Файлы (multiple):</label><br>
        <input type="file" name="photos[]" multiple accept="image/*">
    </div>
    <br>
    <div>
        <label>Один файл:</label><br>
        <input type="file" name="single_file">
    </div>
    <br>
    <button type="submit" style="padding: 10px 20px; background: #2196F3; color: white; border: none; border-radius: 5px;">
        📤 Отправить форму
    </button>
</form>

<hr>
<h3>📋 Проверка формы create.php:</h3>
<a href="../create.php" style="color: blue;">Перейти к основной форме →</a>
