<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../pages/auth/login.php');
    exit;
}

$page_title = "Добавить объявление - Упрощенная форма";
include '../../includes/layout/header-catalog.php';
include '../../includes/layout/utility-bar.php';

$database = new Database();
$db = $database->getConnection();

$categories = $db->query("SELECT id, name FROM categories WHERE parent_id IS NOT NULL ORDER BY name")->fetchAll();

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploaded_images = [];
    $upload_dir = '../../uploads/ads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
    
    // Обрабатываем каждое поле файла отдельно
    $file_fields = ['photo1', 'photo2', 'photo3', 'photo4', 'photo5'];
    
    foreach ($file_fields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            $original_name = $_FILES[$field]['name'];
            $file_extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
            $file_name = uniqid() . '_' . $original_name;
            $file_path = $upload_dir . $file_name;
            
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (in_array($file_extension, $allowed_extensions)) {
                if (move_uploaded_file($_FILES[$field]['tmp_name'], $file_path)) {
                    $uploaded_images[] = $file_name;
                }
            }
        }
    }
    
    // Сохраняем в базу
    $user_id = $_SESSION['user_id'];
    $category_id = $_POST['category_id'];
    $title = trim($_POST['title']);
    
    $images_data = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
    
    $stmt = $db->prepare("
        INSERT INTO ads (user_id, category_id, title, description, price, location, phone, email, images, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
    ");
    
    $stmt->execute([
        $user_id, $category_id, $title, 
        'Описание объявления', 1000, 'Лазаревское', '+79991234567', 'test@test.ru', $images_data
    ]);
    
    echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>✅ Объявление создано!</h3>";
    echo "<p>Загружено файлов: " . count($uploaded_images) . "</p>";
    echo "<p>Файлы: " . implode(', ', $uploaded_images) . "</p>";
    echo "</div>";
}
?>

<div class="page-container">
    <div style="max-width: 600px; margin: 0 auto;">
        <div class="header-title">
            <h1>Упрощенная форма</h1>
            <small>Отдельные поля для файлов</small>
        </div>

        <form method="POST" enctype="multipart/form-data" style="background: var(--light); padding: 30px; border-radius: 15px;">
            
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Категория:</label>
                <select name="category_id" required style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px;">
                    <option value="">-- Выберите категорию --</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Заголовок:</label>
                <input type="text" name="title" required placeholder="Название объявления" style="width: 100%; padding: 12px; border: 2px solid var(--gray); border-radius: 8px;">
            </div>
            
            <div style="margin-bottom: 20px;">
                <h3 style="color: var(--primary); margin-bottom: 15px;">📷 Фотографии:</h3>
                
                <div style="margin-bottom: 10px;">
                    <label>Фото 1:</label>
                    <input type="file" name="photo1" accept="image/*" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
                
                <div style="margin-bottom: 10px;">
                    <label>Фото 2:</label>
                    <input type="file" name="photo2" accept="image/*" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
                
                <div style="margin-bottom: 10px;">
                    <label>Фото 3:</label>
                    <input type="file" name="photo3" accept="image/*" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
                
                <div style="margin-bottom: 10px;">
                    <label>Фото 4:</label>
                    <input type="file" name="photo4" accept="image/*" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
                
                <div style="margin-bottom: 10px;">
                    <label>Фото 5:</label>
                    <input type="file" name="photo5" accept="image/*" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
            </div>
            
            <button type="submit" class="cta-button" style="width: 100%; background: var(--success);">
                <i class="fas fa-paper-plane"></i> Создать объявление
            </button>
        </form>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="create.php" class="profile-btn secondary">← Вернуться к основной форме</a>
        </div>
    </div>
</div>

<?php include '../../includes/layout/footer.php'; ?>