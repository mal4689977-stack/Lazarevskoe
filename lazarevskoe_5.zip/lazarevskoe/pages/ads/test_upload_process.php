<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    die('Доступ запрещен');
}

echo "<h1>🧪 Результат тестовой загрузки</h1>";
echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 10px 0;'>";

// Выводим информацию о загрузке
echo "<h3>📊 ДАННЫЕ ЗАГРУЗКИ:</h3>";
echo "<strong>Данные FILES:</strong><br>";
echo "<pre>";
print_r($_FILES);
echo "</pre>";

echo "<strong>Данные POST:</strong><br>";
echo "<pre>";
print_r($_POST);
echo "</pre>";

echo "</div>";

// Загрузка файлов
$uploaded_images = [];
$upload_dir = '../../uploads/ads/';

// Создаем папку если не существует
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
    echo "<div class='success'>📁 Папка создана: $upload_dir</div>";
}

if(isset($_FILES['photos']) && !empty($_FILES['photos']['name'][0])) {
    echo "<h3>📁 ПРОЦЕСС ЗАГРУЗКИ:</h3>";
    
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    foreach($_FILES['photos']['name'] as $key => $name) {
        echo "<div style='border: 1px solid #ddd; padding: 10px; margin: 5px 0; border-radius: 5px;'>";
        echo "<strong>Файл:</strong> $name<br>";
        
        if($_FILES['photos']['error'][$key] === 0) {
            // Проверяем тип файла
            $file_type = $_FILES['photos']['type'][$key];
            if(!in_array($file_type, $allowed_types)) {
                echo "❌ <strong>Ошибка:</strong> Недопустимый тип файла: $file_type<br>";
                echo "</div>";
                continue;
            }
            
            // Проверяем размер
            if($_FILES['photos']['size'][$key] > $max_size) {
                echo "❌ <strong>Ошибка:</strong> Файл слишком большой: " . round($_FILES['photos']['size'][$key] / 1024 / 1024, 2) . "MB<br>";
                echo "</div>";
                continue;
            }
            
            $file_tmp = $_FILES['photos']['tmp_name'][$key];
            $file_ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            
            // Генерируем уникальное имя
            $file_new = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $name);
            $file_dest = $upload_dir . $file_new;
            
            echo "<strong>Временный файл:</strong> $file_tmp<br>";
            echo "<strong>Новое имя:</strong> $file_new<br>";
            echo "<strong>Путь назначения:</strong> $file_dest<br>";
            
            if(move_uploaded_file($file_tmp, $file_dest)) {
                $uploaded_images[] = $file_new;
                echo "✅ <strong>Успешно загружен!</strong><br>";
                
                // Проверяем что файл создан
                if(file_exists($file_dest)) {
                    $file_size = filesize($file_dest);
                    echo "✅ <strong>Файл сохранен:</strong> " . realpath($file_dest) . " (" . round($file_size / 1024, 2) . " KB)<br>";
                    
                    // Показываем превью
                    echo "<strong>Превью:</strong><br>";
                    echo "<img src='$file_dest' style='max-width: 200px; border: 2px solid green; border-radius: 5px; margin: 5px 0;'><br>";
                } else {
                    echo "❌ <strong>Ошибка:</strong> Файл не найден после загрузки<br>";
                }
            } else {
                $error = error_get_last();
                echo "❌ <strong>Ошибка загрузки:</strong> " . ($error ? $error['message'] : 'Неизвестная ошибка') . "<br>";
            }
        } else {
            echo "❌ <strong>Ошибка файла:</strong> Код ошибки " . $_FILES['photos']['error'][$key] . "<br>";
        }
        
        echo "</div>";
    }
} else {
    echo "<div class='error'>❌ Файлы не были загружены</div>";
}

// Сохраняем в базу данных
if(!empty($uploaded_images)) {
    echo "<h3>💾 СОХРАНЕНИЕ В БАЗУ ДАННЫХ:</h3>";
    
    $database = new Database();
    $db = $database->getConnection();
    
    $title = $_POST['title'] ?? 'Тестовое объявление';
    $description = $_POST['description'] ?? 'Тестовое описание';
    $price = $_POST['price'] ?? 1000;
    $category_id = $_POST['category_id'] ?? 1;
    $user_id = $_SESSION['user_id'];
    
    $images_json = json_encode($uploaded_images);
    
    $sql = "INSERT INTO ads (user_id, category_id, title, description, price, images, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())";
    
    $stmt = $db->prepare($sql);
    
    if($stmt->execute([$user_id, $category_id, $title, $description, $price, $images_json])) {
        $ad_id = $db->lastInsertId();
        echo "<div class='success'>✅ Объявление сохранено в БД! ID: $ad_id</div>";
        echo "<strong>Изображения в БД:</strong> " . htmlspecialchars($images_json) . "<br>";
    } else {
        echo "<div class='error'>❌ Ошибка сохранения в БД</div>";
    }
}

echo "<hr>";
echo "<h3>📁 ПРОВЕРКА ПАПКИ UPLOADS:</h3>";
if (is_dir($upload_dir)) {
    $files = array_diff(scandir($upload_dir), ['.', '..']);
    echo "<p>Всего файлов в папке: " . count($files) . "</p>";
    
    if ($files) {
        echo "<div style='display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; margin-top: 15px;'>";
        foreach($files as $file) {
            $file_path = $upload_dir . $file;
            echo "<div style='border: 1px solid #ddd; padding: 8px; border-radius: 5px; text-align: center; font-size: 12px;'>";
            echo "<img src='$file_path' style='width: 80px; height: 80px; object-fit: cover; border-radius: 3px;'><br>";
            echo "<small title='$file'>" . (strlen($file) > 15 ? substr($file, 0, 12) . '...' : $file) . "</small>";
            echo "</div>";
        }
        echo "</div>";
    }
} else {
    echo "<div class='error'>❌ Папка не существует: $upload_dir</div>";
}

echo "<br><br>";
echo "<a href='test_upload.php' style='padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>🔄 Еще один тест</a> ";
echo "<a href='upload_ad.php' style='padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;'>📝 Основная форма</a> ";
echo "<a href='debug_images.php' style='padding: 10px 20px; background: #ffc107; color: black; text-decoration: none; border-radius: 5px;'>🔍 Отладка</a> ";
echo "<a href='../../profile.php' style='padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 5px;'>👤 Профиль</a>";

?>