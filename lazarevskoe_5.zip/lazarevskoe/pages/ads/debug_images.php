<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    die('Доступ запрещен');
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];

echo "<!DOCTYPE html>
<html>
<head>
    <title>Отладка объявлений</title>
    <style>
        body { font-family: Arial; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .ad-block { border: 2px solid #007bff; padding: 20px; margin: 20px 0; border-radius: 10px; }
        .image-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; margin: 15px 0; }
        .image-item { border: 1px solid #ddd; padding: 10px; border-radius: 5px; text-align: center; }
        .image-item img { max-width: 100%; height: 120px; object-fit: cover; }
        .debug-info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1>🔍 Отладка объявлений</h1>";

// Получаем объявления пользователя
$ads = $db->query("
    SELECT a.*, c.name as category_name 
    FROM ads a 
    LEFT JOIN categories c ON a.category_id = c.id 
    WHERE a.user_id = $user_id 
    ORDER BY a.created_at DESC
")->fetchAll();

foreach($ads as $ad) {
    echo "<div class='ad-block'>";
    echo "<h3>Объявление ID: " . $ad['id'] . " - " . htmlspecialchars($ad['title']) . "</h3>";
    echo "<p><strong>Категория:</strong> " . ($ad['category_name'] ?? 'Нет') . "</p>";
    echo "<p><strong>Цена:</strong> " . $ad['price'] . " руб</p>";
    echo "<p><strong>Создано:</strong> " . $ad['created_at'] . "</p>";
    echo "<p><strong>Изображения в БД:</strong> " . ($ad['images'] ?? 'NULL') . "</p>";
    
    $images = json_decode($ad['images'] ?? '[]', true);
    echo "<p><strong>Количество изображений:</strong> " . count($images) . "</p>";
    
    if (!empty($images)) {
        echo "<div class='image-grid'>";
        foreach($images as $image) {
            $file_path = '../../uploads/ads/' . $image;
            $file_exists = file_exists($file_path);
            
            echo "<div class='image-item'>";
            if ($file_exists) {
                echo "<img src='$file_path' alt='$image'>";
                echo "<p class='success'>✅ " . $image . "</p>";
            } else {
                echo "<div style='width: 100px; height: 100px; background: #f8d7da; display: flex; align-items: center; justify-content: center; margin: 0 auto;'>❌</div>";
                echo "<p class='error'>" . $image . " (не найден)</p>";
            }
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p class='error'>❌ Нет изображений в этом объявлении</p>";
    }
    
    echo "</div>";
}

echo "<div style='text-align: center; margin-top: 30px;'>
        <a href='upload_ad.php' style='padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>📝 Добавить объявление</a>
        <a href='../profile.php' style='padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 5px; margin-left: 10px;'>👤 Профиль</a>
      </div>";

echo "</body></html>";
?>