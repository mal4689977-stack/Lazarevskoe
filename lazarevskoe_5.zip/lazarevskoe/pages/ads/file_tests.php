<!DOCTYPE html>
<html>
<head>
    <title>Тесты загрузки файлов</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 10px; }
        button { padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #45a049; }
    </style>
</head>
<body>
    <h1>🔧 ТЕСТЫ ЗАГРУЗКИ ФАЙЛОВ</h1>
    <p>Проверьте разные способы загрузки файлов</p>
    
    <?php
echo "<h2>🧪 ТЕСТ 1: Один файл</h2>";
if ($_FILES) {
    echo "<h3>Результат:</h3>";
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";
}
?>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="single_file" required>
    <br><br>
    <button type="submit">📤 Загрузить один файл</button>
</form>
<hr>
    <?php
echo "<h2>🧪 ТЕСТ 2: Multiple файлы</h2>";
if ($_FILES) {
    echo "<h3>Результат:</h3>";
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";
}
?>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="multiple_files[]" multiple required>
    <br><br>
    <button type="submit">📤 Загрузить multiple</button>
</form>
<hr>
    <?php
echo "<h2>🧪 ТЕСТ 3: Отдельные поля</h2>";
if ($_FILES) {
    echo "<h3>Результат:</h3>";
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";
}
?>
<form method="POST" enctype="multipart/form-data">
    <label>Файл 1:</label><br>
    <input type="file" name="file1"><br><br>
    <label>Файл 2:</label><br>
    <input type="file" name="file2"><br><br>
    <label>Файл 3:</label><br>
    <input type="file" name="file3"><br><br>
    <button type="submit">📤 Загрузить отдельные файлы</button>
</form>
<hr>
    <?php
echo "<h2>🧪 ТЕСТ 4: С JavaScript</h2>";
if ($_FILES) {
    echo "<h3>Результат:</h3>";
    echo "<pre>";
    print_r($_FILES);
    echo "</pre>";
}
?>
<form method="POST" enctype="multipart/form-data" id="jsForm">
    <input type="file" name="js_files[]" multiple id="fileInput" required>
    <br>
    <div id="fileList" style="margin: 10px 0; padding: 10px; background: #f5f5f5; border-radius: 5px;"></div>
    <button type="submit">📤 Загрузить с JS</button>
</form>

<script>
document.getElementById('fileInput').addEventListener('change', function(e) {
    const files = e.target.files;
    const fileList = document.getElementById('fileList');
    fileList.innerHTML = '<strong>Выбрано файлов: ' + files.length + '</strong><br>';
    
    for (let i = 0; i < files.length; i++) {
        fileList.innerHTML += '📄 ' + files[i].name + ' (' + Math.round(files[i].size/1024) + ' KB)<br>';
    }
});
</script>
<hr>
    
    <h2>📋 ИНСТРУКЦИЯ:</h2>
    <ol>
        <li>Попробуйте каждый тест по очереди</li>
        <li>Смотрите какие файлы появляются в результате</li>
        <li>Если в каком-то тесте файлы появляются - используйте этот подход</li>
    </ol>
</body>
</html>