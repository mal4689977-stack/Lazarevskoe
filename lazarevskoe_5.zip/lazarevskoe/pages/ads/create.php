<?php 
$page_title = "Добавить объявление - Лазаревское";
include '../../includes/layout/header.php';
include '../../includes/layout/utility-bar.php';
?>

<style>
@import url('../../assets/css/style.css');
</style>

<div class="page-container">
    <!-- Заголовок -->
    <div class="form-header">
        <h1>📋 Добавить объявление</h1>
        <p>Расскажите о вашем предложении в Лазаревском</p>
    </div>

    <!-- Основная форма -->
    <div class="form-card">
        <form id="createAdForm" enctype="multipart/form-data">
            <!-- Основная информация -->
            <div class="form-group">
                <label class="form-label required">Название объявления</label>
                <input type="text" class="form-input" name="title" required 
                       placeholder="Например: Гостевой дом 'У моря' или 'Прогулки на катерах'">
            </div>

            <div class="form-group">
                <label class="form-label required">Описание</label>
                <textarea class="form-textarea" name="description" required 
                          placeholder="Подробно опишите ваше предложение, условия, преимущества..."></textarea>
            </div>

            <!-- Категории -->
            <div class="form-group">
                <label class="form-label required">Категория</label>
                <div class="category-compact">
                    <div class="category-label">Основная:</div>
                    <select class="form-select" id="mainCategory" onchange="updateSubcategories()" required>
                        <option value="">-- выбрать категорию --</option>
                        <option value="housing">🏠 Жилье</option>
                        <option value="entertainment">🎉 Развлечения</option>
                        <option value="food">🍽️ Питание</option>
                        <option value="active">🏔️ Активный отдых</option>
                        <option value="tours">🗺️ Экскурсии</option>
                    </select>
                </div>

                <div class="category-compact">
                    <div class="category-label">Подкатегория:</div>
                    <select class="form-select" id="subCategory" name="subcategory" required>
                        <option value="">-- сначала выберите категорию --</option>
                    </select>
                </div>

                <div class="category-compact hidden" id="activeSubGroup">
                    <div class="category-label">Услуга:</div>
                    <select class="form-select" id="activeSubCategory" name="active_subcategory">
                        <option value="">-- выбрать услугу --</option>
                    </select>
                </div>
            </div>

            <!-- Контакты и цена -->
            <div class="form-row">
                <div class="form-group half">
                    <label class="form-label required">Контакты</label>
                    <input type="text" class="form-input" name="contacts" required 
                           placeholder="Телефон или email">
                </div>

                <div class="form-group half">
                    <label class="form-label">Цена</label>
                    <input type="text" class="form-input" name="price" 
                           placeholder="₽/сутки или услуга">
                </div>
            </div>

            <!-- Местоположение -->
            <div class="form-group">
                <label class="form-label">Местоположение</label>
                <input type="text" class="form-input" name="location" 
                       placeholder="Улица, район в Лазаревском">
            </div>

            <!-- Фотографии -->
            <div class="form-group">
                <label class="form-label">Фотографии</label>
                <div class="photo-fields" id="photoFields">
                    <div class="photo-field">
                        <div class="photo-number">1</div>
                        <input type="file" class="form-input photo-input" name="photo_1" accept="image/*">
                    </div>
                </div>
                <button type="button" class="add-photo-btn" onclick="addPhotoField()">
                    <i class="fas fa-plus"></i> Добавить фото
                </button>
                <div class="photo-hint">Максимум 5 фотографий. Рекомендуемый размер: 1200×800px</div>
            </div>

            <!-- Кнопка отправки -->
            <div class="submit-section">
                <button type="submit" class="submit-btn">
                    <i class="fas fa-paper-plane"></i> Опубликовать объявление
                </button>
            </div>
        </form>
    </div>
</div>

<style>
/* Стили формы в дизайне сайта */
.form-header {
    text-align: center;
    padding: 20px 0 30px;
    margin-bottom: 20px;
}

.form-header h1 {
    color: var(--primary);
    font-size: 32px;
    margin-bottom: 10px;
}

.form-header p {
    color: var(--secondary);
    font-size: 16px;
}

.form-card {
    background: var(--light);
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 25px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-group.half {
    margin-bottom: 0;
}

.form-label {
    display: block;
    margin-bottom: 10px;
    font-weight: 600;
    color: var(--primary);
    font-size: 15px;
}

.form-label.required::after {
    content: " *";
    color: var(--error);
}

.form-input, .form-select, .form-textarea {
    width: 100%;
    padding: 14px 16px;
    border: 2px solid #e8f0fe;
    border-radius: 10px;
    font-size: 15px;
    transition: all 0.3s ease;
    background: var(--light);
    font-family: inherit;
}

.form-input:focus, .form-select:focus, .form-textarea:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(42, 93, 132, 0.1);
}

.form-textarea {
    height: 120px;
    resize: vertical;
    line-height: 1.5;
}

/* Компактные категории */
.category-compact {
    display: grid;
    grid-template-columns: 120px 1fr;
    gap: 15px;
    align-items: center;
    margin-bottom: 12px;
}

.category-label {
    font-size: 14px;
    font-weight: 600;
    color: var(--primary);
}

/* Поля для фото */
.photo-fields {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 10px;
}

.photo-field {
    display: flex;
    gap: 12px;
    align-items: center;
}

.photo-number {
    font-size: 14px;
    font-weight: 600;
    color: var(--primary);
    min-width: 30px;
    text-align: center;
    background: var(--gray);
    padding: 8px;
    border-radius: 8px;
}

.photo-input {
    flex: 1;
    padding: 12px;
}

.add-photo-btn {
    background: var(--secondary);
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.add-photo-btn:hover {
    background: var(--primary);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(42, 93, 132, 0.3);
}

.add-photo-btn:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
}

.photo-hint {
    font-size: 13px;
    color: var(--secondary);
    font-style: italic;
}

/* Кнопка отправки */
.submit-section {
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 2px dashed var(--gray);
}

.submit-btn {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    padding: 16px 40px;
    background: linear-gradient(135deg, var(--accent), #FF9C71);
    color: white;
    text-decoration: none;
    border-radius: 12px;
    font-weight: 600;
    font-size: 16px;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(255, 127, 80, 0.3);
}

.submit-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(255, 127, 80, 0.4);
}

.submit-btn:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
}

.hidden {
    display: none;
}

/* Адаптивность */
@media (max-width: 768px) {
    .form-card {
        padding: 20px;
        margin: 0 10px 20px;
    }

    .form-header h1 {
        font-size: 28px;
    }

    .form-row {
        grid-template-columns: 1fr;
        gap: 0;
    }

    .category-compact {
        grid-template-columns: 100px 1fr;
        gap: 12px;
    }

    .submit-btn {
        padding: 14px 30px;
        font-size: 15px;
        width: 100%;
        justify-content: center;
    }
}

@media (max-width: 480px) {
    .form-card {
        padding: 15px;
        margin: 0 5px 15px;
    }

    .form-header {
        padding: 15px 0 20px;
    }

    .form-header h1 {
        font-size: 24px;
    }

    .category-compact {
        grid-template-columns: 1fr;
        gap: 8px;
    }

    .category-label {
        margin-bottom: 5px;
    }

    .photo-field {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }

    .photo-number {
        align-self: flex-start;
    }

    .add-photo-btn {
        width: 100%;
        justify-content: center;
    }
}
</style>

<script>
// Данные для каскадного выбора
const categories = {
    housing: [
        {value: 'hotels', text: '🏨 Отели и гостиницы'},
        {value: 'guest_houses', text: '🏡 Гостевые дома'},
        {value: 'apartments', text: '🏘️ Квартиры посуточно'},
        {value: 'camping', text: '🏕️ Турбазы и кемпинги'},
        {value: 'cottages', text: '🏠 Дома и коттеджи'},
        {value: 'private_rooms', text: '🏡 Частный сектор'}
    ],
    entertainment: [
        {value: 'attractions', text: '🎡 Парки аттракционов'},
        {value: 'aquaparks', text: '💦 Аквапарки'},
        {value: 'dolphinariums', text: '🐬 Дельфинарии'},
        {value: 'entertainment_centers', text: '🎳 Развлекательные центры'},
        {value: 'cinemas', text: '🎬 Кинотеатры'},
        {value: 'gaming_clubs', text: '🎮 Игровые клубы'}
    ],
    food: [
        {value: 'canteens', text: '🍜 Столовые'},
        {value: 'cafes', text: '☕ Кафе'},
        {value: 'restaurants', text: '🍷 Рестораны'},
        {value: 'fastfood', text: '🍔 Фастфуд'},
        {value: 'pizzerias', text: '🍕 Пиццерии'},
        {value: 'national_cuisine', text: '🌍 Национальная кухня'}
    ],
    active: [
        {value: 'land', text: '🚙 Наземный отдых'},
        {value: 'sea', text: '🌊 Морской отдых'},
        {value: 'air', text: '🪂 Воздушный отдых'},
        {value: 'mountain', text: '⛰️ Горный отдых'},
        {value: 'sports', text: '🎯 Спортивный отдых'},
        {value: 'transport', text: '🚗 Аренда транспорта'}
    ],
    tours: [
        {value: 'sightseeing', text: '🏛️ Обзорные экскурсии'},
        {value: 'waterfalls', text: '💦 Водопады и ущелья'},
        {value: 'mountain_tours', text: '⛰️ Горные туры'},
        {value: 'abkhazia_tours', text: '🇦🇱 Туры в Абхазию'},
        {value: 'dolmens', text: '🌿 Дольмены и древности'},
        {value: 'national_parks', text: '🏞️ Национальные парки'}
    ]
};

const activeSubcategories = {
    land: [
        {value: 'jeep_tours', text: 'Джиппинг'},
        {value: 'quad_bikes', text: 'Квадроциклы'},
        {value: 'horse_riding', text: 'Конные прогулки'},
        {value: 'rock_climbing', text: 'Скалолазание'},
        {value: 'paintball', text: 'Пейнтбол'},
        {value: 'motocross', text: 'Мотокросс'}
    ],
    sea: [
        {value: 'jet_skis', text: 'Гидроциклы'},
        {value: 'catamarans', text: 'Катамараны'},
        {value: 'boat_tours', text: 'Прогулки на катерах'},
        {value: 'diving', text: 'Дайвинг'},
        {value: 'water_attractions', text: 'Водные аттракционы'},
        {value: 'fishing', text: 'Морская рыбалка'}
    ],
    air: [
        {value: 'parachuting', text: 'Парашюты'}
    ],
    mountain: [
        {value: 'hiking', text: 'Пешие походы'}
    ],
    sports: [
        {value: 'sports_activities', text: 'Спортивные мероприятия'}
    ],
    transport: [
        {value: 'transport_rental', text: 'Прокат транспорта'}
    ]
};

let photoCount = 1;
const MAX_PHOTOS = 5;

function updateSubcategories() {
    const mainSelect = document.getElementById('mainCategory');
    const subSelect = document.getElementById('subCategory');
    const activeGroup = document.getElementById('activeSubGroup');
    const activeSelect = document.getElementById('activeSubCategory');
    
    const selectedMain = mainSelect.value;
    
    // Очищаем подкатегории
    subSelect.innerHTML = '<option value="">-- выбрать подкатегорию --</option>';
    activeSelect.innerHTML = '<option value="">-- выбрать услугу --</option>';
    activeGroup.classList.add('hidden');
    
    if (selectedMain && categories[selectedMain]) {
        categories[selectedMain].forEach(cat => {
            const option = new Option(cat.text, cat.value);
            subSelect.add(option);
        });
    }
}

// Обработчик изменения подкатегории для активного отдыха
document.getElementById('subCategory').addEventListener('change', function() {
    const mainSelect = document.getElementById('mainCategory');
    const activeGroup = document.getElementById('activeSubGroup');
    const activeSelect = document.getElementById('activeSubCategory');
    
    if (mainSelect.value === 'active' && this.value) {
        activeSelect.innerHTML = '<option value="">-- выбрать услугу --</option>';
        
        if (activeSubcategories[this.value]) {
            activeSubcategories[this.value].forEach(subCat => {
                const option = new Option(subCat.text, subCat.value);
                activeSelect.add(option);
            });
            activeGroup.classList.remove('hidden');
        }
    } else {
        activeGroup.classList.add('hidden');
    }
});

// Функция добавления поля для фото
function addPhotoField() {
    if (photoCount >= MAX_PHOTOS) {
        alert(`Максимум ${MAX_PHOTOS} фотографий`);
        return;
    }
    
    photoCount++;
    const photoFields = document.getElementById('photoFields');
    const newField = document.createElement('div');
    newField.className = 'photo-field';
    newField.innerHTML = `
        <div class="photo-number">${photoCount}</div>
        <input type="file" class="form-input photo-input" name="photo_${photoCount}" accept="image/*">
    `;
    photoFields.appendChild(newField);
    
    // Скрываем кнопку если достигли максимума
    if (photoCount >= MAX_PHOTOS) {
        document.querySelector('.add-photo-btn').style.display = 'none';
    }
}

// Обработчик отправки формы
document.getElementById('createAdForm').onsubmit = function(e) {
    e.preventDefault();
    
    const mainCategory = document.getElementById('mainCategory').value;
    const subCategory = document.getElementById('subCategory').value;
    const activeSub = document.getElementById('activeSubCategory').value;
    
    // Проверяем, что для активного отдыха выбран уровень 3
    if (mainCategory === 'active' && !activeSub) {
        alert('❌ Пожалуйста, выберите конкретную услугу');
        return;
    }
    
    const formData = new FormData(this);
    
    // Добавляем данные о категории
    formData.append('main_category', mainCategory);
    formData.append('sub_category', subCategory);
    if (activeSub) {
        formData.append('active_subcategory', activeSub);
    }
    
    // Здесь будет отправка на сервер
    const categoryText = document.getElementById('mainCategory').options[document.getElementById('mainCategory').selectedIndex].text +
        ' → ' + document.getElementById('subCategory').options[document.getElementById('subCategory').selectedIndex].text +
        (activeSub ? ' → ' + document.getElementById('activeSubCategory').options[document.getElementById('activeSubCategory').selectedIndex].text : '');
    
    alert('✅ Объявление успешно отправлено на модерацию!\n\n' +
          `Категория: ${categoryText}\n` +
          `Название: ${formData.get('title')}\n` +
          `Контакты: ${formData.get('contacts')}`);
    
    // Очистка формы после отправки
    this.reset();
    updateSubcategories();
    photoCount = 1;
    document.getElementById('photoFields').innerHTML = `
        <div class="photo-field">
            <div class="photo-number">1</div>
            <input type="file" class="form-input photo-input" name="photo_1" accept="image/*">
        </div>
    `;
    document.querySelector('.add-photo-btn').style.display = 'inline-flex';
};

// Инициализация
document.addEventListener('DOMContentLoaded', function() {
    updateSubcategories();
});
</script>

<?php include '../../includes/layout/footer.php'; ?>        