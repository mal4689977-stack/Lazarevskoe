<?php 
$page_title = "Развлечения - Лазаревское";
include 'includes/layout/header.php';
include 'includes/layout/utility-bar.php';
?>

<!-- Заголовок -->
<div class="header-title">
    <h1>Развлечения</h1>
    <small>Адреналин, природа и незабываемые впечатления</small>
</div>

<?php 
include 'includes/pages/entertainment/categories.php';
include 'includes/pages/entertainment/jeep.php';
include 'includes/pages/entertainment/horse.php';
include 'includes/pages/entertainment/atv.php';
include 'includes/pages/entertainment/water.php';
include 'includes/pages/entertainment/hiking.php';
include 'includes/pages/entertainment/extreme.php';
?>

<!-- Кнопка добавления -->
<div class="add-section">
    <button class="cta-button" onclick="window.location.href='pages/ads/create.php'">
        <i class="fas fa-plus-circle"></i> Добавить развлечение
    </button>
</div>

<?php include 'includes/layout/footer.php'; ?>
