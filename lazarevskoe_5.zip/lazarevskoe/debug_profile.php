<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];

// Получаем объявления пользователя
$user_ads = $db->query("
    SELECT a.*, c.name as category_name 
    FROM ads a 
    LEFT JOIN categories c ON a.category_id = c.id 
    WHERE a.user_id = $user_id 
    ORDER BY a.created_at DESC
")->fetchAll();

echo "<!DOCTYPE html>
<html>
<head>
    <title>Профиль - Отладка</title>
    <style>
        body { font-family: Arial; max-width: 1000px; margin: 0 auto; padding: 20px; }
        .ad-block { border: 2px solid #007bff; padding: 20px; margin: 15px 0; border-radius: 10px; }
        .image-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; margin: 10px 0; }
        .image-item { border: 1px solid #ddd; padding: 10px; border-radius: 5px; text-align: center; }
        .image-item img { max-width: 100%; height: 120px; object-fit: cover; }
        .debug-info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>👤 Профиль - Режим отладки</h1>
    
    <div class='debug-info'>
        <h3>📊 Информация:</h3>
        <p><strong>Всего объявлений:</strong> " . count($user_ads) . "</p>
        <p><strong>Путь к изображениям:</strong> uploads/ads/</p>
    </div>";

foreach($user_ads as $ad) {
    echo "<div class='ad-block'>";
    echo "<h3>Объявление ID: " . $ad['id'] . " - " . htmlspecialchars($ad['title']) . "</h3>";
    echo "<p><strong>Категория:</strong> " . ($ad['category_name'] ?? 'Нет') . "</p>";
    echo "<p><strong>Цена:</strong> " . $ad['price'] . " руб</p>";
    echo "<p><strong>Изображения в БД:</strong> " . ($ad['images'] ?? 'NULL') . "</p>";
    
    $images = json_decode($ad['images'] ?? '[]', true);
    echo "<p><strong>Количество изображений:</strong> " . count($images) . "</p>";
    
    if (!empty($images)) {
        echo "<div class='image-grid'>";
        foreach($images as $image) {
            $file_path = 'uploads/ads/' . $image;
            $file_exists = file_exists($file_path);
            
            echo "<div class='image-item'>";
            if ($file_exists) {
                echo "<img src='$file_path' alt='$image'>";
                echo "<p style='color: green;'>✅ " . $image . "</p>";
            } else {
                echo "<div style='width: 100px; height: 100px; background: #f8d7da; display: flex; align-items: center; justify-content: center; margin: 0 auto;'>❌</div>";
                echo "<p style='color: red;'>" . $image . " (не найден)</p>";
            }
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p style='color: red;'>❌ Нет изображений в этом объявлении</p>";
    }
    
    echo "</div>";
}

echo "<br><a href='profile.php'>← Обычный профиль</a> | 
      <a href='pages/ads/upload_ad.php'>📝 Добавить объявление</a>";
echo "</body></html>";
?>